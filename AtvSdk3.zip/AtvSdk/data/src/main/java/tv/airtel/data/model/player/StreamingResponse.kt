package tv.airtel.data.model.player

import java.util.HashMap

data class StreamingResponse(
    var eligibleForPlayback: Boolean? = null,
    var playId: String? = null,
    var lastWatchedPosition: String? = null,
    var playbackType: String? = null,
    var bundleInfo: BundleInfoResponse? = null,
    var drmInfo: DrmInfoResponse? = null,
    var requestCookieProperties: HashMap<String, String> = HashMap<String, String>()){

}
