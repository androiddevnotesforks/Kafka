package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class AppVersion (

    @SerializedName("updateTitle")
    @Expose
    var updateTitle: String? = null,

    @SerializedName("androidTargetVersion")
    @Expose
    var appVersion: Int = 0,

    @SerializedName("updateAvailableMessage")
    @Expose
    var updateMessage: String? = null,

    @SerializedName("apkUrl")
    @Expose
    var url: String? = null,

    @SerializedName("forceUpgrade")
    @Expose
    var forceUpgrade: Boolean = false,

    @SerializedName("softUpgradeOptional")
    @Expose
    var softUpgradeOptional: Boolean = true,

    @SerializedName("softUpgradeAlways")
    @Expose
    var softUpgradeAlways: Boolean = true
)