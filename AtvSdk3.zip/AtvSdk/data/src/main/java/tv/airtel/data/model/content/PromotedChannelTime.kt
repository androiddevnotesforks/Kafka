package tv.airtel.data.model.content

data class PromotedChannelTime(
        var startTime: Long = 0,
        var endTime: Long = 0
)