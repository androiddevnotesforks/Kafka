package tv.airtel.data.model.content

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class Credit(
        @SerializedName("characterName")
        @Expose
        var characterName: String? = null,
        @SerializedName("roleType")
        @Expose
        var roleType: String? = null,
        @SerializedName("displayTitle")
        @Expose
        var displayTitle: String? = null,
        @SerializedName("id")
        @Expose
        var id: String? = null,

        @SerializedName("images")
        @Expose
        var creditImages: ImagesApiModel?
) : Serializable
