package tv.airtel.data.utilmodule.util.telephony;

import android.content.Context;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import org.json.JSONObject;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import tv.airtel.data.utilmodule.util.LogUtil;

/**
 * Created by ajitp on 15/09/17.
 */
public class CustomTelephony {
    private Context mContext;
    private String SIM_VARINT = "";
    private String telephonyClassName = "";
    private int slotNumber_1 = 0;
    private int slotNumber_2 = 1;
    private String slotName_1 = "null";
    private String slotName_2 = "null";

    public CustomTelephony(Context mContext) {
        try {
            this.mContext = mContext;
            fetchClassInfo();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method returns the class name in which we fetch dual sim details
     */
    public void fetchClassInfo() {
        try {
            telephonyClassName = "android.telephony.TelephonyManager";
            String[] listofClass = new String[]{
                    "com.mediatek.telephony.TelephonyManagerEx",
                    "android.telephony.TelephonyManager",
                    "android.telephony.MSimTelephonyManager",
                    "android.telephony.TelephonyManager"};
            for (int index = 0; index < listofClass.length; index++) {
                if (isTelephonyClassExists(listofClass[index])) {
                    if (isMethodExists(listofClass[index], "getDeviceId")) {
                        LogUtil.INSTANCE.d("getDeviceId method found");
                        if (!SIM_VARINT.equalsIgnoreCase("")) {
                            break;
                        }
                    }
                    if (isMethodExists(listofClass[index],
                            "getNetworkOperatorName")) {
                        System.out
                                .println("getNetworkOperatorName method found");
                        break;
                    } else if (isMethodExists(listofClass[index],
                            "getSimOperatorName")) {
                        LogUtil.INSTANCE.d("getSimOperatorName method found");
                        break;
                    }
                }
            }
            for (int index = 0; index < listofClass.length; index++) {
                if (slotName_1 == null || slotName_1.equalsIgnoreCase("")) {
                    getValidSlotFields(listofClass[index]);
                    getSlotNumber(listofClass[index]);
                } else {
                    break;
                }
            }

            JSONObject edit = new JSONObject();
            edit.put("dualsim_telephonycls", telephonyClassName);
            edit.put("SIM_VARINT", SIM_VARINT);
            edit.put("SIM_SLOT_NAME_1", slotName_1);
            edit.put("SIM_SLOT_NAME_2", slotName_2);
            edit.put("SIM_SLOT_NUMBER_1", slotNumber_1);
            edit.put("SIM_SLOT_NUMBER_2", slotNumber_2);
            LogUtil.INSTANCE.d("INFO :", edit.toString());
            LogUtil.INSTANCE.d("Done");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Check method with sim variant
     */
    public boolean isMethodExists(String className, String compairMethod) {
        boolean isExists = false;
        try {
            Class<?> telephonyClass = Class.forName(className);
            Class<?>[] parameter = new Class[1];
            parameter[0] = int.class;
            StringBuffer sbf = new StringBuffer();
            Method[] methodList = telephonyClass.getDeclaredMethods();
            for (int index = methodList.length - 1; index >= 0; index--) {
                sbf.append("\n\n" + methodList[index].getName());
                if (methodList[index].getReturnType().equals(String.class)) {
                    String methodName = methodList[index].getName();
                    if (methodName.contains(compairMethod)) {
                        Class<?>[] param = methodList[index]
                                .getParameterTypes();
                        if (param.length > 0) {
                            if (param[0].equals(int.class)) {
                                try {
                                    SIM_VARINT = methodName.substring(
                                            compairMethod.length(),
                                            methodName.length());
                                    telephonyClassName = className;
                                    isExists = true;
                                    break;
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            } else {
                                telephonyClassName = className;
                                isExists = true;
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isExists;
    }


    public List<String> getIMEIPreLolipop() {
        List<String> imeis = new ArrayList<>();
        try {
            String imei1 = invokeMethod(telephonyClassName, slotNumber_1, "getDeviceId", SIM_VARINT);
            if (!TextUtils.isEmpty(imei1)) {
                imeis.add(imei1);
            }
            String imei2 = invokeMethod(telephonyClassName, slotNumber_2, "getDeviceId", SIM_VARINT);
            if (!TextUtils.isEmpty(imei2)) {
                imeis.add(imei2);
            }
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        return imeis;
    }

    public boolean isTelephonyClassExists(String className) {

        boolean isClassExists = false;
        try {
            Class<?> telephonyClass = Class.forName(className);
            isClassExists = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isClassExists;
    }

    /**
     * Here we are identify sim slot number
     */
    public void getValidSlotFields(String className) {

        String value = null;
        try {
            Class<?> telephonyClass = Class.forName(className);
            Class<?>[] parameter = new Class[1];
            parameter[0] = int.class;
            StringBuffer sbf = new StringBuffer();
            Field[] fieldList = telephonyClass.getDeclaredFields();
            for (int index = 0; index < fieldList.length; index++) {
                sbf.append("\n\n" + fieldList[index].getName());
                Class<?> type = fieldList[index].getType();
                Class<?> type1 = int.class;
                if (type.equals(type1)) {
                    String variableName = fieldList[index].getName();
                    if (variableName.contains("SLOT")
                            || variableName.contains("slot")) {
                        if (variableName.contains("1")) {
                            slotName_1 = variableName;
                        } else if (variableName.contains("2")) {
                            slotName_2 = variableName;
                        } else if (variableName.contains("" + slotNumber_1)) {
                            slotName_1 = variableName;
                        } else if (variableName.contains("" + slotNumber_2)) {
                            slotName_2 = variableName;
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Some device assign different slot number so here code execute
     * to get slot number
     */
    public void getSlotNumber(String className) {
        try {
            Class<?> c = Class.forName(className);
            Field fields1 = c.getField(slotName_1);
            fields1.setAccessible(true);
            slotNumber_1 = (Integer) fields1.get(null);
            Field fields2 = c.getField(slotName_2);
            fields2.setAccessible(true);
            slotNumber_2 = (Integer) fields2.get(null);
        } catch (Exception e) {
            slotNumber_1 = 0;
            slotNumber_2 = 1;
        }
    }

    private String invokeMethod(String className, int slotNumber,
                                String methodName, String SIM_variant) {
        String value = null;

        try {
            Class<?> telephonyClass = Class.forName(className);
            Constructor[] cons = telephonyClass.getDeclaredConstructors();
            cons[0].getName();
            cons[0].setAccessible(true);
            Object obj = cons[0].newInstance();
            Class<?>[] parameter = new Class[1];
            parameter[0] = int.class;
            Object ob_phone = null;
            try {
                Method getSimID = telephonyClass.getMethod(methodName
                        + SIM_variant, parameter);
                Object[] obParameter = new Object[1];
                obParameter[0] = slotNumber;
                ob_phone = getSimID.invoke(obj, obParameter);
            } catch (Exception e) {
                if (slotNumber == 0) {
                    Method getSimID = telephonyClass.getMethod(methodName
                            + SIM_variant, parameter);
                    Object[] obParameter = new Object[1];
                    obParameter[0] = slotNumber;
                    ob_phone = getSimID.invoke(obj);
                }
            }

            if (ob_phone != null) {
                value = ob_phone.toString();
            }
        } catch (Exception e) {
            invokeOldMethod(className, slotNumber, methodName, SIM_variant);
        }

        return value;
    }

    public String invokeOldMethod(String className, int slotNumber,
                                  String methodName, String SIM_variant) {
        String val = "";
        try {
            Class<?> telephonyClass = Class
                    .forName("android.telephony.TelephonyManager");
            Constructor[] cons = telephonyClass.getDeclaredConstructors();
            cons[0].getName();
            cons[0].setAccessible(true);
            Object obj = cons[0].newInstance();
            Class<?>[] parameter = new Class[1];
            parameter[0] = int.class;
            Object ob_phone = null;
            try {
                Method getSimID = telephonyClass.getMethod(methodName
                        + SIM_variant, parameter);
                Object[] obParameter = new Object[1];
                obParameter[0] = slotNumber;
                ob_phone = getSimID.invoke(obj, obParameter);
            } catch (Exception e) {
                if (slotNumber == 0) {
                    Method getSimID = telephonyClass.getMethod(methodName
                            + SIM_variant, parameter);
                    Object[] obParameter = new Object[1];
                    obParameter[0] = slotNumber;
                    ob_phone = getSimID.invoke(obj);
                }
            }

            if (ob_phone != null) {
                val = ob_phone.toString();
            }
        } catch (Exception e) {

        }
        return val;
    }

    private static String getDeviceIdBySlot(Context context, String predictedMethodName, int slotID) {

        String imsi = null;

        TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);

        try {

            Class<?> telephonyClass = Class.forName(telephony.getClass().getName());

            Class<?>[] parameter = new Class[1];
            parameter[0] = int.class;
            Method getSimID = telephonyClass.getMethod(predictedMethodName, parameter);

            Object[] obParameter = new Object[1];
            obParameter[0] = slotID;
            Object ob_phone = getSimID.invoke(telephony, obParameter);

            if (ob_phone != null) {
                imsi = ob_phone.toString();

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return imsi;
    }

    public List<String> getIMEIPostLolipop() {
        TelephonyManager telephonyManager = ((TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE));
        List<String> imeis = new ArrayList<>();
        String imei1 = telephonyManager.getDeviceId();
        String imei2 = null;
        try {
            imei1 = getDeviceIdBySlot(mContext, "getDeviceId", slotNumber_1);
            imei2 = getDeviceIdBySlot(mContext, "getDeviceId", slotNumber_2);
        } catch (NoSuchMethodError e) {
            e.printStackTrace();

        }
        if (!TextUtils.isEmpty(imei1)) {
            imeis.add(imei1);
        }
        if (!TextUtils.isEmpty(imei2)) {
            imeis.add(imei2);
        }
        return imeis;
    }
}
