package tv.airtel.data.model.content.detail

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class SeriesTvSeason(
    @SerializedName("seasonId")
    @Expose
    var seasonId: String? = null,
    @SerializedName("year")
    @Expose
    var year: String? = null,
    @SerializedName("name")
    @Expose
    var name: String? = null,

    @SerializedName("seasonNumber")
    @Expose
    var seasonNumber: String? = null

) : Serializable