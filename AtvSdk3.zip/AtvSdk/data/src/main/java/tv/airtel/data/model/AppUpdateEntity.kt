package tv.airtel.data.model

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Modified by Akash Gupta on 05/05/19.
 */
@Entity
data class
AppUpdateEntity(
        @PrimaryKey
        @Expose
        var id:Int = 1001,

        @SerializedName("updateAvailable")
        var updateAvailable: Boolean = false,

        @SerializedName("url")
        var url: String? = null,

        @SerializedName("requestInfo")
        var requestInfo: AppUpdateRequestInfo? = null,

        @SerializedName("checksum")
        var checksum: String? = null
) : Parcelable {
    constructor(parcel: Parcel) : this(
            parcel.readInt(),
            parcel.readByte() != 0.toByte(),
            parcel.readString(),
            parcel.readParcelable(AppUpdateRequestInfo::class.java.classLoader),
            parcel.readString()) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(id)
        parcel.writeByte(if (updateAvailable) 1 else 0)
        parcel.writeString(url)
        parcel.writeParcelable(requestInfo, flags)
        parcel.writeString(checksum)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<AppUpdateEntity> {
        override fun createFromParcel(parcel: Parcel): AppUpdateEntity {
            return AppUpdateEntity(parcel)
        }

        override fun newArray(size: Int): Array<AppUpdateEntity?> {
            return arrayOfNulls(size)
        }
    }
}
