package tv.airtel.data.model.analytics


class AnalyticsResponse
