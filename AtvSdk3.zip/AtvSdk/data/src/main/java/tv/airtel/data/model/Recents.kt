package tv.airtel.data.model

import com.google.gson.annotations.SerializedName
import tv.airtel.data.model.content.recentfavorite.RecentFavouriteItem

/**
 * Author : Akash Gupta
 * Created On : 09/08/18
 *
 */
class Recents(
        @field:SerializedName("add")
        var add: List<RecentFavouriteItem?>? = null,

        @field:SerializedName("remove")
        var remove: List<RecentFavouriteItem?>? = null
)