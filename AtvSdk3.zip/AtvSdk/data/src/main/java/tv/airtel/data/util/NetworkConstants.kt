package tv.airtel.data.util

/**
 * Created by ajitp on 14/09/17.
 *
 */
object NetworkConstants {
    const val dummyBaseUrl = "http://www.wynk.in/"

    object ApiParams {
        const val VALUE_REQUIRE_OTP_FALSE = "false"
        const val VALUE_DEVICE_KEY = "APADdd8231gg"
        const val CONTENT_TYPE_JSON = "application/json"

        const val KEY_ID = "id"
        const val KEY_PROFILE_ID = "profileId"
        const val KEY_IS_MAX = "isMax"
        const val KEY_CONTENT_ID = "contentId"
        const val KEY_CP = "cp"
        const val SESSION_HEADER = "X-Session"
        const val PARAM_DEVICE_KEY = "appId"

        const val PARAM_CREDIT_REF = "creditRef"

        const val KEY_PIN = "pin"

    }

    const val KEY_DEVICE_IDENTIFIER="KEY_DEVICE_IDENTIFIER"
    const val KEY_APP_VERSION = "appVersion"
    const val KEY_BUILD_NUMBER = "bn"
    const val KEY_PLATFORM = "platform"
    const val KEY_OS = "os"
    const val KEY_DT = "dt"
    const val KEY_MAC_ID = "macId"
    const val KEY_SERIAL_ID = "serialId"

    const val KEY_DEVICE_NAME = "deviceName"
    const val KEY_DEVICE_MAC = "mac"
    const val KEY_DEVICE_SERIAL = "serialId"
    const val NAME = "name"
    const val EMAIL = "email"
    const val DOB = "dob"
    const val MSISDN = "msisdn"
    const val MSG_TEXT = "msgTxt"
    const val KEY_OTP = "otp"
    const val KEY_CONTENT_TYPE = "Content-Type"
    const val KEY_SYNC_API_DIFF = "diff";
    const val KEY_PAGE_SIZE = "count"
    const val KEY_PAGE_NO = "offset"
    const val KEY_PAGE_OFFSET = "offSet"

    const val REQUIRE_OTP = "requireOtp"

    const val KEY_MCC = "mcc"
    const val KEY_MNC = "mnc"

    const val X_ATV_CUSTOMER = "x-atv-customer"
    const val X_ATV_CP = "x-atv-cp"
    const val KEY_X_MSISDN = "x-msisdn"
    const val KEY_X_ATV_DID = "x-atv-did"
    const val KEY_X_ATV_IMSI = "x-atv-imsi"
    const val KEY_X_ATV_PLATFORM = "x-atv-platform"
    const val KEY_X_DTH_CUSTOMER_ID = "x-atv-dth-customer-id"
    const val KEY_X_PROFILE_ID = "x-atv-profileId"

    const val KEY_DEVICE_KEY = "deviceKey"
    const val KEY_X_ATV_UTKN = "x-atv-utkn"
    const val KEY_X_ATV_MTKN = "x-atv-mtkn"
    const val LANGUAGE = "lang"
    const val KEY_PAGE_ID = "pageId"
    const val KEY_KEYWORD = "q"
    const val KEY_CPSUB = "cpSub"
    const val KEY_PEOPLE_ID = "id"
    const val KEY_LANGUAGES = "lang"
    const val KEY_SUPERTYPE = "superType"
    const val KEY_MORE = "more"

    //User migration
    const val KEY_UID_M = "uid_m"
    const val KEY_TOKEN_M = "token_m"

    const val contentId = "contentId"

    //for create profile
    const val KEY_NAME = "name"
    const val KEY_IMG = "img"
    const val KEY_PASS_CODE = "passCode"
    const val KEY_SEARCH_CONTENT_SOURCE = "source"

}
