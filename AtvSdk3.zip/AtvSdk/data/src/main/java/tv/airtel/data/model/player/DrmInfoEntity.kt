package tv.airtel.data.model.player

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


data class DrmInfoEntity (
    @SerializedName("streamTicket")
    @Expose
    var streamTicket: String? = null,

    @SerializedName("licenceUrl")
    @Expose
    var licenceUrl: String? = null,

    @SerializedName("xssessionHeader")
    @Expose
    var xssessionHeader: String? = null,

    @SerializedName("partner")
    @Expose
    var partner: String? = null,

    @SerializedName("streamId")
    @Expose
    var streamId: String? = null,

    @SerializedName("licenseValidity")
    @Expose
    var licenseValidity: Long = 0
)