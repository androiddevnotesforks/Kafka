package tv.airtel.data.model.content.detail

import android.arch.persistence.room.Entity
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

import tv.airtel.data.model.content.ContentDetail

/**
 * Created by a1wew4g3 on 27/09/17.
 */
@Entity
class SeasonDetail (
    @SerializedName("seriesTvSeasons")
    @Expose
    var seriesTvSeasons: List<SeriesTvSeason>? = null
): ContentDetail()
