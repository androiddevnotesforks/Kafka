package tv.airtel.data.model.content

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

@Entity
data class FavoriteListEntity (
    @field:PrimaryKey
    var id: String = "",

    @SerializedName("favorites")
    @Expose
    var favContents: List<RowItemContent> = arrayListOf()
)