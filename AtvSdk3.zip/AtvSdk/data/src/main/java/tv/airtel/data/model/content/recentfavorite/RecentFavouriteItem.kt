package tv.airtel.data.model.content.recentfavorite

import com.google.gson.annotations.SerializedName

/**
 * Author : Akash Gupta
 * Created On : 09/08/18
 *
 */
data class RecentFavouriteItem (
        @field:SerializedName("lastWatchedPosition")
        var lastWatchedPosition: Int = 0,

        @field:SerializedName("contentId")
        var contentId: String? = null,

        @field:SerializedName("lastUpdatedTimeStamp")
        var lastUpdatedTimeStamp: Long? = 0
)