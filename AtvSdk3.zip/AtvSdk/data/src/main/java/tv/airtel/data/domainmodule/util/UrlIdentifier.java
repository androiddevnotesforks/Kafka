package tv.airtel.data.domainmodule.util;

import java.net.URI;

/**
 * Created by a10253x0 on 29/09/17.
 */
public class UrlIdentifier {

    private static final String USER_MODULE = "User";
    private static final String LIVE_TV_MODULE = "LiveTv";
    private static final String CONTENT_MODULE = "Content";
    private static final String PACKAGE_MODULE = "Package";
    private static final String LAYOUT_MODULE = "Layout";
    private static final String IMAGE_MODULE = "Image";

    private static final String HUAWEI_BASE_URL = "epg";
    private static final String USER_BASE_URL = "user";
    private static final String CONTENT_BASE_URL = "content";
    private static final String PACKAGE_BASE_URL = "package";
    private static final String LAYOUT_BASE_URL = "layout";
    private static final String IMAGE_URL = "tvimg";

    public static String getModuleName(String url) {
        URI uri = URI.create(url);
        String moduleName = uri.getPath();
        if (url.toLowerCase().contains(HUAWEI_BASE_URL)) {
            moduleName = LIVE_TV_MODULE;
        } else if (url.toLowerCase().contains(USER_BASE_URL)) {
            moduleName = USER_MODULE;
        } else if (url.toLowerCase().contains(CONTENT_BASE_URL)) {
            moduleName = CONTENT_MODULE;
        } else if (url.toLowerCase().contains(PACKAGE_BASE_URL)) {
            moduleName = PACKAGE_MODULE;
        } else if (url.toLowerCase().contains(IMAGE_URL)) {
            moduleName = IMAGE_MODULE;
        } else if (url.toLowerCase().contains(LAYOUT_BASE_URL)) {
            moduleName = LAYOUT_MODULE;
        }
        return moduleName;
    }

    public static boolean isEmpty(CharSequence str) {
        return (str == null || str.length() == 0);
    }

}
