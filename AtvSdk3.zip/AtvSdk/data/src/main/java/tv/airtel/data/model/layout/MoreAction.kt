package tv.airtel.data.model.layout

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.util.isNotNullOrEmpty


data class MoreAction (

    @SerializedName("t")
    @Expose
    var title: String? = null,

    @SerializedName("color")
    @Expose
    var color: String? = null,

    @SerializedName("st")
    @Expose
    var clickToAction: String? = null,

    @SerializedName("pageId")
    @Expose
    var pageId: String? = null,

    @SerializedName("meta")
    @Expose
    var meta: Meta? = null,

    @SerializedName("source")
    @Expose
    var source : String = "",

    @SerializedName("packageId")
    @Expose
    var packageId: String? = null,

    @SerializedName("contentId")
    @Expose
    var contentId: String? = null,

    @SerializedName("channelId")
    @Expose
    var channelId: String? = null,

    @SerializedName("seriesId")
    @Expose
    var seriesId: String? = null,

    @SerializedName("type")
    @Expose
    var ty: String? = null,

    var backendType : BackendType = if (source.isNotNullOrEmpty()) BackendType.valueOf(source) else BackendType.BE

)