package tv.airtel.data.model.user

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

@Entity
data class LoginEntity (
    @SerializedName("success")
    @Expose
    var success: Boolean? = null,
    @SerializedName("token")
    @Expose
    var token: String? = null,
    @SerializedName("uid")
    @Expose
    @PrimaryKey
    var uid: String = "",
    @SerializedName("msisdnDetected")
    @Expose
    var msisdnDetected: Boolean? = null,
    @SerializedName("icrCircle")
    @Expose
    var icrCircle: Boolean? = null,
    @SerializedName("eapSim")
    @Expose
    var eapSim: Int? = null,
    @SerializedName("userConfig")
    @Expose
    var userConfig: UserConfig? = null
)