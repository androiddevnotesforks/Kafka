package tv.airtel.data.model.user.plan

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.util.*

@Entity
data class AvailablePlanEntity (
    @PrimaryKey
    var id: String = "",
    @SerializedName("availablePlans")
    @Expose
    var plansEntity: List<PlansEntity>? = null,
    @SerializedName("activePacks")
    @Expose
    var activePackEntities: List<ActivePackEntity>? = null
)