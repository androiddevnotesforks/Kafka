package tv.airtel.data.model.content

data class RecentlyWatched (
    var lastWatchedPosition: Int = 0
): Content()