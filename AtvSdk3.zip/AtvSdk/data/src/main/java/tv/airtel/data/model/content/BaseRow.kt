package tv.airtel.data.model.content

import tv.airtel.data.model.layout.*
import tv.airtel.data.util.isNotNullOrEmpty

open class BaseRow {
    var type: RowType? = null
    var totalCount: Int = 0
    var backendType: BackendType? = null
    var contentType: String? = null
    var subType: RowSubType? = null
    var layoutContents: List<LayoutContent>? = null
    var contents: ContentEntity? = null
    var more: MoreAction? = null
    var railPosition: Int = 0
    var title: String? = ""
    var headerIconUrl: String? = null
    var railType = subType?.type?.name
    var id = ""

    val railId: String
        get() = if (this.layoutContents.isNotNullOrEmpty()) this.layoutContents!![0].packageId!! else ""
}