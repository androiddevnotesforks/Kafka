package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class EligibleOffer (
    @SerializedName("offerId")
    @Expose
    var offerId: Int? = null,
    @SerializedName("title")
    @Expose
    var title: String? = null,
    @SerializedName("description")
    @Expose
    var description: String? = null,
    @SerializedName("src")
    @Expose
    var src: String? = null,
    @SerializedName("type")
    @Expose
    var type: String? = null,
    @SerializedName("action")
    @Expose
    var action: String? = null,
    @SerializedName("packs")
    @Expose
    var packs: List<Pack>? = null,
    @SerializedName("isAvailableOnRegisteredUser")
    @Expose
    var isAvailableOnRegisteredUser: Boolean? = null
)