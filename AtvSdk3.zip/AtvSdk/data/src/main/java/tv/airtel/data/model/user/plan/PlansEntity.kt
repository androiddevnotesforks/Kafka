package tv.airtel.data.model.user.plan

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class PlansEntity (
    @SerializedName("productId")
    @Expose
    var productId: String? = null,
    @SerializedName("partnerProductId")
    @Expose
    var partnerProductId: String? = null,
    @SerializedName("cp")
    @Expose
    var cpName: String? = null,
    @SerializedName("title")
    @Expose
    var title: String? = null,
    @SerializedName("validity")
    @Expose
    var validity: String? = null,
    @SerializedName("free")
    @Expose
    var isFree: Boolean = false,
    @SerializedName("meta")
    @Expose
    var meta: PlanMetaEntity? = null
)