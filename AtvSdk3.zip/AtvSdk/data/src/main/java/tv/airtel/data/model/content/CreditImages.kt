package tv.airtel.data.model.content

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Created by Aditya Mehta on 20/07/18.
 */
data class CreditImages (

    @SerializedName("PORTRAIT")
    @Expose
    var portrait: String? = null
)