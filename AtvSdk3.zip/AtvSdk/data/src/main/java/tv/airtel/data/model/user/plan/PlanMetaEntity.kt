package tv.airtel.data.model.user.plan

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class PlanMetaEntity (
    @SerializedName("bundleFlag")
    @Expose
    var isBundleFlag: Boolean = false,
    @SerializedName("contentProvider")
    @Expose
    var contentProvider: String? = null,
    @SerializedName("description")
    @Expose
    var description: String? = null,
    @SerializedName("wcfExpiry")
    @Expose
    var expiry: String? = null,
    @SerializedName("freePack")
    @Expose
    var isFreePack: Boolean = false,
    @SerializedName("image")
    @Expose
    var image: String? = null,
    @SerializedName("action")
    @Expose
    var action: String? = null,
    @SerializedName("longDescription")
    @Expose
    var longDescription: String? = null,
    @SerializedName("price")
    @Expose
    var price: Int = 0,
    @SerializedName("productType")
    @Expose
    var productType: String? = null,
    @SerializedName("subscriptionUnit")
    @Expose
    var subscriptionUnit: String? = null,
    @SerializedName("title")
    @Expose
    var title: String? = null
)