package tv.airtel.data.model.content

import java.util.HashMap

class ContentEntityResponse : HashMap<String, ContentEntity>() {
}