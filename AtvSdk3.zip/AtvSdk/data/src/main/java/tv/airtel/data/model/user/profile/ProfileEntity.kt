package tv.airtel.data.model.user.profile

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity
data class ProfileEntity(

        @PrimaryKey
        var id: Long = 0L, // is always same; overwrite data

        @field:SerializedName("devices")
        var devices: List<Device?>? = null,

        @field:SerializedName("userProfiles")
        var userProfile: List<UserProfile?>? = null
)
