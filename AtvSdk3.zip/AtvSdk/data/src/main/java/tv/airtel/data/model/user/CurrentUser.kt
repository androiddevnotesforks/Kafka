package tv.airtel.data.model.user

import android.app.Application
import tv.airtel.data.manager.CPManager
import tv.airtel.data.model.user.profile.ProfileEntity
import tv.airtel.data.model.user.profile.UserProfile
import tv.airtel.data.util.findActiveProfile
import tv.airtel.data.util.isNotNullOrEmpty
import tv.airtel.data.utilmodule.util.Constants
import tv.airtel.data.utilmodule.DeviceIdentifier
import tv.airtel.data.utilmodule.util.Signature
import java.util.HashMap
import java.util.HashSet
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Created by VipulKumar on 31/03/18.
 *
 */
@Singleton
class CurrentUser @Inject constructor() {

    @Inject
    lateinit var application: Application

    var uid: String? = null
    var token: String? = null
    var msisdnDetected: Boolean? = false
    var icrCircle: Boolean? = false
    var name: String? = null
    var langInfo: List<String>? = null
    var selectedLanguages: List<String>? = null
    var gender: String? = null
    var email: String? = null
    var dob: Long? = null
    var customerType: String? = null
    private var phoneNumberEncrypted: String? = null
    var huaweiNamespace: String? = null
    var subscriptions: List<Subscription>? = null
    val subscriptionStatusMap = hashMapOf<String, Subscription>()
    var userContentProperties: HashMap<String, String>? = null
    var userProperties: HashMap<String, String>? = null
    var lastSyncTime: Long? = -1
    var xclusivePlanUrl: String? = null

    var activeProfile: UserProfile? = null
    var appNotifcationPopUps: HashMap<String, PopUpInfo>? = null

    fun getLoginState(): LOGIN_STATE {
        if (uid.isNotNullOrEmpty() && token.isNotNullOrEmpty()) {
            if (!msisdnDetected!!) {
                return LOGIN_STATE.LOGIN
            } else if (msisdnDetected!!) {
                return if (email.isNullOrEmpty()) {
                    LOGIN_STATE.MOBILE_ONLY
                } else {
                    LOGIN_STATE.EMAIL_COMPLETE
                }
            }
        }
        return LOGIN_STATE.UNKNOWN
    }

    enum class LOGIN_STATE {
        UNKNOWN, LOGIN, MOBILE_ONLY, EMAIL_COMPLETE
    }

    fun buildCurrentUser(login: LoginEntity?, profileEntity: ProfileEntity? = null): CurrentUser? {
        if (login != null) {
            this.uid = login.uid
            this.token = login.token
            this.msisdnDetected = login.msisdnDetected
            this.icrCircle = login.icrCircle
        }
        val userConfig = login?.userConfig
        if (userConfig != null) {
            this.name = userConfig.userInfo?.name
            this.selectedLanguages = userConfig.userInfo?.lang
            this.langInfo = userConfig.langInfo
            this.gender = userConfig.userInfo?.gender
            this.email = userConfig.userInfo?.email
            this.dob = userConfig.userInfo?.dob
            this.customerType = userConfig.customerType
            this.phoneNumberEncrypted = userConfig.userInfo?.phoneNumber
            this.huaweiNamespace = userConfig.userInfo?.huaweiNamespace
            this.subscriptions = userConfig.subscriptions
            this.userProperties = userConfig.userProperties
            this.userContentProperties = userConfig.userContentProperties
            this.appNotifcationPopUps = userConfig.appNotificationsEntity
            this.lastSyncTime = userConfig.lastSyncTime
            this.xclusivePlanUrl = userConfig.xclusivePlanURL
            buildSubscriptionStatusMap()
            CPManager.setCPSubscriptionData(this)
        }

        profileEntity?.let {
            this.activeProfile =
                    profileEntity.findActiveProfile()
        }
        return this
    }

    fun isLoggedIn(): Boolean {
        return uid.isNotNullOrEmpty() && token.isNotNullOrEmpty()
                && phoneNumberEncrypted.isNotNullOrEmpty()
    }

    fun getPhoneNumber(): String? {
        if (phoneNumberEncrypted.isNotNullOrEmpty() && token.isNotNullOrEmpty()) {
            return Signature.decrypt(phoneNumberEncrypted!!, token?.substring(0, 16)!!)
        }
        return ""
    }

    private fun buildSubscriptionStatusMap() {
        subscriptionStatusMap.clear()
        subscriptions?.forEach {
            subscriptionStatusMap[it.cp ?: ""] = it
        }
    }

    fun getCommaSeparatedSubscribedCpIds(): String {
        if (subscriptionStatusMap.isNotEmpty()) {
            val keys = subscriptionStatusMap.keys
            val cpSet = HashSet<String>(keys)
            cpSet.add(Constants.YOUTUBE)
            return cpSet.joinToString(separator = ",")
        }
        return ""
    }

    fun getDeviceId() = DeviceIdentifier.deviceId
}
