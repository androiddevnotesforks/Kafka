package tv.airtel.data.model.content.recentfavorite

import com.google.gson.annotations.SerializedName

/**
 * Author : Akash Gupta
 * Created On : 09/08/18
 *
 */
data class Favorites(

        @field:SerializedName("add")
        var add: List<RecentFavouriteItem?>? = null,

        @field:SerializedName("remove")
        var remove: List<RecentFavouriteItem?>? = null
)