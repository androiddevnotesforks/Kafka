package tv.airtel.data.model.content

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class ImagesApiModel(
        @SerializedName("PORTRAIT")
        var portrait: String? = null,
        @SerializedName("PORTRAIT_HD")
        var portraitHD: String? = null,
        @SerializedName("LANDSCAPE")
        var landscape: String? = null,
        @SerializedName("LANDSCAPE_43")
        var landscape43: String? = null,
        @SerializedName("LANDSCAPE_43_HD")
        var landscape43HD: String? = null,
        @SerializedName("LANDSCAPE_169")
        var landscape169: String? = null,
        @SerializedName("LANDSCAPE_169_HD")
        var landscape169HD: String? = null,
        @SerializedName("LANDSCAPE_TILE_169")
        var landscapeTile169: String? = null,
        @SerializedName("LANDSCAPE_TILE_169_HD")
        var landscapeTile169HD: String? = null,
        @SerializedName("LANDSCAPE_53")
        var landscape53: String? = null,
        @SerializedName("LANDSCAPE_53_HD")
        var landscape53HD: String? = null,
        @SerializedName("LANDSCAPE_106")
        var landscape106: String? = null,
        @SerializedName("LANDSCAPE_106_HD")
        var landscape106HD: String? = null,
        @SerializedName("FEATURE_BANNER")
        var featuredBanner: String? = null,
        @SerializedName("FEATURE_BANNER_HD")
        var featuredBannerHD: String? = null,
        @SerializedName("FEATURE_SMALL_43")
        var featuredBanner43: String? = null,
        @SerializedName("FEATURE_SMALL_43_HD")
        var featuredBanner43HD: String? = null,
        @SerializedName("CUSTOM")
        var custom: String? = null,
        @SerializedName("LOGO")
        var logo: String? = null,
        @SerializedName("LOGO_HD")
        var logoHD: String? = null,

        var modifiedThumborUrl: String? = null) : Serializable {

    fun getFeaturedBannerHDImage(): String {
        return when {
            featuredBannerHD != null -> featuredBannerHD!!
            featuredBanner != null -> featuredBanner!!
            featuredBanner43HD != null -> featuredBanner43HD!!
            featuredBanner43 != null -> featuredBanner43!!
            else -> getLandscapeImage()
        }
    }

    fun getFeaturedBannerImage(): String {
        return when {
            featuredBanner != null -> featuredBanner!!
            featuredBanner43 != null -> featuredBanner43!!
            else -> getLandscapeImage()
        }
    }

    fun getLandscapeHDImage(): String {
        return when {
            landscape169HD != null -> landscape169HD!!
            landscape169 != null -> landscape169!!
            landscape43HD != null -> landscape43HD!!
            landscape43 != null -> landscape43!!
            landscape != null -> landscape!!
            landscape != null -> landscape!!
            featuredBannerHD != null -> featuredBannerHD!!
            featuredBanner != null -> featuredBanner!!
            featuredBanner43HD != null -> featuredBanner43HD!!
            featuredBanner43 != null -> featuredBanner43!!
            else -> logoHD ?: ""
        }
    }

    fun getLandscapeTileHDImage(): String {
        return when {
            landscapeTile169HD != null -> landscapeTile169HD!!
            landscapeTile169 != null -> landscapeTile169!!
            landscape169HD != null -> landscape169HD!!
            landscape169 != null -> landscape169!!
            landscape43HD != null -> landscape43HD!!
            landscape43 != null -> landscape43!!
            landscape != null -> landscape!!
            featuredBannerHD != null -> featuredBannerHD!!
            featuredBanner != null -> featuredBanner!!
            featuredBanner43HD != null -> featuredBanner43HD!!
            featuredBanner43 != null -> featuredBanner43!!
            else -> logoHD ?: ""
        }
    }

    fun getLandscapeTileImage(): String {
        return when {
            landscapeTile169 != null -> landscapeTile169!!
            landscape169 != null -> landscape169!!
            landscape43 != null -> landscape43!!
            landscape != null -> landscape!!
            featuredBanner != null -> featuredBanner!!
            featuredBanner43 != null -> featuredBanner43!!
            else -> logo ?: ""
        }
    }

    fun getLandscapeImage(): String {
        return when {
            landscape169 != null -> landscape169!!
            landscape43 != null -> landscape43!!
            landscape != null -> landscape!!
            featuredBanner != null -> featuredBanner!!
            featuredBanner43 != null -> featuredBanner43!!
            else -> logo ?: ""
        }
    }

    fun getAppTileImage(): String {
        return when {
            landscape53 != null -> landscape53!!
            landscape106 != null -> landscape106!!
            landscape169 != null -> landscape169!!
            landscape43 != null -> landscape43!!
            landscape != null -> landscape!!
            featuredBanner != null -> featuredBanner!!
            featuredBanner43 != null -> featuredBanner43!!
            else -> logo ?: ""
        }
    }

    fun getAppTileHDImage(): String {
        return when {
            landscape53HD != null -> landscape53HD!!
            landscape53 != null -> landscape53!!
            landscape106HD != null -> landscape106HD!!
            landscape106 != null -> landscape106!!
            landscape169HD != null -> landscape169HD!!
            landscape169 != null -> landscape169!!
            landscape43HD != null -> landscape43HD!!
            landscape43 != null -> landscape43!!
            landscape != null -> landscape!!
            landscape != null -> landscape!!
            featuredBannerHD != null -> featuredBannerHD!!
            featuredBanner != null -> featuredBanner!!
            featuredBanner43HD != null -> featuredBanner43HD!!
            featuredBanner43 != null -> featuredBanner43!!
            else -> logoHD ?: ""
        }
    }

    fun getPortraitImage(): String {
        return when {
            portrait != null -> portrait!!
            custom != null -> custom!!
            else -> logo ?: ""
        }
    }

    fun getPortraitImageHD(): String {
        return when {
            portraitHD != null -> portraitHD!!
            portrait != null -> portrait!!
            custom != null -> custom!!
            else -> logoHD ?: ""
        }
    }

}
