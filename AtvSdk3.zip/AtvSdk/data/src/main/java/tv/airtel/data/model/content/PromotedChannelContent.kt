package tv.airtel.data.model.content

data class PromotedChannelContent(
        var startTime: Long = 0,
        var endTime: Long = 0,
        var channelId: String? = null
)
