package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


data class PopUpCtaInfo(

        @SerializedName("st")
        @Expose
        var action: String? = null,

        @SerializedName("source")
        @Expose
        var source: String? = null,


        @SerializedName("t")
        @Expose
        var title: String? = null,


        @SerializedName("sTy")
        @Expose
        var subType: String? = null,

        @SerializedName("color")
        @Expose
        var color: String? = null,


        @SerializedName("naviagtionTitle")
        @Expose
        var naviagtionTitle: String? = null,


        @SerializedName("packageId")
        @Expose
        var packageId: String? = null
)