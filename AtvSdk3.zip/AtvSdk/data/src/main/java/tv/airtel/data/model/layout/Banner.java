package tv.airtel.data.model.layout;

import tv.airtel.data.model.content.BaseRow;

/**
 * Created by ajitp on 14/09/17.
 */
public class Banner extends BaseRow {

}