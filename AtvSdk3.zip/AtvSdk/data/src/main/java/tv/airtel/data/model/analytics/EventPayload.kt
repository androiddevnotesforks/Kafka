package tv.airtel.data.model.analytics

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class EventPayload(

    @SerializedName("id")
    @Expose
    var id: String? = null,
    @SerializedName("events")
    @Expose
    var events: List<Event>? = null,
    @SerializedName("ts")
    @Expose
    var ts: String? = null
)