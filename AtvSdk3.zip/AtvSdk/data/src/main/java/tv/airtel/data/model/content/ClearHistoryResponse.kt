package tv.airtel.data.model.content

data class ClearHistoryResponse(var success: Boolean = false, var message: String = "")