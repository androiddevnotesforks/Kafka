package tv.airtel.data.model.layout

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class LayoutFormat (

    @SerializedName("ty")
    @Expose
    var type: String = "",

    @SerializedName("showAll")
    @Expose
    var showAll: Boolean = false,

    @SerializedName("t")
    @Expose
    var railTitle: String? = null,

    @SerializedName("action")
    @Expose
    var moreAction: MoreAction? = null,

    @SerializedName("hIcon")
    @Expose
    var headerIcon: String? = null,

    @SerializedName("ds")
    @Expose
    var description: String? = null,

    @SerializedName("lds")
    @Expose
    var longDescription: Array<String>? = null,

    @SerializedName("fIcon")
    @Expose
    var footerIcon: String? = null,

    @SerializedName("img")
    @Expose
    var image: String? = null,

    @SerializedName("pId")
    @Expose
    var programId: String? = null,

    @SerializedName("sId")
    @Expose
    var seriesId: String? = null,

    @SerializedName("pTy")
    @Expose
    var programType: String? = null,

    @SerializedName("meta")
    @Expose
    var meta: tv.airtel.data.model.layout.Meta? = null,

    @SerializedName("lt")
    @Expose
    var longTitle: String? = null,

    @SerializedName("row")
    @Expose
    var row: Int = 0,

    @SerializedName("col")
    @Expose
    var col: Int = 0,

    @SerializedName("cpId")
    @Expose
    var contentProgramId: String? = null

)