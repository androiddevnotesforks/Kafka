package tv.airtel.data.model.content

data class ContentTrailerInfo (
    var type: String? = null,
    var url: String? = null
)