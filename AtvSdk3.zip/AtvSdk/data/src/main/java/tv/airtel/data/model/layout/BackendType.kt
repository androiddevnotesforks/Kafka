package tv.airtel.data.model.layout

/**
 * Created by Udit on 10/10/17.
 */

enum class BackendType private constructor
(val sourceType: String) {
    BE("BE"), HW("HW"), MW("MW"), MUSIC("MUSIC");
}
