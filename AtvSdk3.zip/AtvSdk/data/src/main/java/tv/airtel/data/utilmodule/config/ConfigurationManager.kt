package tv.airtel.data.utilmodule.config

import android.app.Application
import tv.airtel.data.utilmodule.util.Constants
import javax.inject.Inject

/**
 * Created by Udit on 23/10/17.
 *
 */
class ConfigurationManager @Inject constructor(application: Application) {

    private var languageKeys = arrayOf(String())
    private var selectedLanguage: String? = null
    private var languageStringSelected: String? = null
    private var languages = arrayOf(String())

    companion object {
        var shouldSendAPIFailureToFabric: Boolean = false
        var MIDDLEWARE_END_POINT: String? = null
        var MIDDLEWARE_END_POINT_SEARCH_API: String? = null
        var MIDDLEWARE_END_POINT_HTTP: String? = null
        var MIDDLEWARE_EVENTS_BASE_URL : String? = null
        var MIDDLEWARE_END_POINT_LAYOUT_API: String? = null
        var MIDDLEWARE_END_POINT_LAYOUT_API_HTTP: String? = null
        var MIDDLEWARE_END_POINT_CONTENT_LAYOUT_API: String? = null
        var MIDDLEWARE_END_POINT_CONTENT_LAYOUT_API_HTTP: String? = null
        var MIDDLEWARE_END_POINT_PLAY_API:String? = null
        var GEO_BLOCK_ENDPOINT: String? = null
        var OTP_MESSAGE_TO_USER: String? = null
    }

    fun getConfigLanguageKeys(): Array<String> {
        return languageKeys
    }

    fun getLanguageOptions(): Array<String> {
        return languages
    }

    fun getSelectedLanguage(): String? {
        return if (selectedLanguage != null) selectedLanguage else Constants.DEFAULT_MESSAGE_KEY
    }

    fun setSelectedLanguage(SELECTED_LANGUAGE: String?) {
        this.selectedLanguage = SELECTED_LANGUAGE
    }

    fun setConfigLanguageStringSelected(languageStringSelected: String?) {
        this.languageStringSelected = languageStringSelected
    }

    fun getName() {
    }
}
