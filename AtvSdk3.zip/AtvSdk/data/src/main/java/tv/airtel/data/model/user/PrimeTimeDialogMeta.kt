package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Created by Udit on 31/10/18.
 */
data class PrimeTimeDialogMeta(
        @SerializedName("title") @Expose val title: String = "",
        @SerializedName("subTitle") @Expose val subTitle: String = "",
        @SerializedName("para") @Expose val para: String = "",
        @SerializedName("pkgId") @Expose val pkgId: String = "",
        @SerializedName("source") @Expose val source: String = "",
        @SerializedName("footerText") @Expose val footerText: String = "",
        @SerializedName("prop_1") @Expose val prop1: String = "",
        @SerializedName("prop_2") @Expose val prop2: String = "",
        @SerializedName("prop_3") @Expose val prop3: String = "",
        @SerializedName("cta") @Expose val cta: String = "",
        @SerializedName("appPkgName") @Expose val packageName: String = "",
        @SerializedName("deeplink") @Expose val deeplink: String = ""
)