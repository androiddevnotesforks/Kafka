package tv.airtel.data.domainmodule

import android.app.Application
import tv.accedo.airtel.wynk.domain.R
import tv.airtel.data.utilmodule.config.ConfigurationManager
import tv.airtel.data.utilmodule.config.Environment
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Created by VipulKumar on 20/03/18.
 *
 */
@Singleton
class ConfigUtils @Inject constructor() {
    @Inject
    lateinit var environment: Environment
    @Inject
    internal lateinit var configurationManager: ConfigurationManager
    @Inject
    internal lateinit var application: Application

    fun init() {
        ConfigurationManager.MIDDLEWARE_END_POINT = environment.middleWareEndpoint
        ConfigurationManager.MIDDLEWARE_EVENTS_BASE_URL = environment.middlewareEventsEndpoint
        ConfigurationManager.MIDDLEWARE_END_POINT_LAYOUT_API = environment.middlewareLayoutEndpoint
        ConfigurationManager.MIDDLEWARE_END_POINT_CONTENT_LAYOUT_API = environment.middlewareCMSEndpoint
        ConfigurationManager.GEO_BLOCK_ENDPOINT = environment.middlewareGeoEndpoint
        ConfigurationManager.MIDDLEWARE_END_POINT_PLAY_API = environment.middlewarePlayEndPoint
        ConfigurationManager.MIDDLEWARE_END_POINT_SEARCH_API = environment.middlewareSearchEndPoint
//        ConfigurationManager.MIDDLEWAREPLAYBACKHOST = Environment.middlewarePlayBackHost

        ConfigurationManager.MIDDLEWARE_END_POINT_HTTP = environment.middleWareEndpointHttp
        ConfigurationManager.MIDDLEWARE_END_POINT_LAYOUT_API_HTTP = environment.middlewareLayoutEndpointHttp
        ConfigurationManager.MIDDLEWARE_END_POINT_CONTENT_LAYOUT_API_HTTP = environment.middlewareCMSEndpointHttp
        ConfigurationManager.OTP_MESSAGE_TO_USER = application.getString(R.string.otp_default_message)
    }

    companion object {

        private val DEFAULTVALUE = -1
    }
}
