package tv.airtel.data.model.user

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.SerializedName

/**
 * Created by B0098048 on 25/09/17.
 *
 */
@Entity
data class GeoBlockEntity (
    @PrimaryKey
    var id: String = "",

    @SerializedName("isAllowedCountry")
    var isAllowedCountry: Boolean = false
)