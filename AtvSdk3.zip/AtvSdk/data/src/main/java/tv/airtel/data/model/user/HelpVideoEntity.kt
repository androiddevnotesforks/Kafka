package tv.airtel.data.model.user

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

@Entity
data class HelpVideoEntity(

    @SerializedName("rails_count")
    @Expose
    val railCount: Int,

    @SerializedName("video_rails")
    @Expose
    val videoRails: List<VideoRail>,


    @PrimaryKey
    @SerializedName("id")
    @Expose
    val id: Int = 1
)