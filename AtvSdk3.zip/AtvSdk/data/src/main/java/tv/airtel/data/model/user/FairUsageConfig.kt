package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Created by Ashwani on 27/10/18.
 */
data class FairUsageConfig (

    @SerializedName("days")
    @Expose
    var days: Int = 1,

    @SerializedName("seconds")
    @Expose
    var seconds: Int = 3600
)