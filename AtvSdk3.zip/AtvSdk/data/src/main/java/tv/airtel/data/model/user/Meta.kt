package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class Meta (
    @SerializedName("isDth")
    @Expose
    var isDth: Boolean = false,

    @SerializedName("cpId")
    @Expose
    var cpId: String? = null,

    @SerializedName("railType")
    @Expose
    var railType: String? = null,

    @SerializedName("cardTitle")
    @Expose
    var cardTitle: String? = null,

    @SerializedName("cardIcon")
    @Expose
    var cardIcon: String? = null,

    @SerializedName("showPopup")
    @Expose
    var showPopup: Boolean = false,

    @SerializedName("longDescription")
    @Expose
    var longDescription: String? = null,

    @SerializedName("seperator")
    @Expose
    var seperator: String? = null,

    @SerializedName("packId")
    @Expose
    var packId: String? = null
)