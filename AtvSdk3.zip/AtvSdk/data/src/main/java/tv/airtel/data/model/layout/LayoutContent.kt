package tv.airtel.data.model.layout

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.util.isNotNullOrEmpty

data class LayoutContent(

    @SerializedName("pageSize")
    @Expose
    var pageSize: Int = 0,
    @SerializedName("source")
    @Expose
    var source: String = "",
    @SerializedName("packageId")
    @Expose
    var packageId: String? = null,
    @SerializedName("type")
    @Expose
    var type: String? = null,

    var backendType : BackendType = if (source.isNotNullOrEmpty()) BackendType.valueOf(source) else BackendType.BE
)
