package tv.airtel.data.utilmodule

import android.Manifest
import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.ConnectivityManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.text.TextUtils
import android.util.DisplayMetrics
import tv.airtel.data.utilmodule.util.LogUtil
import tv.airtel.data.utilmodule.config.Environment
import tv.airtel.data.utilmodule.util.StringUtil.capitalize
import tv.airtel.util.util.telephony.CustomTelephony
import java.net.NetworkInterface
import java.util.*


@Suppress("unused", "MemberVisibilityCanBePrivate")
/**
 * Simple logic to detect and define specific device type attributes, if needed.
 *
 */
object DeviceIdentifier {
    private const val XXHDPI = "xxhdpi"
    private const val XHDPI = "xhdpi"
    private const val HDPI = "hdpi"
    private const val MDPI = "mdpi"

    private const val NETWORK_3G = "3G"
    private const val NETWORK_4G = "4G"
    private const val NETWORK_GPRS = "GPRS"
    private const val NETWORK_EDGE_2G = "EDGE 2G"
    private const val LOG_TAG = "DeviceIdentifier"
    var deviceIdentifierHeader = ""
    var deviceId: String? = ""
    var projectType: AppId? = null

    enum class DeviceType(val type: String) {
        DEVICE_PHONE("Phone"),
        DEVICE_TABLET("Tablet"),
        DEVICE_STB("STB"),
        DEVICE_STICK("STICK")
    }

    enum class AppId(val type: String) {
        APP_XTREME("XTREME"),
        APP_SDK("SDK"),
        APP_STB("STB"),
        APP_PRIMETIME("PRIMETIME"),
        APP_MOBILITY("MOBILITY"),
        APP_MITRA("PTMITRA")
    }

    var dthCustomerId: String? = null
    var deviceType: DeviceType? = null

    val osVersion: String
        get() = "" + Build.VERSION.SDK_INT

    val sdkVersion: Int
        get() = Build.VERSION.SDK_INT

    var deviceName: String? = null

    fun buildDeviceName(context: Context, appId: AppId = DeviceIdentifier.AppId.APP_SDK) {
        when (appId) {
            DeviceIdentifier.AppId.APP_XTREME -> {
                deviceName =
                        Settings.Global.getString(context.contentResolver, "device_name")
            }
            DeviceIdentifier.AppId.APP_SDK,
            DeviceIdentifier.AppId.APP_STB,
            DeviceIdentifier.AppId.APP_MOBILITY -> {
                val manufacturer = Build.MANUFACTURER
                val model = Build.MODEL
                deviceName = if (model.startsWith(manufacturer)) {
                    capitalize(model)
                } else {
                    capitalize(manufacturer) + " " + model
                }
            }
        }
    }

    val serialId = android.os.Build.SERIAL

    val osVersionInt: Int
        get() = Build.VERSION.SDK_INT

    val osVersionString: String
        get() = Build.VERSION.RELEASE

    val platform: String
        get() = "Android"

    val os: String
        get() = platform
    var msisdn: String? = null

    fun getAppVersionCode(): String? {
        return Environment.APP_VERSION_CODE.toString()
    }

    fun getCarrierName(context: Context): String {
        var carrierName = ""
        val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager?
        if (telephonyManager != null) {
            carrierName = telephonyManager.networkOperatorName
        }
        return carrierName
    }

    @SuppressLint("MissingPermission", "HardwareIds")
    private fun getImei(context: Context): String {
        var imei = ""
        val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager?
        if (telephonyManager != null) {
            imei = telephonyManager.deviceId
        }
        return imei
    }


    fun getIMEIs(context: Context, telephony: CustomTelephony): List<String> {
        val imeis = HashSet<String>()

        if (Build.VERSION.SDK_INT < 21) {
            imeis.addAll(telephony.imeiPreLolipop)
        } else if (Build.VERSION.SDK_INT >= 21) {
            imeis.addAll(telephony.imeiPostLolipop)
        }
        if (imeis.size == 0) {
            imeis.add(getImei(context))
        }
        return ArrayList(imeis)
    }


    fun getMcc(context: Context): String {
        val tel = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val networkOperator = tel.networkOperator
        var mcc = 0
        try {
            if (networkOperator != null && networkOperator != "") {
                mcc = Integer.parseInt(networkOperator.substring(0, 3))
            }
        } catch (e: NumberFormatException) {
            e.printStackTrace()
        }

        return mcc.toString()
    }

    fun getMnc(context: Context): String {
        val tel = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val networkOperator = tel.networkOperator
        var mnc = 0
        if (networkOperator != null && networkOperator != "") {
            try {
                mnc = Integer.parseInt(networkOperator.substring(3))
            } catch (e: NumberFormatException) {
                e.printStackTrace()
            }

        }
        return mnc.toString()
    }

    @SuppressLint("HardwareIds")
    fun getIMSI(context: Context): String {
        var deviceID = ""
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val phoneStatePermission = context.checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
            if (phoneStatePermission == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                    deviceID = getImsiString(context)
                } else {
                    val serviceName = Context.TELEPHONY_SERVICE
                    val telephonyManager = context.getSystemService(serviceName) as TelephonyManager?
                    if (telephonyManager?.subscriberId != null)
                        deviceID = telephonyManager.subscriberId.toString()
                }
            }
        } else {
            val serviceName = Context.TELEPHONY_SERVICE
            val telephonyManager = context.getSystemService(serviceName) as TelephonyManager?
            if (telephonyManager != null && telephonyManager.subscriberId != null)
                deviceID = telephonyManager.subscriberId.toString()
        }
        return deviceID
    }

    private fun getImsiString(context: Context): String {
        var str = ""
        if (!TextUtils.isEmpty(getSim1IMSI(context))) {
            str += getSim1IMSI(context)
        }
        if (!TextUtils.isEmpty(getSim1IMSI(context)) && !TextUtils.isEmpty(getSim2IMSI(context))) {
            str += ","
        }
        if (!TextUtils.isEmpty(getSim2IMSI(context))) {
            str += getSim2IMSI(context)
        }
        return str
    }


    @TargetApi(Build.VERSION_CODES.LOLLIPOP_MR1)
    private fun getSim1IMSI(context: Context): String {
        var imsi = ""
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        try {
            val getSubId = TelephonyManager::class.java.getMethod("getSubscriberId", Int::class.javaPrimitiveType)
            val sm = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            imsi = getSubId.invoke(tm, sm.getActiveSubscriptionInfoForSimSlotIndex(0).subscriptionId) as String // Sim slot 1 IMSI
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            return imsi
        }
    }


    @TargetApi(Build.VERSION_CODES.LOLLIPOP_MR1)
    private fun getSim2IMSI(context: Context): String {
        var imsi = ""
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        try {
            val getSubId = TelephonyManager::class.java.getMethod("getSubscriberId", Int::class.javaPrimitiveType)
            val sm = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            //TODO: Line below throws exception
            imsi = getSubId.invoke(tm, sm.getActiveSubscriptionInfoForSimSlotIndex(1).subscriptionId) as String // Sim slot 2 IMSI
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            return imsi
        }
    }

    fun getNetworkType(context: Context): String {
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        var networkType = ""
        when (tm.networkType) {
            TelephonyManager.NETWORK_TYPE_HSDPA -> networkType = NETWORK_3G
            TelephonyManager.NETWORK_TYPE_HSPAP -> networkType = NETWORK_4G
            TelephonyManager.NETWORK_TYPE_GPRS -> networkType = NETWORK_GPRS
            TelephonyManager.NETWORK_TYPE_EDGE -> networkType = NETWORK_EDGE_2G
        }// for 3g HSDPA networktype will be return as
        // per testing(real) in device with 3g enable
        // data
        // and speed will also matters to decide 3g network type
        // No specification for the 4g but from wiki
        // i found(HSPAP used in 4g)
        // http://goo.gl/bhtVT
        return networkType
    }

    fun getNetworkClass(context: Context): String {

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        @SuppressLint("MissingPermission") val netInfo = cm.activeNetworkInfo
        return if (netInfo != null) {
            if (netInfo.type == ConnectivityManager.TYPE_WIFI && netInfo.isConnected) {
                "wifi"
            } else {
                getMobileNetworkType(context)
            }
        } else {
            getMobileNetworkType(context)
        }
    }

    fun getMobileNetworkType(context: Context): String {
        val mTelephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val networkType = mTelephonyManager.networkType
        return when (networkType) {
            TelephonyManager.NETWORK_TYPE_GPRS, TelephonyManager.NETWORK_TYPE_EDGE, TelephonyManager.NETWORK_TYPE_CDMA, TelephonyManager.NETWORK_TYPE_1xRTT, TelephonyManager.NETWORK_TYPE_IDEN -> "2G"
            TelephonyManager.NETWORK_TYPE_UMTS, TelephonyManager.NETWORK_TYPE_EVDO_0, TelephonyManager.NETWORK_TYPE_EVDO_A, TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA, TelephonyManager.NETWORK_TYPE_HSPA, TelephonyManager.NETWORK_TYPE_EVDO_B, TelephonyManager.NETWORK_TYPE_EHRPD, TelephonyManager.NETWORK_TYPE_HSPAP -> "3G"
            TelephonyManager.NETWORK_TYPE_LTE -> "4G"
            else -> "Unknown"
        }
    }

    fun findDeviceDensity(context: Context): String {
        val deviceDensity: String
        val metrics = context.resources.displayMetrics
        LogUtil.d("metrics.densityDpi" + metrics.densityDpi)
        deviceDensity = when {
            metrics.densityDpi >= DisplayMetrics.DENSITY_XXXHIGH -> XXHDPI
            metrics.densityDpi >= DisplayMetrics.DENSITY_XXHIGH -> XXHDPI
            metrics.densityDpi >= DisplayMetrics.DENSITY_XHIGH -> XHDPI
            metrics.densityDpi >= DisplayMetrics.DENSITY_HIGH -> HDPI
            metrics.densityDpi == DisplayMetrics.DENSITY_TV -> HDPI
            metrics.densityDpi >= DisplayMetrics.DENSITY_MEDIUM -> MDPI
            else -> HDPI
        }
        return deviceDensity
    }

    fun findDeviceWidthinpixel(context: Context): Int {
        val deviceWidth: Int
        val metrics = context.resources.displayMetrics
        deviceWidth = metrics.widthPixels
        return deviceWidth
    }

    fun isAutoRotationON(context: Context): Boolean {
        return Settings.System.getInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
    }

    fun getAppVersion(context: Context): Int {
        var version = Integer.MIN_VALUE
        try {
            version = context.packageManager.getPackageInfo(context.packageName, 0).versionCode
        } catch (ex: PackageManager.NameNotFoundException) {
            LogUtil.w(LOG_TAG, "App version not found", ex)
        }

        return version
    }


    fun getAppVersionName(): String {
        return Environment.APP_VERSION_NAME
    }

    fun checkIsTelevision(context: Context): Boolean {
        val uiMode = context.resources.configuration.uiMode
        return uiMode and Configuration.UI_MODE_TYPE_MASK == Configuration.UI_MODE_TYPE_TELEVISION
    }

    fun isTablet(context: Context): Boolean {
        return context.resources.configuration.screenLayout and Configuration.SCREENLAYOUT_SIZE_MASK >= Configuration.SCREENLAYOUT_SIZE_LARGE
    }

    @SuppressLint("HardwareIds")
    fun getDeviceId(context: Context): String? {
        if (deviceId?.isEmpty() == true) {
            deviceId = Settings.Secure.getString(context.contentResolver,
                    Settings.Secure.ANDROID_ID)
        }
        return deviceId
    }

    fun getDeviceBrand(): String {
        return android.os.Build.BRAND

    }

    fun getDeviceModel(): String {
        return android.os.Build.MODEL
    }

    @SuppressLint("HardwareIds")
    fun getIMEI(context: Context): String {
        var imei = ""
        val phoneStatePermission = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE)
        if (phoneStatePermission == PackageManager.PERMISSION_GRANTED) {
            val tManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            imei = tManager.deviceId
        }
        return imei
    }


    fun getDeviceIdentifierHeader(context: Context): String {
        val deviceIdentifier = StringBuilder()
        deviceIdentifier.append(getDeviceId(context) + "|")
                .append("${deviceType?.type}|")
                .append("$platform|")
                .append("$osVersion|")
                .append(getAppVersionCode() + "|")
                .append(getAppVersionName())
        deviceIdentifierHeader = deviceIdentifier.toString()
        return deviceIdentifierHeader
    }

    fun getNetworkTypeInfo(context: Context): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val netInfo = cm.activeNetworkInfo
        return if (netInfo != null) {
            if (netInfo.type == ConnectivityManager.TYPE_WIFI && netInfo.isConnected) {
                "wifi"
            } else {
                getMobileNetworkType(context)
            }
        } else {
            getMobileNetworkType(context)
        }
    }

    fun getSimMCCMNC(context: Context): String {
        if (Build.VERSION.SDK_INT >= 22 && ContextCompat
                        .checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            var operatorName = ""
            val sm = SubscriptionManager.from(context)
            if (sm.activeSubscriptionInfoList != null) {
                for (i in 0 until sm.activeSubscriptionInfoList.size) {
                    val operator = sm.getActiveSubscriptionInfo(sm.activeSubscriptionInfoList[i].subscriptionId)
                    operatorName += operator.mcc.toString() + "-" + operator.mnc
                    if (sm.activeSubscriptionInfoList.size == 2 && i == 0) {
                        operatorName += ","
                    }
                }
            } else {
                operatorName = getActiveMCCMNC(context)
            }
            return operatorName
        } else {
            return getActiveMCCMNC(context)
        }
    }

    fun getActiveMCCMNC(context: Context): String {
        val tel = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val simOperator = tel.simOperator
        var mccNdMnc = ""
        if (simOperator != null && simOperator != "") {
            try {
                mccNdMnc = "" + simOperator.substring(0, 3)
                mccNdMnc += "-" + simOperator.substring(3)
            } catch (e: NumberFormatException) {
                e.printStackTrace()
            }
        }
        return if (!TextUtils.isEmpty(mccNdMnc)) {
            mccNdMnc
        } else {
            ""
        }
    }

    fun networkType(context: Context): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val netInfo = cm.activeNetworkInfo
        return if (netInfo != null) {
            if (netInfo.type == ConnectivityManager.TYPE_WIFI && netInfo.isConnected) {
                "1"
            } else {
                "0"
            }
        } else {
            "0"
        }
    }

    fun getActiveOperator(context: Context): String {
        try {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            return tm.simOperator.substring(3)
        } catch (e: Exception) {
            LogUtil.d("  while getting  getNetworkOperator   exception e : $e")
            return ""
        }
    }

    fun getCustomerIdentifier(context: Context, customerType: String?): String {
        val customerIdentifier = StringBuilder()
        customerIdentifier
                .append(getSimMCCMNC(context) + "|")
                //.append("BROADBAND|")
                .append(if (customerType?.isNotEmpty() == true) "$customerType|" else "" + "|")
                .append(networkType(context) + "|")
                .append(getActiveOperator(context) + "|")
                .append(isTablet(context))
        return customerIdentifier.toString()
    }

    fun getMacAddr(): String {
        try {
            val all = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (nif in all) {
                if (!nif.name.equals("wlan0", ignoreCase = true)) continue

                val macBytes = nif.hardwareAddress ?: return ""

                val res1 = StringBuilder()
                for (b in macBytes) {
                    //res1.append(Integer.toHexString(b & 0xFF) + ":");
                    res1.append(String.format("%02X:", b))
                }

                if (res1.length > 0) {
                    res1.deleteCharAt(res1.length - 1)
                }
                return res1.toString()
            }
        } catch (ex: Exception) {
        }

        return "MAC_NOT_FOUND"
    }

    fun fetchAppVersionName(context: Context): String? {
        try {
            val pInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            return pInfo.versionName
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }
        return ""
    }

    fun fetchAppVersionCode(context: Context): Int? {
        try {
            val pInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            return pInfo.versionCode
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }
        return -1
    }

    fun getStreamingOperator(context: Context): String? {
        return if (Build.VERSION.SDK_INT >= 24) {
            getActiveDataName(context)
        } else {
            getSimOperatorName(context)
        }
    }

    @TargetApi(24)
    private fun getActiveDataName(context: Context): String? {
        var operatorName: String? = null
        return try {
            val sm = SubscriptionManager.from(context)
            val operator = sm.getActiveSubscriptionInfo(SubscriptionManager.getDefaultDataSubscriptionId())
            operatorName = operator.carrierName.toString()
            operatorName
        } catch (e: Exception) {
            getSimOperatorName(context)
        }
    }

    fun getSimOperatorName(context: Context): String? {
        var operator: String? = null
        return try {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            operator = tm.simOperatorName
            operator
        } catch (e: Exception) {
            LogUtil.d("  while getting  getSimOperatorName   exception e : $e")
            operator
        }
    }
}
