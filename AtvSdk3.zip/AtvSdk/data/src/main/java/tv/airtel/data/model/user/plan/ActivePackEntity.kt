package tv.airtel.data.model.user.plan

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class ActivePackEntity (
    @SerializedName("productId")
    @Expose
    var productId: String? = null,
    @SerializedName("partnerProductId")
    @Expose
    var partnerProductId: String? = null,
    @SerializedName("wcfExpiry")
    @Expose
    var wcfExpiry: String? = null,
    @SerializedName("expiry")
    @Expose
    var expiry: Long? = null,
    @SerializedName("cpExpiry")
    @Expose
    var cpExpiry: String? = null,
    @SerializedName("cp")
    @Expose
    var cp: String? = null,
    @SerializedName("meta")
    @Expose
    var meta: MetaActivePackEntity? = null,
    @SerializedName("free")
    @Expose
    var free: Boolean? = null,

    @SerializedName("subState")
    @Expose
    var subState: String? = null,

    @SerializedName("title")
    @Expose
    var title: String? = null)