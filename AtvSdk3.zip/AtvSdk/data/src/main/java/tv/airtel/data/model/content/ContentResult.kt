package tv.airtel.data.model.content

/**
 * Created by b0203949 on 24/07/18.
 */

class ContentResult(val pageId: String?, val baseRows: List<BaseRow>?)  {

}
