package tv.airtel.data.model.search

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.model.content.Content

data class SearchCategoryEntity(
        @SerializedName("count") @Expose val count: Int = 0,
        @SerializedName("type") @Expose val type: String? = null,
        @SerializedName("displayTitle") @Expose val displayTitle: String? = null,
        @SerializedName("contentResponseList") @Expose val contentResults: List<Content>? = null,
        @SerializedName("more") @Expose val moreItemsAvailable: Boolean = false
)