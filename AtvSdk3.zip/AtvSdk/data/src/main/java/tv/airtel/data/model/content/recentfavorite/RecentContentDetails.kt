package tv.airtel.data.model.content.recentfavorite

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.TypeConverters
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.db.MiddlewareTypeConverters
import tv.airtel.data.model.content.Credit
import tv.airtel.data.model.content.ImagesApiModel
import tv.airtel.data.model.content.TrailerSteamUrlsItem
import java.util.*

class RecentContentDetails {

    @ColumnInfo(name = "content_id")
    var id: String? = null
    @ColumnInfo(name = "program_type")
    var programType: String? = null
    @ColumnInfo(name = "title")
    var title: String? = null
    @SerializedName("tvShowName")
    @ColumnInfo(name = "tv_show_name")
    var tvShowName:String? =null
    @ColumnInfo(name = "cp_id")
    var cpId: String? = null
    @ColumnInfo(name = "imdb_rating")
    @SerializedName("imdbRating")
    var imdbRating: String? = null
    @ColumnInfo(name = "release_year")
    var releaseYear: String? = null
    @ColumnInfo(name = "free")
    var free: Boolean? = null
    @ColumnInfo(name = "images")
    var images: ImagesApiModel? = null
    @ColumnInfo(name = "episode_tv_show_image")
    @SerializedName("episodeTvShowImage")
    var episodeTvShowImage: ImagesApiModel? = null
    @ColumnInfo(name = "duration")
    var duration: Int? = null
    @ColumnInfo(name = "description")
    var description: String? = null
    @ColumnInfo(name = "ref_type")
    var refType: String? = null
    @ColumnInfo(name = "trailer_stream_urls")
//    @TypeConverters(DataTypeConverters::class)
    var trailerSteamUrls: MutableList<TrailerSteamUrlsItem>? = null
    @ColumnInfo(name = "short_url")
    var shortUrl: String? = null
    @ColumnInfo(name = "languages")
    @TypeConverters(MiddlewareTypeConverters.StringListTypeConverters::class)
    var languages: List<String> = ArrayList()
    @ColumnInfo(name = "channel_id")
    var channelId: String? = null
    @ColumnInfo(name = "genre")
    var genre: String? = null
    @ColumnInfo(name = "genres")
    @TypeConverters(MiddlewareTypeConverters.StringListTypeConverters::class)
    var genres:List<String>? =null
    @ColumnInfo(name = "hd")
    var hd: Boolean = false
    @ColumnInfo(name = "start_time")
    var startTime: Long = 0
    @ColumnInfo(name = "skip_intro")
    var skipIntro: Int? = 0
    @ColumnInfo(name = "skip_credits")
    var skipCredits: Int? = 0
    @ColumnInfo(name = "season_id")
    var seasonId: String? = null
    @ColumnInfo(name = "episode_season_num")
    @SerializedName("episodeSeasonNum")
    var episodeSeasonNum: Int? = null
    @ColumnInfo(name = "series_id")
    var seriesId: String? = null
    @ColumnInfo(name = "is_hotstar")
    var isHotStar: Boolean = false
    @ColumnInfo(name = "credits")
    @TypeConverters(MiddlewareTypeConverters.CreditListTypeConverters::class)
    var credits: List<Credit>? = null
    @ColumnInfo(name = "air_date")
    @SerializedName("airDate")
    @Expose
    var airDate: Long = 0
    @ColumnInfo(name = "episode_number")
    @SerializedName("episodeNum")
    @Expose
    var episodeNumber: Int = 0
    @ColumnInfo(name = "segment")
    var segment: String? = null

}