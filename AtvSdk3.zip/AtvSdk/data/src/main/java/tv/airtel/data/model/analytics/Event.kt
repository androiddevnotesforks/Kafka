package tv.airtel.data.model.analytics

import com.google.gson.JsonObject
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class Event(

        @SerializedName("event_type")
        @Expose
        var eventType: String? = null,

        @SerializedName("meta")
        @Expose
        var meta: JsonObject? = null,

        @SerializedName("ts")
        @Expose
        var ts: String? = null,

        @SerializedName("uid")
        @Expose
        var uid: String? = null,


        @SerializedName("did")
        @Expose
        var did: String? = null,

        @SerializedName("dt")
        @Expose
        var dt: String? = null,

        @SerializedName("ov")
        @Expose
        var ov: String? = null,

        @SerializedName("bn")
        @Expose
        var bn: String? = null,


        @SerializedName("nq")
        @Expose
        var nq: String? = null,

        @SerializedName("os")
        @Expose
        var os: String? = null,

        @SerializedName("nct")
        @Expose
        var nct: String? = null,

        @SerializedName("lc")
        @Expose
        var lc: String? = null,

        @SerializedName("nt")
        @Expose
        var nt: String? = null,

        @SerializedName("av")
        @Expose
        var av: String? = null,


        @SerializedName("adid")
        @Expose
        var adid: String? = null,


        @SerializedName("brand")
        @Expose
        var brand: String? = null,


        @SerializedName("model")
        @Expose
        var model: String? = null,

    @SerializedName("appid")
    @Expose
    var appId: String? = null,

        @SerializedName("dname")
        @Expose
        var dname: String? = null,

        @SerializedName("appid")
        @Expose
        var appid: String? = null,

        @SerializedName("sId")
        @Expose
        var serialId: String? = null,

        @SerializedName("profileId")
        @Expose
        var profileId: String? = null)

