package tv.airtel.data.model.user.plan

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class MetaActivePackEntity(

        @SerializedName("image")
        @Expose
        var image: String? = null,

        @SerializedName("price")
        @Expose
        var price: String? = null,

        @SerializedName("category")
        @Expose
        var category: String? = null,

        @SerializedName("childPacks")
        @Expose
        var childPacks: String? = null,

        @SerializedName("oneTimeChargingUnit")
        @Expose
        var oneTimeChargingUnit: String? = null,

        @SerializedName("CP")
        @Expose
        var cp: String? = null,

        @SerializedName("isParentPack")
        @Expose
        var isParentPack: String? = null,

        @SerializedName("chargePerCycle")
        @Expose
        var chargePerCycle: String? = null,

        @SerializedName("oneTimeCharge")
        @Expose
        var oneTimeCharge: String? = null,

        @SerializedName("subscriptionUnit")
        @Expose
        var subscriptionUnit: String? = null,

        @SerializedName("isSubscription")
        @Expose
        var isSubscription: Boolean = false,

        @SerializedName("enabled")
        @Expose
        var isEnabled: Boolean = false,

        @SerializedName("productType")
        @Expose
        var productType: String? = null,

        @SerializedName("bundleCounter")
        @Expose
        var bundleCounter: String? = null,

        @SerializedName("title")
        @Expose
        var title: String? = null,

        @SerializedName("description")
        @Expose
        var description: String? = null,

        @SerializedName("action")
        @Expose
        var action: String? = null,

        @SerializedName("longDescription")
        @Expose
        var longDescription: String? = null
)