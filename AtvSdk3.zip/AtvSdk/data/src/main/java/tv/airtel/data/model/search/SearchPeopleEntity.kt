package tv.airtel.data.model.search

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class SearchPeopleEntity (

    @SerializedName("type")
    @Expose
    var type: String? = null,
    @SerializedName("credits")
    @Expose
    var results: List<SearchPeopleModel>? = null,
    @SerializedName("totalRecord")
    @Expose
    var totalRecord: Int = 0

)