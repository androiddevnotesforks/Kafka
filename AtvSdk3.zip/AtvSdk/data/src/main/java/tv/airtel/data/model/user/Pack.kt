package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class Pack (

    @SerializedName("id")
    @Expose
    var id: String? = null,
    @SerializedName("partnerProductId")
    @Expose
    var partnerProductId: String? = null,
    @SerializedName("title")
    @Expose
    var title: String? = null,
    @SerializedName("description")
    @Expose
    var description: String? = null,
    @SerializedName("cpName")
    @Expose
    var cpName: String? = null,
    @SerializedName("action")
    @Expose
    var action: String? = null
)