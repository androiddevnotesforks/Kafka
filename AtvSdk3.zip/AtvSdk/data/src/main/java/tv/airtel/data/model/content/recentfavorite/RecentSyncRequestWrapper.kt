package tv.airtel.data.model.content.recentfavorite

 data class RecentSyncRequestWrapper(val requestEntity: RecentFavouriteRequestEntity, val diff: Boolean)