package tv.airtel.data.model.content

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.util.ArrayList
import java.util.Arrays

@Entity
open class Content {
    @PrimaryKey
    @SerializedName("id")
    var id: String = ""
    @SerializedName("programType")
    var programType: String? = null
    @SerializedName("title")
    var title: String? = null
    @SerializedName("subTitle")
    var subTitle: String? = null
    @SerializedName("images")
    var images: ImagesApiModel? = null
    @SerializedName("cpId")
    var cpId: String? = null
    @SerializedName("shortUrl")
    var shortUrl: String? = null
    @SerializedName("refType")
    var refType: String? = null
    @SerializedName("languages")
    var languages: List<String>? = null
    @SerializedName("description")
    var description: String? = null
    @SerializedName("seriesId")
    @Expose
    var seriesId: String? = null
    @SerializedName("channelId")
    @Expose
    var channelId: String? = null
    @SerializedName("episodeId")
    @Expose
    var episodeId: String? = null
    @SerializedName("imdbRating")
    var imdbRating: String? = null
    @SerializedName("duration")
    var duration: Long? = 0
    @SerializedName("trailerSteamUrls")
    var trailerSteamUrls: List<TrailerSteamUrlsItem>? = null
    @SerializedName("free")
    var free: Boolean = false
    @SerializedName("releaseYear")
    var releaseYear: String? = null
    @SerializedName("seasonId")
    @Expose
    var seasonId: String? = null
    @SerializedName("updatedAt")
    var updatedAt: String? = null
    @SerializedName("hd")
    var hd: Boolean = false
    @SerializedName("genres")
    var genres: Array<String>? = null
    @SerializedName("channelNo")
    var channelNo: String? = null
    @SerializedName("hotstar")
    var hotstar: Boolean = false
    @SerializedName("promotions")
    var promotions: ArrayList<PromotedChannel>? = null
    @SerializedName("segment")
    @Expose
    var segment: String? = null
    var pageId: String? = null
    var railId: String? = null
    @SerializedName("ageRating")
    var ageRating: String? = null
    @SerializedName("playStoreRating")
    var playStoreRating: String? = null
    @SerializedName("packageName")
    var packageName: String? = null
    @SerializedName("redirectionUrl")
    var redirectionUrl: String? = null
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Content

        if (id != other.id) return false
        if (programType != other.programType) return false
        if (title != other.title) return false
        if (images != other.images) return false
        if (cpId != other.cpId) return false
        if (shortUrl != other.shortUrl) return false
        if (refType != other.refType) return false
        if (languages != other.languages) return false
        if (description != other.description) return false
        if (seriesId != other.seriesId) return false
        if (channelId != other.channelId) return false
        if (episodeId != other.episodeId) return false
        if (imdbRating != other.imdbRating) return false
        if (duration != other.duration) return false
        if (trailerSteamUrls != other.trailerSteamUrls) return false
        if (free != other.free) return false
        if (releaseYear != other.releaseYear) return false
        if (seasonId != other.seasonId) return false
        if (updatedAt != other.updatedAt) return false
        if (hd != other.hd) return false
        if (!Arrays.equals(genres, other.genres)) return false
        if (channelNo != other.channelNo) return false
        if (hotstar != other.hotstar) return false
        if (promotions != other.promotions) return false
        if (pageId != other.pageId) return false
        if (ageRating != other.ageRating) return false
        if (playStoreRating != other.playStoreRating) return false
        if (packageName != other.packageName) return false
        if (segment != other.segment) return false
        if (redirectionUrl != other.redirectionUrl) return false

        return true
    }

    override fun hashCode(): Int {
        var result = id.hashCode()
        result = 31 * result + (programType?.hashCode() ?: 0)
        result = 31 * result + (title?.hashCode() ?: 0)
        result = 31 * result + (images?.hashCode() ?: 0)
        result = 31 * result + (cpId?.hashCode() ?: 0)
        result = 31 * result + (shortUrl?.hashCode() ?: 0)
        result = 31 * result + (refType?.hashCode() ?: 0)
        result = 31 * result + (languages?.hashCode() ?: 0)
        result = 31 * result + (description?.hashCode() ?: 0)
        result = 31 * result + (seriesId?.hashCode() ?: 0)
        result = 31 * result + (channelId?.hashCode() ?: 0)
        result = 31 * result + (episodeId?.hashCode() ?: 0)
        result = 31 * result + (imdbRating?.hashCode() ?: 0)
        result = 31 * result + (duration?.hashCode() ?: 0)
        result = 31 * result + (trailerSteamUrls?.hashCode() ?: 0)
        result = 31 * result + free.hashCode()
        result = 31 * result + (releaseYear?.hashCode() ?: 0)
        result = 31 * result + (seasonId?.hashCode() ?: 0)
        result = 31 * result + (updatedAt?.hashCode() ?: 0)
        result = 31 * result + hd.hashCode()
        result = 31 * result + (genres?.let { Arrays.hashCode(it) } ?: 0)
        result = 31 * result + (channelNo?.hashCode() ?: 0)
        result = 31 * result + hotstar.hashCode()
        result = 31 * result + (promotions?.hashCode() ?: 0)
        result = 31 * result + (pageId?.hashCode() ?: 0)
        result = 31 * result + (ageRating?.hashCode() ?: 0)
        result = 31 * result + (playStoreRating?.hashCode() ?: 0)
        result = 31 * result + (packageName?.hashCode() ?: 0)
        result = 31 * result + (segment?.hashCode() ?: 0)
        result = 31 * result + (redirectionUrl?.hashCode() ?: 0)
        return result
    }
}
