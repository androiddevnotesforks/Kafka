package tv.airtel.data.di

/**
 * Marks an activity / fragment injectable.
 */
interface Injectable
