package tv.airtel.data.model.content

import tv.airtel.data.model.layout.Meta
import java.io.Serializable


data class Rail (
    var meta: Meta? = null,
    var longTitle: String? = null,
    var description: String? = null,
    var longDescription: Array<String>? = null,
    var image: String? = null,
    var footerIcon: String? = null,
    var programId: String? = null,
    var programType: String? = null,
    var showAll: Boolean = false,
    var col: Int = 0,
    var row: Int = 0,
    var free: Boolean = false,
    var serialId: String? = null
): BaseRow(), Serializable
