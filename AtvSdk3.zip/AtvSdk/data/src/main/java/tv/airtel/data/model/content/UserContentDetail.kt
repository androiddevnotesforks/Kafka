package tv.airtel.data.model.content

import com.google.gson.annotations.SerializedName

data class UserContentDetail (

    @SerializedName("lastWatchedPosition")
    var lastWatchedPosition: Int = 0,

    @SerializedName("isFavorite")
    var isFavorite: Boolean = false

)