package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.manager.CPManager

/**
 * Author : Akash Gupta
 * Created On : 13/02/19
 *
 */
data class CpDetails(
        @SerializedName("cpStateMessage")
        @Expose
        var cpStateMessage: String? = null,

        @SerializedName("wcfExpiryCheck")
        @Expose
        var wcfExpiryCheck: Boolean = true,

        @SerializedName("loginState")
        @Expose
        var loginState: CurrentUser.LOGIN_STATE = CurrentUser.LOGIN_STATE.UNKNOWN,

        @SerializedName("cpId")
        @Expose
        var cpId: String? = null,

        @SerializedName("cpName")
        @Expose
        var cpName: String? = null,

        @SerializedName("cpExpiryCheck")
        @Expose
        var cpExpiryCheck: Boolean = true,

        @SerializedName("state")
        @Expose
        var state: CPManager.CPSubState = CPManager.CPSubState.CP_UNKNOWN,

        @SerializedName("title")
        @Expose
        var title: String,

        @SerializedName("type")
        @Expose
        var type: String = CPManager.CPType.UNKNOWN,

        @SerializedName("cpColor")
        @Expose
        var cpColor: String? = null,

        @SerializedName("cpDarkColor")
        @Expose
        var cpDarkColor: String? = null,

        @SerializedName("cpIcon")
        @Expose
        var cpIcon: String? = null,

        @SerializedName("redirectionUrl")
        @Expose
        var redirectionUrl: String? = null,

        @SerializedName("cpIconURL")
        @Expose
        var cpIconURL: String? = null
)