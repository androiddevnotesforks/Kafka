package tv.airtel.data.model.content

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import android.arch.persistence.room.TypeConverters
import androidx.annotation.NonNull
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.db.MiddlewareTypeConverters
import java.io.Serializable

//TODO: Remove serializable
@Entity
open class ContentDetail : Serializable, Cloneable {
    @SerializedName("createdAt")
    @Expose
    var createdAt: Long? = null

    @SerializedName("imdbRating")
    @Expose
    var imdbRating: String? = null
    @SerializedName("updatedAt")
    @Expose
    var updatedAt: Long? = null

    @SerializedName("updatedBy")
    @Expose
    var updatedBy: String? = null

    @SerializedName("programType")
    @Expose
    var programType: String? = null

    @NonNull
    @PrimaryKey
    @SerializedName("id")
    @Expose
    var id: String = ""

    @SerializedName("title")
    @Expose
    var title: String? = null

    @SerializedName("cpId")
    @Expose
    var cpId: String? = null

    @SerializedName("releaseYear")
    @Expose
    var releaseYear: String? = null

    @SerializedName("free")
    @Expose
    var free: Boolean? = null

    @SerializedName("credits")
    @Expose
    @TypeConverters(MiddlewareTypeConverters.CreditListTypeConverters::class)
    var credits: List<Credit>? = null

    @SerializedName("images")
    @Expose
    var images: ImagesApiModel? = null

    @SerializedName("hotstar")
    @Expose
    var hotstar: Boolean? = null

    @SerializedName("duration")
    @Expose
    var duration: Int? = null

    @SerializedName("description")
    @Expose
    var description: String? = null

    @SerializedName("contentState")
    @Expose
    var contentState: String? = null

    @SerializedName("refType")
    @Expose
    var refType: String? = null

    @SerializedName("trailerSteamUrls")
    @Expose
    var trailerSteamUrls: List<TrailerSteamUrl>? = null

    @SerializedName("languages")
    @Expose
    @TypeConverters(MiddlewareTypeConverters.StringListTypeConverters::class)
    var languages: List<String>? = null

    @SerializedName("shortUrl")
    @Expose
    var shortUrl: String? = null

    @SerializedName("hd")
    @Expose
    var hd: Boolean? = null

    @SerializedName("skpIn")
    @Expose
    var skpIn: Int? = null

    @SerializedName("genre")
    @Expose
    var genre: String? = null

    @SerializedName("genres")
    @Expose
    var genres: List<String>? = null

    @SerializedName("skpCr")
    @Expose
    var skpCr: Int? = null

    @SerializedName("ageRating")
    @Expose
    var ageRating: String? = null

    @SerializedName("playStoreRating")
    @Expose
    var playStoreRating: String? = null

    @SerializedName("packageName")
    @Expose
    var packageName: String? = null
    @SerializedName("seriesId")
    @Expose
    var seriesId: String? = null
    @ColumnInfo(name = "season_id")
    @SerializedName("seasonId")
    var seasonId: String? = null
    @SerializedName("episodeNum")
    var episodeNum: Int? = null
    @SerializedName("isFavorite")
    @ColumnInfo(name = "isFavorite")
    var isFavorite: Boolean? = null
    @SerializedName("shouldResume")
    var shouldResume: Boolean = false
    @SerializedName("lastWatchedPosition")
    var lastWatchedPosition = -1
    @SerializedName("segment")
    @Expose
    var segment: String? = null

    public override fun clone(): Any {
        return super.clone()
    }
}
