package tv.airtel.data.domainmodule.util;

public enum RowType {
    CARD,
    BANNER,
    RAIL,
    UNKNOWN
    }
