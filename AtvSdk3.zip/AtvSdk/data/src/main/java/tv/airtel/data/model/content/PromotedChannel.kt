package tv.airtel.data.model.content

import com.google.gson.annotations.SerializedName

data class PromotedChannel(
        @SerializedName("startTime")
        var startTime: Long = 0,
        @SerializedName("endTime")
        var endTime: Long = 0,
        @SerializedName("channelId")
        var channelId: String? = null
)
