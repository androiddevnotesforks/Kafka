package tv.airtel.data.model.content

import java.util.*

data class RowItemContent (
    var id: String? = null,
    var title: String? = null,
    var images: ImagesApiModel? = null,
    var contentType: String? = null,
    var cpId: String? = null,
    var isFreeContent: Boolean = false,
    var description: String? = null,
    var languages: List<String>? = null,
    var imdbRating: String? = null,
    var duration: Long = 0,         // not coming right now used in making subtext in related call
    var releaseYear: String = "0",
    var shortUrl: String? = null,
    var refType: String? = null,
    var updatedAt: String? = null,
    var hd: Boolean = false,
    var genres: Array<String>? = null,
    var channelId: String? = null,
    var hotstar: Boolean = false,
    var seasonId: String? = null,
    var seriesId: String? = null,
    var promotions: ArrayList<PromotedChannelContent>? = null,

    var contentTrailerInfoList: List<ContentTrailerInfo>? = null
)