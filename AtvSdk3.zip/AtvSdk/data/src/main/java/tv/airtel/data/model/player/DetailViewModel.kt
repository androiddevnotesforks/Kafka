package tv.airtel.data.model.player

import tv.airtel.data.model.content.ContentTrailerInfo
import tv.airtel.data.model.content.ImagesApiModel
import tv.airtel.data.model.layout.BackendType
import tv.airtel.util.util.ContentConstants
import java.io.Serializable

data class DetailViewModel(

        var id: String? = "",
        var title: String? = null,
        var images: ImagesApiModel? = null,
        var contentType: String? = "",
        var cpId: String? = "",
        var isFreeContent: Boolean = false,
        var description: String? = null,
        var imdbRating: String? = null,
        var duration: Long? = 0,         // not coming right now used in making subtext in related call
        var releaseYear: String? = "0",
        var contentTrailerInfoList: List<ContentTrailerInfo>? = null,
        var playList: List<PlayBillList>? = null,
        var seriesId: String? = null,
        var channelId: String? = null,
        var episodeId: String? = null,
        var backendType: BackendType? = BackendType.BE,

        var lastPlayTime: Int = 0,

        var trailerUrl: String? = null,

        var isStarChannel: Boolean = false,
        var seasonId: String? = null,
        var skipIntro: Int? = 0, // skip time
        var skipCredits: Int? = 0, // next time
        var isNextAvailable: Boolean = false,
        var nextTitle: String? = null,
        var currentTitle: String? = null,
        var currentEpisodeReleaseTime: String? = null) : Serializable {


    fun isTvShow(): Boolean {
        return ContentConstants.ContentType.TVSHOW.equals(contentType, true) || ContentConstants.ContentType.SERIES.equals(contentType, true)
    }

    fun isMovie(): Boolean {
        return ContentConstants.ContentType.MOVIE.equals(contentType, true)
    }

    fun isVideo(): Boolean {
        return ContentConstants.ContentType.VIDEO.equals(contentType, true)
    }

    fun isOther(): Boolean {
        return ContentConstants.ContentType.OTHER.equals(contentType, true)
    }

    fun isEpisode(): Boolean {
        return ContentConstants.ContentType.EPISODE.equals(contentType, true)
    }

    fun isLiveTvChannel(): Boolean {
        return ContentConstants.ContentType.LIVETVCHANNEL.equals(contentType, true)
    }

    fun isLiveTvShow(): Boolean {
        return ContentConstants.ContentType.LIVETVSHOW.equals(contentType, true)
    }

    fun isLiveTvMovie(): Boolean {
        return ContentConstants.ContentType.LIVETVMOVIE.equals(contentType, true)
    }

    fun isSports(): Boolean {
        return ContentConstants.ContentType.SPORTS.equals(contentType, true)
    }

    fun isHotStar(): Boolean {
        //TODo move to constants
        if (cpId.equals("HOTSTAR", true)) {
            return true
        }
        if (channelId != null) {
            //TODO livetv pending
//          val liveTvChannel: LiveTvChannel? = EPGDataManager.getInstance().getChannel(channelId)
//            if(liveTvChannel!=null){
//                return liveTvChannel.isStarChannel
//            }
            return false
        }
        return false
    }

    override fun toString(): String {
        return "DetailViewModel(id=$id, title=$title, images=$images, contentType=$contentType, cpId='$cpId', isFreeContent=$isFreeContent, description=$description, imdbRating=$imdbRating, duration=$duration, releaseYear=$releaseYear, contentTrailerInfoList=$contentTrailerInfoList, playList=$playList, seriesId=$seriesId, channelId=$channelId, episodeId=$episodeId backendType=$backendType)"
    }

    var showId: String? = null

    fun isHuaweiContent(): Boolean {
        return ContentConstants.HUAWEI.equals(cpId, true)
    }

    fun isMwtvContent(): Boolean {
        return ContentConstants.MWTV.equals(cpId, true)
    }

    fun isTvPromo(): Boolean {
        return ContentConstants.TVPROMO.equals(cpId, true)
    }

    fun isHD(): Boolean {
//        val channel: LiveTvChannel? = EPGDataManager.getInstance().getChannel(channelId)
//         return channel?.isHD ?: false
        return false;
    }

    fun isLive(): Boolean {
        return ContentConstants.ContentType.LIVE.equals(contentType, true) || ContentConstants.ContentType.LIVETV.equals(contentType, true)
    }

    fun isCatchupMovie(): Boolean {
        return isHuaweiContent() && ContentConstants.ContentType.MOVIE.equals(playList?.get(0)?.programType, true)
    }
}


