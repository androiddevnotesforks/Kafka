package tv.airtel.data.model.content

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity
data class ContentEntity (
    @PrimaryKey
    @SerializedName("id")
    var id: String = "",
    @SerializedName("title")
    var title: String? = null,
    @SerializedName("images")
    var images: ImagesApiModel? = null,
    @SerializedName("content")
    var content: List<Content> = arrayListOf(),
    @SerializedName("more")
    var more: Boolean = false,
    @SerializedName("totalContentCount")
    var totalContentCount: Int = 0
)
