package tv.airtel.data.model.content

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.Expose

@Entity
data class ContentEntityMap (

    @Expose
    @field:PrimaryKey
    var pageId: String = "",

    var map: HashMap<String, ContentEntity> = hashMapOf()
)