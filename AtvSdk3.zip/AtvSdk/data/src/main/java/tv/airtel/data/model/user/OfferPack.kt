package tv.airtel.data.model.user

data class OfferPack(
    var id: String? = null,
    var partnerProductId: String? = null,
    var title: String? = null,
    var description: String? = null,
    var cpName: String? = null,
    var action: String? = null
)