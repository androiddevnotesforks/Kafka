package tv.airtel.data.model.user.profile

import com.google.gson.annotations.SerializedName

data class UserProfile(
        @field:SerializedName("img")
        val img: String?,

        @field:SerializedName("devices")
        val devices: List<String?>?,

        @field:SerializedName("name")
        val name: String?,

        @field:SerializedName("id")
        var id: String = "",

        @field:SerializedName("passCode")
        val passCode: String?,

        @field:SerializedName("master")
        val isMaster: Boolean?
)
