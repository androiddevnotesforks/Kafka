package tv.airtel.data.model.user

data class Faq(
    val category: String,
    val faq: String,
    val id: Int,
    val resolution: String
)