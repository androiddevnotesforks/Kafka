package tv.airtel.data.model.layout

/**
 * Created by Udit on 19/09/17.
 *
 */
enum class RowSubType private constructor(val type: RowType) {

    CONTINUE_WATCHING(RowType.RAIL),
    WATCHLIST(RowType.RAIL),
    APPS_GAMES(RowType.RAIL),
    TVSHOW_LOGO_43(RowType.RAIL),
    TVSHOW_NOLOGO_43(RowType.RAIL),
    TVSHOW_LOGO_169(RowType.RAIL),
    TVSHOW_NOLOGO_169(RowType.RAIL),
    TVSHOW_BIG_43(RowType.RAIL),
    CHANNEL(RowType.RAIL),
    EMPTY_STATE(RowType.RAIL),
    HEADER(RowType.RAIL),
    FOOTER(RowType.RAIL),
    MOVIE_LOGO(RowType.RAIL),
    MOVIE_NOLOGO(RowType.RAIL),
    BANNER(RowType.BANNER),
    CARD_TITLE_169(RowType.CARD),
    CARD_NOTITILE_169(RowType.CARD),
    UNKNOWN(RowType.UNKNOWN),
    MOVIE(RowType.RAIL),
    TV_SHOWS(RowType.RAIL),
    VIDEO(RowType.RAIL),
    PEOPLE(RowType.RAIL),
    SPORTS(RowType.RAIL),
    SONG_RAIL(RowType.RAIL),
    PLAYLIST_RAIL(RowType.RAIL),
    PRODUCT_CARD(RowType.CARD),
    LIVE_TV_RAIL(RowType.RAIL),
    ARTIST_RAIL(RowType.RAIL)
}

