package tv.airtel.data.repo;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.mockito.Mockito;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;

import okhttp3.MediaType;
import okhttp3.ResponseBody;
import retrofit2.Response;
import tv.airtel.data.api.model.ApiResponse;
import tv.airtel.data.api.model.AppExecutors;
import tv.airtel.data.api.model.Error;
import tv.airtel.data.api.model.Resource;
import tv.airtel.data.livedata.NetworkBoundResource;
import tv.airtel.data.util.ApiTestUtil;
import tv.airtel.data.util.CountingAppExecutors;
import tv.airtel.data.util.InstantAppExecutors;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static tv.airtel.data.api.model.ErrorKt.RESOLUTION_PLEASE_RETRY;

/**
 * Created by VipulKumar on 04/05/18.
 */
@RunWith(Parameterized.class)
public class NetworkBoundResourceTest {
    @Rule
    public InstantTaskExecutorRule instantExecutorRule = new InstantTaskExecutorRule();
    private Function<Foo, Void> saveCallResult;
    private Function<Foo, Boolean> shouldFetch;
    private Function<Void, LiveData<ApiResponse<Foo>>> createCall;
    private MutableLiveData<Foo> dbData = new MutableLiveData<>();
    private NetworkBoundResource<Foo, Foo> networkBoundResource;

    private AtomicBoolean fetchedOnce = new AtomicBoolean(false);
    private CountingAppExecutors countingAppExecutors;
    private final boolean useRealExecutors;

    @Parameterized.Parameters
    public static List<Boolean> param() {
        return Arrays.asList(true, false);
    }

    public NetworkBoundResourceTest(boolean useRealExecutors) {
        this.useRealExecutors = useRealExecutors;
        if (useRealExecutors) {
            countingAppExecutors = new CountingAppExecutors();
        }
    }

    @Before
    public void init() {
        AppExecutors appExecutors = useRealExecutors
                ? countingAppExecutors.getAppExecutors()
                : new InstantAppExecutors();
        networkBoundResource = new NetworkBoundResource<Foo, Foo>(appExecutors) {
            @Override
            protected void saveCallResult(@NonNull Foo item) {
                saveCallResult.apply(item);
            }

            @Override
            protected boolean shouldFetch(@Nullable Foo data) {
                // since test methods don't handle repetitive fetching, call it only once
                return shouldFetch.apply(data) && fetchedOnce.compareAndSet(false, true);
            }

            @NonNull
            @Override
            protected LiveData<Foo> loadFromDb() {
                return dbData;
            }

            @NonNull
            @Override
            protected LiveData<ApiResponse<Foo>> createCall() {
                return createCall.apply(null);
            }
        };
    }

    private void drain() {
        if (!useRealExecutors) {
            return;
        }
        try {
            countingAppExecutors.drainTasks(1, TimeUnit.SECONDS);
        } catch (Throwable t) {
            throw new AssertionError(t);
        }
    }

    @Test
    public void basicFromNetwork() {
        final AtomicReference<Foo> saved = new AtomicReference<>();
        shouldFetch = new Function<Foo, Boolean>() {
            @Override
            public Boolean apply(Foo obj) {
                return Objects.isNull(obj);
            }
        };
        final Foo fetchedDbValue = new Foo(1);
        saveCallResult = new Function<Foo, Void>() {
            @Override
            public Void apply(Foo foo) {
                saved.set(foo);
                dbData.setValue(fetchedDbValue);
                return null;
            }
        };
        final Foo networkResult = new Foo(1);
        createCall = new Function<Void, LiveData<ApiResponse<Foo>>>() {
            @Override
            public LiveData<ApiResponse<Foo>> apply(Void aVoid) {
                return ApiTestUtil.createCall(Response.success(networkResult));
            }
        };

        Observer<Resource<Foo>> observer = Mockito.mock(Observer.class);
        networkBoundResource.asLiveData().observeForever(observer);
        drain();
        verify(observer).onChanged(Resource.Companion.<Foo>loading(null));
        reset(observer);
        dbData.setValue(null);
        drain();
        assertThat(saved.get(), is(networkResult));
        verify(observer).onChanged(Resource.Companion.<Foo>success(fetchedDbValue));
    }

    @Test
    public void failureFromNetwork() {
        final AtomicBoolean saved = new AtomicBoolean(false);
        shouldFetch = new Function<Foo, Boolean>() {
            @Override
            public Boolean apply(Foo obj) {
                return Objects.isNull(obj);
            }
        };
        saveCallResult = new Function<Foo, Void>() {
            @Override
            public Void apply(Foo foo) {
                saved.set(true);
                return null;
            }
        };

        final ResponseBody body = ResponseBody.create(MediaType.parse("text/html"), "error");

        createCall = new Function<Void, LiveData<ApiResponse<Foo>>>() {
            @Override
            public LiveData<ApiResponse<Foo>> apply(Void aVoid) {
                return ApiTestUtil.createCall(Response.<Foo>error(500, body));
            }
        };

        Observer<Resource<Foo>> observer = Mockito.mock(Observer.class);
        networkBoundResource.asLiveData().observeForever(observer);
        drain();
        verify(observer).onChanged(Resource.Companion.<Foo>loading(null));
        reset(observer);
        dbData.setValue(null);
        drain();
        assertThat(saved.get(), is(false));
        verify(observer).onChanged(Resource.Companion.<Foo>error(buildNetworkError(), null));
        verifyNoMoreInteractions(observer);
    }

    @Test
    public void dbSuccessWithoutNetwork() {
        final AtomicBoolean saved = new AtomicBoolean(false);
        shouldFetch = new Function<Foo, Boolean>() {
            @Override
            public Boolean apply(Foo obj) {
                return Objects.isNull(obj);
            }
        };
        saveCallResult = new Function<Foo, Void>() {
            @Override
            public Void apply(Foo foo) {
                saved.set(true);
                return null;
            }
        };

        Observer<Resource<Foo>> observer = Mockito.mock(Observer.class);
        networkBoundResource.asLiveData().observeForever(observer);
        drain();
        verify(observer).onChanged(Resource.Companion.<Foo>loading(null));
        reset(observer);
        Foo dbFoo = new Foo(1);
        dbData.setValue(dbFoo);
        drain();
        verify(observer).onChanged(Resource.Companion.<Foo>success(dbFoo));
        assertThat(saved.get(), is(false));
        Foo dbFoo2 = new Foo(2);
        dbData.setValue(dbFoo2);
        drain();
        verify(observer).onChanged(Resource.Companion.<Foo>success(dbFoo2));
        verifyNoMoreInteractions(observer);
    }

    @Test
    public void dbSuccessWithFetchFailure() {
        final Foo dbValue = new Foo(1);
        final AtomicBoolean saved = new AtomicBoolean(false);
        shouldFetch = new Function<Foo, Boolean>() {
            @Override
            public Boolean apply(Foo foo) {
                return foo == dbValue;
            }
        };
        saveCallResult = new Function<Foo, Void>() {
            @Override
            public Void apply(Foo foo) {
                saved.set(true);
                return null;
            }
        };
        ResponseBody body = ResponseBody.create(MediaType.parse("text/html"), "error");
        final MutableLiveData<ApiResponse<Foo>> apiResponseLiveData = new MutableLiveData();
        createCall = new Function<Void, LiveData<ApiResponse<Foo>>>() {
            @Override
            public LiveData<ApiResponse<Foo>> apply(Void aVoid) {
                return apiResponseLiveData;
            }
        };

        Observer<Resource<Foo>> observer = Mockito.mock(Observer.class);
        networkBoundResource.asLiveData().observeForever(observer);
        drain();
        verify(observer).onChanged(Resource.Companion.<Foo>loading(null));
        reset(observer);

        dbData.setValue(dbValue);
        drain();
        verify(observer).onChanged(Resource.Companion.<Foo>loading(dbValue));

        apiResponseLiveData.setValue(new ApiResponse<Foo>(Response.<Foo>error(400, body)));
        drain();
        assertThat(saved.get(), is(false));
        verify(observer).onChanged(Resource.Companion.<Foo>error(buildNetworkError(), dbValue));

        Foo dbValue2 = new Foo(2);
        dbData.setValue(dbValue2);
        drain();
        verify(observer).onChanged(Resource.Companion.<Foo>error(buildNetworkError(), dbValue2));
        verifyNoMoreInteractions(observer);
    }

    @Test
    public void dbSuccessWithReFetchSuccess() {
        final Foo dbValue = new Foo(1);
        final Foo dbValue2 = new Foo(2);
        final AtomicReference<Foo> saved = new AtomicReference<>();
        shouldFetch = new Function<Foo, Boolean>() {
            @Override
            public Boolean apply(Foo foo) {
                return foo == dbValue;
            }
        };
        saveCallResult = new Function<Foo, Void>() {
            @Override
            public Void apply(Foo foo) {
                saved.set(foo);
                dbData.setValue(dbValue2);
                return null;
            }
        };
        final MutableLiveData<ApiResponse<Foo>> apiResponseLiveData = new MutableLiveData();
        createCall = new Function<Void, LiveData<ApiResponse<Foo>>>() {
            @Override
            public LiveData<ApiResponse<Foo>> apply(Void aVoid) {
                return apiResponseLiveData;
            }
        };

        Observer<Resource<Foo>> observer = Mockito.mock(Observer.class);
        networkBoundResource.asLiveData().observeForever(observer);
        drain();
        verify(observer).onChanged(Resource.Companion.<Foo>loading(null));
        reset(observer);

        dbData.setValue(dbValue);
        drain();
        final Foo networkResult = new Foo(1);
        verify(observer).onChanged(Resource.Companion.<Foo>loading(dbValue));
        apiResponseLiveData.setValue(new ApiResponse<>(Response.success(networkResult)));
        drain();
        assertThat(saved.get(), is(networkResult));
        verify(observer).onChanged(Resource.Companion.<Foo>success(dbValue2));
        verifyNoMoreInteractions(observer);
    }

    static Error buildNetworkError() {
        return Error.Companion.build(Error.ErrorValue.ERROR_NETWORK_ERROR, 500, "error", RESOLUTION_PLEASE_RETRY);
    }

    static class Foo {
        int value;
        Foo(int value) {
            this.value = value;
        }
    }
}
