package com.airtel.vision.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.airtel.vision.AtvSdk
import com.airtel.vision.livedata.WiseLiveData
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.model.player.PlaybackResponse
import tv.airtel.data.repo.PlaybackRepository
import javax.inject.Inject
import javax.inject.Singleton

/**
 * @author Vipul Kumar; dated 22/10/18.
 */
@Singleton
internal class PlaybackViewModel @Inject
constructor(private val playbackRepository: PlaybackRepository) : BaseViewModel() {

    private var playbackResponseForNonIngestedContent: WiseLiveData<Resource<PlaybackResponse>> =
        WiseLiveData.create()
    private var playbackForNonIngestedContent: LiveData<Resource<PlaybackResponse>>
    private val triggerForNonIngestedContent = MutableLiveData<NonIngestedTrigger>()

    init {
        playbackForNonIngestedContent = Transformations.switchMap(triggerForNonIngestedContent) {
            if (it != null) {
                playbackRepository
                    .getPlaybackResponseForNonIngestedContent(it.contentId, it.cp,
                            AtvSdk.getInstance().application, it.customerType ?:"")
            } else {
                WiseLiveData.create<Resource<PlaybackResponse>>()
            }
        }
        initContentDetailResponse()
    }

    private fun initContentDetailResponse() {
        playbackResponseForNonIngestedContent.addSource(playbackForNonIngestedContent) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> playbackResponseForNonIngestedContent.dispatchSuccess(resource)
                Status.LOADING -> playbackResponseForNonIngestedContent.dispatchLoading(resource)
                Status.ERROR -> playbackResponseForNonIngestedContent.dispatchError(resource)
            }
        }
    }

    fun fetchPlaybackResponse(
        contentId: String,
        cp: String?
    ): WiseLiveData<Resource<PlaybackResponse>> {
        triggerForNonIngestedContent.value = NonIngestedTrigger(contentId, cp, AtvSdk.getInstance().getCurrentUser()?.customerType)
        return playbackResponseForNonIngestedContent
    }

    data class NonIngestedTrigger(var contentId: String, var cp: String?, var customerType: String?)
}
