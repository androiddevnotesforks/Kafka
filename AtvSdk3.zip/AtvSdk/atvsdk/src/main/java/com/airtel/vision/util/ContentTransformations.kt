package com.airtel.vision.util

import tv.airtel.data.model.Recents
import tv.airtel.data.model.content.BaseRow
import tv.airtel.data.model.content.Card
import tv.airtel.data.model.content.Content
import tv.airtel.data.model.content.ContentDetail
import tv.airtel.data.model.content.ContentEntity
import tv.airtel.data.model.content.ContentTrailerInfo
import tv.airtel.data.model.content.Rail
import tv.airtel.data.model.content.RecentlyWatched
import tv.airtel.data.model.content.TrailerSteamUrlsItem
import tv.airtel.data.model.content.recentfavorite.Favorites
import tv.airtel.data.model.content.recentfavorite.RecentContentDetails
import tv.airtel.data.model.content.recentfavorite.RecentFavoriteEntity
import tv.airtel.data.model.content.recentfavorite.RecentFavouriteItem
import tv.airtel.data.model.layout.BackendType
import tv.airtel.data.model.layout.Banner
import tv.airtel.data.model.layout.LayoutEntity
import tv.airtel.data.model.layout.RowSubType
import tv.airtel.data.model.layout.RowType
import tv.airtel.data.model.player.DetailViewModel

/**
 * This class provides methods to transform
 * content list json responses model into adapter models
 * Created by Aditya Mehta on 04/04/18.
 */
object ContentTransformations {

    internal fun transformLayoutAPISuccessEntity(entities: List<LayoutEntity>?): List<BaseRow> {
        val baseRowList = ArrayList<BaseRow>()

        if (entities != null && entities.isNotEmpty()) {
            for (layoutEntity in entities) {
                if (layoutEntity.layoutFormat != null) {
                    val subType: RowSubType = try {
                        RowSubType.valueOf(layoutEntity.layoutFormat!!.type)
                    } catch (e: IllegalArgumentException) {
                        //unknown enum type, ignore this rail
                        RowSubType.UNKNOWN
                    }

                    var row: BaseRow? = null
                    when (subType.type) {
                        RowType.CARD -> {
                            val card = Card()
                            card.id = layoutEntity.id
                            card.type = subType.type
                            card.cardDescription = layoutEntity.layoutFormat?.description
                            card.cardImageUrl = layoutEntity.layoutFormat?.image
                            card.title = layoutEntity.layoutFormat?.railTitle

                            card.footerIconUrl = layoutEntity.layoutFormat?.footerIcon
                            card.longTitle = layoutEntity.layoutFormat?.longTitle
                            card.headerIconUrl = layoutEntity.layoutFormat?.headerIcon
                            card.programId = layoutEntity.layoutFormat?.programId
                            card.programType = layoutEntity.layoutFormat?.programType
                            card.seriesId = layoutEntity.layoutFormat?.seriesId
                            card.longDescription = layoutEntity.layoutFormat?.longDescription
                            card.subType = subType
                            card.more = layoutEntity.layoutFormat?.moreAction
                            card.meta = layoutEntity.layoutFormat?.moreAction?.meta

                            card.contentProgramId = layoutEntity.layoutFormat?.contentProgramId
                            row = card
                        }
                        RowType.BANNER -> {
                            val banner = Banner()
                            banner.id = layoutEntity.id
                            banner.type = subType.type
                            banner.subType = subType
                            if (layoutEntity.contents != null && layoutEntity.contents!!.isNotEmpty()) {
                                banner.backendType =
                                        getBackendType(layoutEntity.contents!![0].source)
                                banner.contentType = layoutEntity.contents!![0].type
                                banner.totalCount = layoutEntity.contents?.get(0)!!.pageSize
                            }
                            banner.layoutContents = layoutEntity.contents
                            banner.more = layoutEntity.layoutFormat!!.moreAction
                            row = banner
                        }
                        RowType.RAIL -> {
                            val rail = Rail()
                            rail.id = layoutEntity.id
                            rail.type = subType.type
                            rail.layoutContents = layoutEntity.contents
                            rail.subType = subType
                            rail.description = layoutEntity.layoutFormat!!.description
                            rail.image = layoutEntity.layoutFormat!!.image
                            rail.title = layoutEntity.layoutFormat!!.railTitle
                            if (layoutEntity.contents != null && layoutEntity.contents?.isNotEmpty()!!) {
                                rail.backendType =
                                        getBackendType(layoutEntity.contents?.get(0)!!.source)
                                rail.contentType = layoutEntity.contents!![0].type
                                rail.totalCount = layoutEntity.contents!![0].pageSize
                            }
                            rail.footerIcon = layoutEntity.layoutFormat!!.footerIcon
                            rail.longTitle = layoutEntity.layoutFormat!!.longTitle
                            rail.headerIconUrl = layoutEntity.layoutFormat!!.headerIcon
                            rail.programId = layoutEntity.layoutFormat!!.programId
                            rail.programType = layoutEntity.layoutFormat!!.programType
                            rail.serialId = layoutEntity.layoutFormat!!.seriesId
                            rail.longDescription = layoutEntity.layoutFormat!!.longDescription
                            rail.more = layoutEntity.layoutFormat!!.moreAction
                            rail.meta = layoutEntity.layoutFormat!!.meta
                            rail.showAll = layoutEntity.layoutFormat!!.showAll
                            rail.col = layoutEntity.layoutFormat!!.col
                            rail.more = layoutEntity.layoutFormat!!.moreAction
                            rail.row = layoutEntity.layoutFormat!!.row
                            row = rail
                        }
                        else -> {
                        }
                    }
                    //filter based on backend type
                    if (row is Card) {
                        if (row.more?.backendType == BackendType.BE) {
                            baseRowList.add(row)
                        }
                    } else if (row != null) {
                        if (row.backendType == BackendType.BE
                            || row.backendType == BackendType.MW
                            || row.backendType == BackendType.MUSIC
                            || row.type == RowType.BANNER
                        ) {
                            baseRowList.add(row)
                        } else if (row.subType == RowSubType.CONTINUE_WATCHING
                                || row.subType == RowSubType.WATCHLIST
                                || row.subType == RowSubType.APPS_GAMES
                        ) {
                            baseRowList.add(row)
                        }
                    }
                }
            }
        }
        return baseRowList
    }

    private fun getBackendType(source: String): BackendType {
        return try {
            BackendType.valueOf(source)
        } catch (e: Exception) {
            BackendType.BE
        }
    }


    fun transformGetRecentFavoriteWatched(recents: List<RecentFavoriteEntity>?): ContentEntity {
        val contentEntity = ContentEntity()

        val list = ArrayList<Content>()
        if (recents != null) {
            for (recent in recents) {
                val rowItemContent = RecentlyWatched()
                rowItemContent.id = recent.contentDetails?.id!!
                rowItemContent.programType = recent.contentDetails?.programType
                rowItemContent.cpId = recent.contentDetails?.cpId
                rowItemContent.description = recent.contentDetails?.description
                rowItemContent.lastWatchedPosition = recent.lastWatchedPosition.toInt()
                rowItemContent.title = recent.contentDetails?.title
                rowItemContent.images = recent.contentDetails?.images
                rowItemContent.seasonId = recent.contentDetails?.seasonId
                rowItemContent.seriesId = recent.contentDetails?.seriesId
                rowItemContent.duration = recent.contentDetails?.duration?.toLong()
                list.add(rowItemContent)
            }
        }
        contentEntity.content = list
        return contentEntity
    }

    fun transformToDetailViewModel(content: Content): DetailViewModel {
        val detailViewModel = DetailViewModel()
        detailViewModel.cpId = content.cpId
        detailViewModel.contentTrailerInfoList = transContentTrailerInfo(content.trailerSteamUrls)
        detailViewModel.contentType = content.programType
        detailViewModel.description = content.description
        detailViewModel.duration = content.duration
        detailViewModel.id = content.id
        detailViewModel.title = content.title
        detailViewModel.imdbRating = content.imdbRating
        detailViewModel.images = content.images
        detailViewModel.isFreeContent = content.free
        detailViewModel.releaseYear = content.releaseYear
        detailViewModel.backendType = BackendType.BE
        return detailViewModel
    }

    //TODO: double check transformations
    fun transformToDetailViewModel(contentDetail: ContentDetail): DetailViewModel {
        val detailViewModel = DetailViewModel()
        detailViewModel.id = contentDetail.id
        detailViewModel.images = contentDetail.images
        detailViewModel.title = contentDetail.title
        detailViewModel.description = contentDetail.description
        detailViewModel.cpId = contentDetail.cpId
        detailViewModel.contentType = contentDetail.programType
        detailViewModel.releaseYear = contentDetail.releaseYear
        detailViewModel.backendType = BackendType.BE
        detailViewModel.lastPlayTime = contentDetail.lastWatchedPosition
        return detailViewModel
    }

    fun transContentTrailerInfo(list: List<TrailerSteamUrlsItem>?): List<ContentTrailerInfo> {
        val contentTrailerInfos = java.util.ArrayList<ContentTrailerInfo>()
        if (list != null) {
            for (item in list) {
                val info = ContentTrailerInfo()
                info.type = item.type
                info.url = item.url
                contentTrailerInfos.add(info)
            }
        }
        return contentTrailerInfos
    }

    fun transformToFavorites(
        addFavList: List<RecentFavoriteEntity>,
        removeFavList: List<RecentFavoriteEntity>
    ): Favorites {
        val favorite = Favorites()
        val addFavoriteList = mutableListOf<RecentFavouriteItem>()
        val removeFavoriteList = mutableListOf<RecentFavouriteItem>()

        for (model in addFavList) {
            val recentFavouriteItem = RecentFavouriteItem()
            recentFavouriteItem.contentId = model._id
            recentFavouriteItem.lastUpdatedTimeStamp = model.lastUpdatedTimeStamp
            addFavoriteList.add(recentFavouriteItem)
        }
        for (model in removeFavList) {
            val recentFavouriteItem = RecentFavouriteItem()
            recentFavouriteItem.contentId = model._id
            recentFavouriteItem.lastUpdatedTimeStamp = model.lastUpdatedTimeStamp
            removeFavoriteList.add(recentFavouriteItem)
        }
        favorite.add = addFavoriteList
        favorite.remove = removeFavoriteList
        return favorite
    }

    fun transformToRecents(
        addList: List<RecentFavoriteEntity>,
        removeList: List<RecentFavoriteEntity>
    ): Recents {
        val recent = Recents()
        val addRecentList = mutableListOf<RecentFavouriteItem>()
        val removeRecentList = mutableListOf<RecentFavouriteItem>()

        for (model in addList) {
            val recentFavouriteItem = RecentFavouriteItem()
            recentFavouriteItem.contentId = model._id
            recentFavouriteItem.lastUpdatedTimeStamp = model.lastUpdatedTimeStamp
            recentFavouriteItem.lastWatchedPosition = model.lastWatchedPosition.toInt()
            addRecentList.add(recentFavouriteItem)
        }
        for (model in removeList) {
            val recentFavouriteItem = RecentFavouriteItem()
            recentFavouriteItem.contentId = model._id
            recentFavouriteItem.lastUpdatedTimeStamp = model.lastUpdatedTimeStamp
            recentFavouriteItem.lastWatchedPosition = model.lastWatchedPosition.toInt()
            removeRecentList.add(recentFavouriteItem)
        }
        recent.add = addRecentList
        recent.remove = removeRecentList
        return recent
    }

    fun transformRecentContentDetails(contentDetails: ContentDetail, episodeNo: Int = 0,tvShowName:String? = null, seasonNo:Int? = null): RecentContentDetails {
        val tempContentDetails = RecentContentDetails()
        tempContentDetails.id = contentDetails.id
//        tempContentDetails.channelId = contentDetails.channelId
        tempContentDetails.cpId = contentDetails.cpId
//        tempContentDetails.seasonId = contentDetails.seasonId
        tempContentDetails.seriesId = contentDetails.seriesId
        tempContentDetails.seasonId = contentDetails.seasonId
        tempContentDetails.description = contentDetails.description
        tempContentDetails.genre = contentDetails.genre
        tempContentDetails.imdbRating = contentDetails.imdbRating
        tempContentDetails.programType = contentDetails.programType
        tempContentDetails.refType = contentDetails.refType
        tempContentDetails.releaseYear = contentDetails.releaseYear
        tempContentDetails.shortUrl = contentDetails.shortUrl
        tempContentDetails.credits = contentDetails.credits
        tempContentDetails.duration = contentDetails.duration
        tempContentDetails.free = contentDetails.free == true
        tempContentDetails.images = contentDetails.images
        tempContentDetails.tvShowName = tvShowName
        tempContentDetails.episodeSeasonNum = seasonNo
//        tempContentDetails.isHotStar = contentDetails.isHotStar
//        tempContentDetails.skipCredits = contentDetails.skipCredits
//        tempContentDetails.skipIntro = contentDetails.skipIntro
//        tempContentDetails.startTime = contentDetails.startTime
        tempContentDetails.title = contentDetails.title
        tempContentDetails.episodeNumber = episodeNo

        tempContentDetails.segment = contentDetails.segment
//        tempContentDetails.trailerSteamUrls = contentDetails.contentTrailerInfoList
        return tempContentDetails
    }
}
