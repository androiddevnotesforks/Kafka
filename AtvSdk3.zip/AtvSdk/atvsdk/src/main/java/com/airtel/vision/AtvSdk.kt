package com.airtel.vision

import android.annotation.SuppressLint
import android.app.Application
import android.app.Service
import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import android.arch.persistence.db.SimpleSQLiteQuery
import android.support.annotation.DrawableRes
import com.airtel.vision.analytics.AnalyticsUtil
import com.airtel.vision.analytics.AtvAnalytics
import com.airtel.vision.di.DaggerInjector
import com.airtel.vision.livedata.WiseLiveData
import com.airtel.vision.manager.RecentSyncManager
import com.airtel.vision.util.NoArgSingletonHolder
import com.airtel.vision.viewmodel.AppViewModel
import com.airtel.vision.viewmodel.ConfigViewModel
import com.airtel.vision.viewmodel.ContentDetailViewModel
import com.airtel.vision.viewmodel.ContentListViewModel
import com.airtel.vision.viewmodel.PlaybackViewModel
import com.airtel.vision.viewmodel.ProfileViewModel
import com.airtel.vision.viewmodel.RecentFavoriteViewModel
import com.airtel.vision.viewmodel.SearchViewModel
import com.airtel.vision.viewmodel.UserViewModel
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasServiceInjector
import tv.accedo.airtel.wynk.domain.firebase.util.ConfigUtils
import tv.airtel.data.domainmodule.util.CrashlyticsUtil
import tv.airtel.data.api.model.AppExecutors
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.db.MiddlewareDb
import tv.airtel.data.error.ErrorCodes
import tv.airtel.data.model.AppUpdateEntity
import tv.airtel.data.model.PeopleProfile
import tv.airtel.data.model.ResultEntity
import tv.airtel.data.model.content.BaseRow
import tv.airtel.data.model.content.ClearHistoryResponse
import tv.airtel.data.model.content.Content
import tv.airtel.data.model.content.ContentDetail
import tv.airtel.data.model.content.ContentEntity
import tv.airtel.data.model.content.ContentEntityMap
import tv.airtel.data.model.content.ContentResult
import tv.airtel.data.model.content.RowItemContent
import tv.airtel.data.model.content.apps.AppEntity
import tv.airtel.data.model.content.detail.EpisodeDetail
import tv.airtel.data.model.content.detail.SeasonDetail
import tv.airtel.data.model.content.recentfavorite.RecentFavoriteEntity
import tv.airtel.data.model.content.related.RelatedContent
import tv.airtel.data.model.content.related.RelatedSports
import tv.airtel.data.model.player.PlaybackResponse
import tv.airtel.data.model.search.SearchCategoryWiseRequestModel
import tv.airtel.data.model.search.SearchResponse
import tv.airtel.data.model.search.SearchResponseCategoryWise
import tv.airtel.data.model.user.ActivateDeviceEntity
import tv.airtel.data.model.user.AppConfig
import tv.airtel.data.model.user.CurrentUser
import tv.airtel.data.model.user.FaqEntity
import tv.airtel.data.model.user.HelpVideoEntity
import tv.airtel.data.model.user.IdentityEntity
import tv.airtel.data.model.user.LoginEntity
import tv.airtel.data.model.user.OtpSuccessEntity
import tv.airtel.data.model.user.UserConfig
import tv.airtel.data.model.user.plan.AvailablePlanEntity
import tv.airtel.data.model.user.profile.ProfileEntity
import tv.airtel.data.repo.ConfigRepository
import tv.airtel.data.utilmodule.config.Environment
import tv.airtel.util.config.WynkApplication
import tv.airtel.data.utilmodule.manager.AppPreferenceManager
import tv.airtel.data.utilmodule.manager.DbPreferenceManager
import tv.airtel.data.utilmodule.manager.UserPreferenceManager
import tv.airtel.data.utilmodule.util.Constants
import tv.airtel.data.utilmodule.DeviceIdentifier
import tv.airtel.data.utilmodule.util.LogUtil
import tv.airtel.wynk.analytics.AnalyticsHashMap
import tv.airtel.wynk.analytics.util.AnalyticsConstants
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Created by VipulKumar on 26/03/18.
 *
 * Utility to expose APIs for use.
 * Ideally a client should only be interacting with this class to find all the APIs.
 * DO NOT let the use of ViewModels or Repositories be accessible to the client.
 */
@Suppress("unused", "MemberVisibilityCanBePrivateA")
@Singleton
class AtvSdk private constructor() : HasServiceInjector {
    @Inject
    internal lateinit var application: Application
    @Inject
    internal lateinit var configViewModel: ConfigViewModel
    @Inject
    internal lateinit var contentListViewModel: ContentListViewModel
    @Inject
    internal lateinit var contentDetailViewModel: ContentDetailViewModel
    @Inject
    internal lateinit var playbackViewModel: PlaybackViewModel
    @Inject
    internal lateinit var searchViewModel: SearchViewModel
    @Inject
    internal lateinit var userViewModel: UserViewModel
    @Inject
    internal lateinit var profileViewModel: ProfileViewModel
    @Inject
    internal lateinit var recentFavoriteViewModel: RecentFavoriteViewModel
    @Inject
    internal lateinit var appViewModel: AppViewModel
    @Inject
    internal lateinit var atvAnalytics: AtvAnalytics
    @Inject
    internal lateinit var configUtils: ConfigUtils
    @Inject
    internal lateinit var recentSyncManager: RecentSyncManager
    @Inject
    lateinit var serviceInjector: DispatchingAndroidInjector<Service>
    @Inject
    internal lateinit var repository: ConfigRepository
    @Inject
    internal lateinit var appExecutors: AppExecutors
    @Inject
    internal lateinit var middlewareDb: MiddlewareDb

    override fun serviceInjector(): AndroidInjector<Service> {
        return serviceInjector
    }

    companion object : NoArgSingletonHolder<AtvSdk>(::AtvSdk)

    /**
     * Initialises modules and frameworks for the SDK to work.
     * @param application  application instance
     * @param appKey       a key generated and shared offline, acts as a unique identifier for a client
     * @param debuggable   sets debuggable true or false. false by default
     * @param flavour      ATV supports 2 flavours - [Flavour.PRODUCTION] and [Flavour.STAGING]
     */
    fun init(
        application: Application, appKey: String, debuggable: Boolean = false,
        flavour: Flavour = Flavour.PRODUCTION, deviceType: DeviceType
    ) {
        LogUtil.d("Init Started ${System.currentTimeMillis()}")
        WynkApplication.context = application

        initDagger(application, this, debuggable)

        Environment.APP_VERSION_NAME =
            DeviceIdentifier.fetchAppVersionName(application) ?: Environment.APP_VERSION_NAME
        Environment.APP_VERSION_CODE =
            DeviceIdentifier.fetchAppVersionCode(application) ?: Environment.APP_VERSION_CODE
        val appId = getAppIdForPackage(application.packageName)
        DeviceIdentifier.projectType = when (appId) {
            AppId.APP_SDK -> DeviceIdentifier.AppId.APP_SDK
            AppId.APP_XTREME -> {
                DeviceIdentifier.AppId.APP_XTREME
            }
            AppId.APP_STB -> DeviceIdentifier.AppId.APP_STB
            AppId.APP_PRIMETIME -> DeviceIdentifier.AppId.APP_PRIMETIME
            AppId.APP_MOBILITY -> DeviceIdentifier.AppId.APP_MOBILITY
            AppId.APP_MITRA -> DeviceIdentifier.AppId.APP_MITRA
        }
        DeviceIdentifier.buildDeviceName(application, DeviceIdentifier.projectType!!)
        insertApiCodes(flavour.name)
        configViewModel.initEnvironment(
            debuggable, when (flavour) {
                Flavour.STAGING -> Environment.Staging.getInstance()
                Flavour.PRODUCTION -> Environment.Production.getInstance()
            }, deviceType
        )

        recentSyncManager.cancelOldJobs()
        registerAppKey(appKey)
        initFabric()
        initAnalytics(deviceType, configViewModel.environment, appId.type, debuggable)
        LogUtil.d("Init Finished ${System.currentTimeMillis()}")
    }

    /**
     * Configures the app with multiple network calls. Not all the calls are blocking,
     * means it can dispatch dispatchValue before some of these network calls complete.
     *
     * User Migration : call to migrate ancient ATV users to the new Middleware backend
     * Geo Block      : checks if the user is in valid geo location to use the APIs
     * Login          : tries to log the user in using customer ID
     * User AppConfigEntity    : fetches [UserConfig]
     * LoadCurrentUser: loads current user locally from database and prepares for later use
     * */
    fun configure(): LiveData<Resource<Boolean>> {
        LogUtil.d("Configure Started ${System.currentTimeMillis()}")
        return configViewModel.configure()
    }

    fun setMoengageId(
        moEngageId: String, @DrawableRes notificationSmallIcon: Int = 0,
        @DrawableRes notificationLargeIcon: Int = 0
    ) {
        atvAnalytics
            .initMoEngage(moEngageId, notificationSmallIcon, notificationLargeIcon)
    }

    fun setMoengageId(moEngageId: String) {
        atvAnalytics
            .initMoEngage(moEngageId, 0, 0)
    }

    private fun initFabric() {
        CrashlyticsUtil.initCrashlytics(application.applicationContext)
    }

    private fun getConfigUtils(): ConfigUtils {
        return configUtils
    }

    private fun initDagger(application: Application, atvSdk: AtvSdk, debuggable: Boolean = false) {
        DaggerInjector.injectAll(application, atvSdk, debuggable)
    }

    private fun insertApiCodes(flavourName: String) {
        ErrorCodes.insertApiCodes(repository, appExecutors, flavourName)
    }

    private fun registerAppKey(appKey: String) {
        //TODO: Do something with app key
    }

    fun identifyUser(): LiveData<Resource<IdentityEntity>> {
        return userViewModel.identifyUser()
    }

    fun activateOttDevice(): LiveData<Resource<ActivateDeviceEntity>> {
        return userViewModel.activateDevice()
    }

    fun verifyOttDevice(devicePin: String): LiveData<Resource<LoginEntity>> {
        return userViewModel.verifyDevice(devicePin)
    }

    fun authenticateUserWithCustomerId(customerId: String? = null): LiveData<Resource<LoginEntity>> {
        DeviceIdentifier.dthCustomerId = customerId
        return userViewModel.loginUser()
    }

    fun authenticateUserWithMsisdn(msisdn: String? = null): LiveData<Resource<LoginEntity>> {
        DeviceIdentifier.msisdn = msisdn
        return userViewModel.loginUser()
    }

    /**
     * Returns content list from database and then from Remote API.
     * Primarily includes two network calls
     * Get Layout  : fetches the layout and structure for the page
     * Get Content : fetches the content corresponding to each [BaseRow] in layout
     *
     * We first dispatch the values from database (if any) to user with [Status.LOADING]
     * then fetch the latest data from Remote and dispatch that with [Status.SUCCESS]
     * */
    fun getContent(page: String): LiveData<Resource<ContentResult>> {
        return contentListViewModel.getContent(page)
    }

    fun getContentByContentId(contentId: String): LiveData<Content> {
        return contentListViewModel.getContentByContentId(contentId)
    }

    /**
     * Returns content list from database and then from Remote API.
     * Primarily includes two network calls
     * Get Layout  : fetches the layout and structure for the page
     * Get Content : fetches the content corresponding to each [BaseRow] in layout
     *
     * same as [getContent]; the Only modification is that the query params are group by Source
     * */
    fun getContentBySource(page: String): LiveData<Resource<ContentResult>> {
        return contentListViewModel.getContent(page, true)
    }

    /**
     * Returns content list for a specific package
     * */
    fun getContentByPackageId(
        pageId: String,
        packageId: String,
        source: String = "",
        type: String = ""
    ): WiseLiveData<Resource<ContentEntityMap>> {
        return contentListViewModel.getContentByPackageId(
            ContentListViewModel.ContentTrigger(
                pageId,
                packageId,
                source,
                type
            )
        )
    }

    /**
     * Returns content list (used for "more" feature) from Remote API.
     * This API does not support database access. So the data will only be provided from remote.
     * */
    fun getContent(
        contentId: String?, pageSize: Int? = 50,
        pageIndex: Int? = 0
    ): LiveData<Resource<ContentEntity>> {
        val contentListData = contentListViewModel
            .getContent(contentId, pageSize, pageIndex)
        return Transformations.map(contentListData) {

            val newData = it.data?.iterator()?.next()?.value
            Resource(it.status, newData, it.error)
        }
    }

    private fun initAnalytics(
        deviceType: DeviceType,
        environment: Environment,
        appId: String,
        debuggable: Boolean = false
    ) {
        atvAnalytics.initAnalytics(
            getCurrentUser(),
            environment,
            deviceType.type,
            appId,
            debuggable
        )
    }

    fun getContentDetail(contentId: String): LiveData<Resource<ContentDetail>> {
        return contentDetailViewModel.getContentDetail(contentId)
    }

    fun getSeasonDetail(contentId: String): LiveData<Resource<SeasonDetail>> {
        return contentDetailViewModel.getSeasonDetail(contentId)
    }

    fun getEpisodeDetail(contentId: String): LiveData<Resource<EpisodeDetail>> {
        return contentDetailViewModel.getEpisodeDetail(contentId)
    }

    fun getRelatedContent(contentId: String): LiveData<Resource<RelatedContent>> {
        return contentDetailViewModel.getRelatedContentEntities(contentId)
    }

    fun getRelatedSports(contentId: String): LiveData<Resource<RelatedSports>> {
        return contentDetailViewModel.getRelatedSportsEntities(contentId)
    }

    fun getContentByCreditId(creditRef: String): LiveData<Resource<SearchResponse>> {
        return contentDetailViewModel.getRelatedPeopleEntities(creditRef)
    }

    @JvmOverloads
    fun addRecent(
        contentId: String,
        contentDetail: ContentDetail,
        lastWatchedPosition: Int,
        episodeNo: Int = 0,
        tvShowName: String? = null,
        seasonNo: Int? = null
    ) {
        recentFavoriteViewModel.addRecent(
            contentId,
            contentDetail,
            lastWatchedPosition,
            episodeNo = episodeNo,
            tvShowName = tvShowName,
            seasonNo = seasonNo
        )
    }

    fun getLastPlayedEpisode(seriesId: String): LiveData<RecentFavoriteEntity> {
        return recentFavoriteViewModel.getLastPlayedEpisode(seriesId)
    }

    fun removeFromRecent(contentId: String) {
        recentFavoriteViewModel.deleteRecent(contentId)
    }

    fun getRecentlyWatched(): LiveData<Resource<List<RecentFavoriteEntity>>> {
        return recentFavoriteViewModel.getRecents()
    }

    fun getRecentlyWatched(contentIds: List<String>): LiveData<List<RecentFavoriteEntity>> {
        return recentFavoriteViewModel.getRecentlyWatched(contentIds)
    }

    fun getRecentlyWatchedBySeriesId(seriesId: String): LiveData<List<RecentFavoriteEntity>> {
        return recentFavoriteViewModel.getRecentlyWatchedBySeriesId(seriesId)
    }

    fun getRecentFavourite(contentId: String): LiveData<RecentFavoriteEntity> {
        return recentFavoriteViewModel.getRecentFavourite(contentId)
    }

    fun addToWatchLater(contentId: String, contentDetail: ContentDetail) {
        recentFavoriteViewModel.addToWatchLater(contentId, contentDetail)
    }

    fun removeWatchLater(contentId: String) {
        recentFavoriteViewModel.removeWatchLater(contentId)
    }

    fun getWatchLater(): LiveData<Resource<BaseRow>> {
        return recentFavoriteViewModel.getWatchLater()
    }

    /**
     * API to get response from playback call.
     */
    fun getPlaybackResponseForNonIngestedContent(
        contentId: String,
        cp: String?
    ): LiveData<Resource<PlaybackResponse>> {
        return playbackViewModel.fetchPlaybackResponse(contentId, cp)
    }

    /**
     * API to check for latest updates for launcher APK - for ATV Xtreme only
     */
    fun checkForUpdates(): LiveData<Resource<AppUpdateEntity>> {
        return configViewModel.checkForUpdates()
    }

    /**
     * Helper API to check if user is eligible for Airtel only playback
     * @param contentId Content ID of the content to check
     */
    fun checkForAirtelOnly(contentId: String?): LiveData<Resource<Boolean>> {
        return userViewModel.checkForAirtelOnly(contentId)
    }

    /**
     * Mark or un-mark a content as favorite.
     *
     * @param contentId: Content Id which will be affected
     * @param isFavorite: true to mark the content as favorite, false otherwise
     * @return observable of ResultEntity
     */
    fun markFavorite(
        contentId: String,
        isFavorite: Boolean = true
    ): LiveData<Resource<ResultEntity>> {
        return contentDetailViewModel.markFavorite(contentId, isFavorite)
    }

    /**
     * Returns the list of favorite content
     */
    fun getFavoritesList(): LiveData<Resource<List<RowItemContent>>> {
        return profileViewModel.getFavoritesList()
    }

    /**
     * Returns profile by a profileId
     */
    fun getPeopleProfile(profileId: String): LiveData<Resource<PeopleProfile>> {
        return profileViewModel.getPeopleProfile(profileId)
    }

    /**
     * Fetches all profile data under current account
     */
    fun getProfileData(): LiveData<Resource<ProfileEntity>> {
        return profileViewModel.getProfileData()
    }

    /**
     * Switches to the profile under current account
     *
     * @param profileId id of the profile to be selected
     */
    fun selectProfile(profileId: String): LiveData<Resource<ProfileEntity>> {
        return profileViewModel.selectProfile(profileId)
    }

    /**
     * Creates new profile under current account
     *
     * @param name profile name
     * @param passCode optional passcode for the profile
     */
    fun createProfile(name: String, passCode: String? = null):
            LiveData<Resource<ProfileEntity>> {
        return profileViewModel.createProfile(name, passCode)
    }

    /**
     * Deletes the profile with given ID under current account
     *
     * @param profileId profile ID
     */
    fun deleteProfile(profileId: String):
            LiveData<Resource<ProfileEntity>> {
        return profileViewModel.deleteProfile(profileId)
    }

    /**
     * Updates a profile under current account
     *
     * @param profileId unique profile ID
     * @param name profile name
     * @param passCode optional passcode
     */
    fun updateProfile(profileId: String, name: String, passCode: String = ""):
            LiveData<Resource<ProfileEntity>> {
        return profileViewModel.updateProfile(profileId, name, passCode)
    }

    /**
     * Unlinks a device
     *
     * @param deviceId deviceId of the device needed to be unlinked
     */
    fun unlinkDevice(deviceId: String):
            LiveData<Resource<ProfileEntity>> {
        return profileViewModel.unlinkDevice(deviceId)
    }

    /**
     * reset current account
     *
     * @param deviceId deviceId of current device
     */
    fun resetAccount():
            LiveData<Resource<ProfileEntity>> {
        return profileViewModel.resetAccount()
    }

    /**
     * Update time whenever an app is opened
     */
    fun updateLastUsedTime(packageId: String, time: Long) {
        appViewModel.updateLastUsedTime(packageId, time)
    }

    /**
     * To generate an One Time Password for user mobile, Put all kind of validations at client side
     *
     * @param mobNo  Mobile no. for which OTP to generate, make sure to send a valid mobile no with
     * country code. for ex: +919876543210
     */
    fun generateOtp(mobNo: String?): LiveData<Resource<OtpSuccessEntity>> {
        val properties = AnalyticsHashMap()
        properties[AnalyticsConstants.SOURCE_NAME] = AnalyticsConstants.SourceNames.enter_mob.name
        properties[AnalyticsConstants.ACTION] = AnalyticsConstants.SUBMIT_MOB
        AnalyticsUtil.clickEvent(properties)

        return userViewModel.generateOtp(mobNo)
    }

    /**
     * Search for content based on a query keyword.
     *
     * @param keyword Query keyword to search for
     * @param subscribedOnly [Boolean] to identify if only to search within CPs subscribed by user
     * @param language Language to search for; language IDs are given in [CurrentUser.lang]
     * */
    fun searchContent(
        keyword: String, subscribedOnly: Boolean,
        language: String
    ): LiveData<Resource<SearchResponse>> {
        return searchViewModel.searchContent(keyword, subscribedOnly, language)
    }

    /**
     * Search for content based on a query keyword and get data content type wise
     *
     * @param keyword Query keyword to search for
     * @param subscribedOnly [Boolean] to identify if only to search within CPs subscribed by user
     * @param language Language to search for; language IDs are given in [CurrentUser.lang]
     * */
    fun searchContentCategorically(
        searchCategoryWiseRequestModel: SearchCategoryWiseRequestModel
    ): LiveData<Resource<SearchResponseCategoryWise>> {
        return searchViewModel.searchContentCategorically(searchCategoryWiseRequestModel)
    }

    /**
     * Search for content based on a query keyword and superType and get data for a particular content
     *
     * */
    fun searchMoreListing(
        searchCategoryWiseRequestModel: SearchCategoryWiseRequestModel
    ): LiveData<Resource<SearchResponseCategoryWise>> {
        return searchViewModel.searchMoreContent(searchCategoryWiseRequestModel)
    }

    /**
     * recent search consumed
     * @param keyword corresponding keyword on which client got consumption
     */
    fun recentSearchConsumed(keyword: String) {
        searchViewModel.recentSearchConsumed(keyword)
    }

    fun searchContentForAssist(keyword: String): List<Content> {
        return searchViewModel.searchContentForAssist(keyword)
    }

    /**
     * Verify one time password against given mobile number
     *
     * @param mobNo  Mobile no. for which OTP has been generated
     * @param otp    Generated one time password to authenticate mobile no
     */
    fun verifyOtp(mobNo: String?, otp: String?): LiveData<Resource<LoginEntity>>? {
        return userViewModel.verifyOtp(mobNo, otp)
    }

    /**
     * Updates user information, Make sure to put all validations before sending values
     *
     * @param email  Email of the user, expected : sample@name.domain
     * @param dob    Milliseconds time, for the date of birth
     * @param lang   List of String(s), where user selected language are provided.
     */
    fun updateUserConfig(
        name: String? = null, email: String? = null, dob: Long? = null,
        lang: ArrayList<String> = arrayListOf()
    ): LiveData<Resource<UserConfig>>? {
        return userViewModel.updateUserConfig(name, email, dob, lang)
    }

    /**
     * Get current state of user.
     */
    fun getCurrentUser(): CurrentUser? {
        return userViewModel.getCurrentUser()
    }

    /**
     * Get all apps.
     */
    fun getApps(): LiveData<Resource<List<AppEntity>>>? {
        return appViewModel.getApps()
    }

    /**
     * Load current user live data.
     */
    fun loadCurrentUser(): LiveData<Resource<CurrentUser>>? {
        return userViewModel.loadCurrentUser()
    }

    /**
     * Get [AppConfig] containing Page data to build tabs/pages.
     */
    fun getAppConfig(): AppConfig? {
        return configViewModel.getAppConfigResponse()
    }

    /**
     * Clear watch history.
     */
    fun clearWatchHistory(): LiveData<Resource<ClearHistoryResponse>> {
        return recentFavoriteViewModel.clearHistory()
    }

    fun getUserConfig(shouldFetch: Boolean = true): LiveData<Resource<UserConfig>> {
        return userViewModel.getUserConfig(shouldFetch)
    }

    //    /**
//     * Checks if the current user is logged in. from login entity
//     */
    fun isUserLoggedIn(): Boolean {
        return userViewModel.isUserLoggedIn()
    }

//    /**
//     * Checks if the current user is logged in.
//     * This directly accesses a boolean in shared preferences and not from [CurrentUser].
//     * //TODO change name and revisit impl.
//     */
//    fun isUserLoggedInFromSharedPrefs(): Boolean {
//        return userViewModel.isUserLoggedIn()
//    }

    /**
     * Checks if the current user is logged in.
     * This directly accesses a boolean in shared preferences and not from [CurrentUser].
     * //TODO change name and revisit impl.
     */
    fun isUserLoggedInFromSharedPrefs(): Boolean {
        return userViewModel.isUserLoggedIn()
    }

    fun getAnalytics(): AtvAnalytics {
        return atvAnalytics
    }

    fun getRecentSearch(limit: Int): LiveData<Resource<List<String>>> {
        return searchViewModel.getRecentSearches(limit)
    }

    fun getRecentSearchesConsumed(limit: Int): LiveData<Resource<List<String>>> {
        return searchViewModel.getRecentSearchesConsumed(limit)
    }

    fun clearRecentSearch() {
        return searchViewModel.clearRecentSearch()
    }

    fun clearDeviceUpdate(): Int {
        return configViewModel.clearAppUpdateEntity()
    }

    fun searchContentForAssistFromNetwork(keyword: String): SearchResponse? {
        return searchViewModel.searchContentForAssistFromNetwork(keyword)
    }

    fun getAvailablePlans(fetchFromNetwork: Boolean = true): LiveData<Resource<AvailablePlanEntity>> {
        return userViewModel.getAvailablePlans(fetchFromNetwork)
    }

    fun getFaqList(): LiveData<Resource<List<FaqEntity>>> {
        return configViewModel.getFaqList()
    }

    fun getHelpVideos(): LiveData<Resource<HelpVideoEntity>> {
        return configViewModel.getHelpVideo()
    }

    @SuppressLint("ApplySharedPref")
    private fun performCleanBuild(application: Application) {
        //.commit() used to block thread for immediate subsequent consumption
        UserPreferenceManager.getInstance(application).pref.edit()
            .putBoolean(UserPreferenceManager.IS_USER_LOGGED_IN, false).commit()
        UserPreferenceManager.getInstance(application).pref.edit()
            .putBoolean(UserPreferenceManager.IS_USER_LOGGED_IN_OLD, false).commit() //Old key for non-migration users
        UserPreferenceManager.getInstance(application).pref.edit()
            .putLong(UserPreferenceManager.KEY_LAST_SERVER_RECENT_SYNC_TIME, 0L).commit()
        UserPreferenceManager.getInstance(application).pref.edit()
            .putBoolean(UserPreferenceManager.KEY_LOCAL_CONTINUE_WATCHING_UPDATED, false).commit()
        clearSharedPrefs(application)
    }

    fun logout() {
        performCleanBuild(application)
        clearDatabase()

        userViewModel.stopUserConfigJob()
        userViewModel.resetCurrentUser()
    }

    fun clearDatabase(): Boolean {
        val db = middlewareDb

        // reset all auto-incrementalValues
        val query = SimpleSQLiteQuery("DELETE FROM sqlite_sequence")

        db.beginTransaction()
        return try {
            db.clearAllTables()
            db.query(query)
            db.setTransactionSuccessful()
            true
        } catch (e: Exception) {
            false
        } finally {
            db.endTransaction()
        }
    }

    fun clearSharedPrefs(application: Application) {
        AppPreferenceManager(application).clearPreferences()
        UserPreferenceManager(application).clearPreferences()
        DbPreferenceManager(application).clearPreferences()
    }

    /** Flavours to be used on this layer and above
     * DO NOT let the client access the [tv.airtel.util.config.Environment.Flavour] from Util SDK
     * This class provides an abstraction to that.
     */
    enum class Flavour {
        STAGING,
        PRODUCTION
    }

    enum class DeviceType(val type: String) {
        DEVICE_PHONE("Phone"),
        DEVICE_TABLET("Tablet"),
        DEVICE_STB("STB"),
        DEVICE_STICK("STICK")
    }

    enum class AppId(val type: String) {
        APP_XTREME("XTREME"),
        APP_SDK("SDK"),
        APP_STB("STB"),
        APP_PRIMETIME("PRIMETIME"),
        APP_MOBILITY("MOBILITY"),
        APP_MITRA("PTMITRA")
    }

    private fun getAppIdForPackage(packageName: String): AtvSdk.AppId {
        val localPackageMapping = linkedMapOf<AtvSdk.AppId, List<String>>()
        localPackageMapping[AtvSdk.AppId.APP_MITRA] = (listOf(
            Constants.AppIds.MITRA_APP_PACKAGE_ID,
            Constants.AppIds.PRIME_TIME_SAMPLE_PACKAGE_ID
        ))
        localPackageMapping[AtvSdk.AppId.APP_PRIMETIME] = (listOf(
            Constants.AppIds.PRIME_TIME_PACKAGE_ID,
            Constants.AppIds.PRIME_TIME_SAMPLE_PACKAGE_ID
        ))
        localPackageMapping[AtvSdk.AppId.APP_SDK] =
            (listOf(Constants.AppIds.APP_SDK_ID, Constants.AppIds.PRIME_TIME_SAMPLE_PACKAGE_ID))
        localPackageMapping[AtvSdk.AppId.APP_XTREME] =
            (listOf(
                Constants.AppIds.APP_XTREME_ID, Constants.AppIds.PRIME_TIME_SAMPLE_PACKAGE_ID,
                Constants.AppIds.APP_SAMPLE
            ))
        localPackageMapping[AtvSdk.AppId.APP_MOBILITY] = (listOf(
            Constants.AppIds.APP_MOBILITY_ID,
            Constants.AppIds.PRIME_TIME_SAMPLE_PACKAGE_ID
        ))

        localPackageMapping.forEach {
            if (it.value.contains(packageName)) {
                return it.key
            }
        }

        LogUtil.e("PrimeSDK", "No matching package found to init SDK")
//      todo: Can change the type of exception thrown
        throw IllegalArgumentException()
    }
}
