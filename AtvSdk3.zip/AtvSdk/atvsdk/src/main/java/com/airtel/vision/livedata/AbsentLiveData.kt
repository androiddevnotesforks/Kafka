package com.airtel.vision.livedata

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData

/**
 * Created by Satya on 28/03/18.
 * [LiveData] that goes as return type of every API that this SDK dispatches to client.
 */
open class AbsentLiveData<T> : MediatorLiveData<T>() {
    init {
        value = null
    }

    companion object {
        fun <T> create(): AbsentLiveData<T> {
            return AbsentLiveData()
        }
    }
}
