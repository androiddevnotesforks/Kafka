package com.airtel.vision.manager.newsync

import tv.airtel.data.utilmodule.manager.UserPreferenceManager
import tv.airtel.data.utilmodule.util.LogUtil
import javax.inject.Inject

/**
 * Created by Aditya Mehta on 02/01/19.
 */
internal class RecentSyncPreferenceManager @Inject constructor(private val userPreferenceManager: UserPreferenceManager) {

    @Synchronized
    internal fun isLocalDbUpdated() =
            userPreferenceManager.getBoolean(UserPreferenceManager.KEY_LOCAL_CONTINUE_WATCHING_UPDATED, false)

    @Synchronized
    internal fun setLocalDbUpdated(updated: Boolean)  {
        LogUtil.d(RecentSyncPreferenceManager.TAG+ " set local db update called "+updated)
        userPreferenceManager.putBoolean(UserPreferenceManager.KEY_LOCAL_CONTINUE_WATCHING_UPDATED, updated)
    }


    internal fun oldLastSyncTime() =
            userPreferenceManager.getLong(UserPreferenceManager.KEY_LAST_SERVER_RECENT_SYNC_TIME, DEFAULT_LAST_SYNC_TIME)

    internal fun setLastSyncTime(lastSyncTime: Long) =
            userPreferenceManager.putLong(UserPreferenceManager.KEY_LAST_SERVER_RECENT_SYNC_TIME, lastSyncTime)

    companion object {
        internal const val DEFAULT_LAST_SYNC_TIME = 0L
        internal const val TAG = "RecentFavTest"
    }

}
