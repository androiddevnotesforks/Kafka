package com.airtel.vision.di

import android.app.Application
import com.airtel.vision.AtvSdk

/**
 * Created by Satya on 27/03/18.
 *
 */
object DaggerInjector {

    fun injectAll(application: Application, atvSdk: AtvSdk, debuggable: Boolean = false) {
        val visionAppComponent = DaggerVisionAppComponent.builder()
                .application(application)
                .debuggable(debuggable)
                .build()
        visionAppComponent.inject(application)
        visionAppComponent.inject(atvSdk)
    }
}