package com.airtel.vision.di


import android.app.Application
import com.airtel.vision.AtvSdk
import com.airtel.vision.di.modules.ApplicationModule
import dagger.BindsInstance
import dagger.Component
import dagger.android.AndroidInjectionModule
import javax.inject.Singleton


/**
 * Authored by vipulkumar on 19/09/17.
 */

@Singleton
@Component(modules = [(ApplicationModule::class), (AndroidInjectionModule::class)])
 interface VisionAppComponent {
    @Component.Builder
    interface Builder {

        @BindsInstance
        fun application(application: Application): Builder

        @BindsInstance
        fun debuggable(debuggable: Boolean): Builder

        fun build(): VisionAppComponent
    }
    fun inject(atvSdk:AtvSdk):AtvSdk
    fun inject(app: Application)
}
