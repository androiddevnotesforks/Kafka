package com.airtel.vision.util

/**
 * Created by b0203949 on 28/03/18.
 */
object ErrorMessage{
    const val USER_MIGRATION_FAILED="User Migration Failed"
    const val OTP_GENERATION_FAILED = "OTP Generation Failed"
    const val OTP_VERIFICATION_FAILED = "OTP Verification Failed"
    const val USER_PROFILE_UPDATE_FAILED = "User Profile Update Failed"
    const val PERMISSION_NOT_GRANTED="permission not granted"
}