package com.airtel.vision.util

import android.os.Build
import android.os.Environment
import android.os.StatFs

/**
 * Created by Aditya Mehta on 03/05/18.
 */
object MemoryUtil {

    internal val SIZE_KB = 1024L
    internal val SIZE_MB = SIZE_KB * SIZE_KB

    fun getAvailableSpaceInMB(): Long {
        var availableSpace = -1L
        try {
            val stat = StatFs(Environment.getExternalStorageDirectory().path)
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN_MR2) {
                availableSpace = stat.availableBlocks.toLong() * stat.blockSize.toLong()
            } else {
                availableSpace = stat.availableBlocksLong * stat.blockSizeLong
            }
            return availableSpace / SIZE_MB
        } catch (e: IllegalArgumentException) {
            return availableSpace
        }

    }
}