package com.airtel.vision.manager

import android.app.Application
import com.firebase.jobdispatcher.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Author : Akash Gupta
 * Created On : 13/08/18
 *
 */
@Singleton
internal class RecentSyncManager @Inject constructor(val application: Application) {

    private val firebaseJobDispatcher: FirebaseJobDispatcher =
            FirebaseJobDispatcher(GooglePlayDriver(application))

    fun cancelOldJobs() {
        firebaseJobDispatcher.cancel(RecentSyncRecurringJob)
        firebaseJobDispatcher.cancel(RecentSyncOneTimeJob)
    }

    companion object {
        private val RecentSyncRecurringJob = "RecentSyncService"
        private val RecentSyncOneTimeJob = "RecentSyncOneTimeJob"
    }
}
