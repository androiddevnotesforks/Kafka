package com.airtel.vision.viewmodel

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.Transformations
import com.airtel.vision.AtvSdk
import com.airtel.vision.analytics.AnalyticsUtil
import com.airtel.vision.livedata.WiseLiveData
import com.airtel.vision.service.AppStatusJob
import com.airtel.vision.service.UserConfigJob
import com.airtel.vision.util.PermissionsUtil
import tv.accedo.airtel.wynk.domain.firebase.util.ConfigUtils
import tv.airtel.data.domainmodule.util.CrashlyticsUtil
import tv.airtel.data.api.ParameterBuilder
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.error.AtvError
import tv.airtel.data.error.ErrorCodes
import tv.airtel.data.livedata.AbsentLiveData
import tv.airtel.data.model.AppUpdateEntity
import tv.airtel.data.model.user.*
import tv.airtel.data.repo.ConfigRepository
import tv.airtel.data.utilmodule.config.ConfigurationManager
import tv.airtel.data.utilmodule.config.Environment
import tv.airtel.data.utilmodule.manager.SharedPreferenceManager
import tv.airtel.data.utilmodule.manager.UserPreferenceManager
import tv.airtel.data.utilmodule.DeviceIdentifier
import tv.airtel.data.utilmodule.util.DeviceUtil
import tv.airtel.data.utilmodule.util.LogUtil
import tv.airtel.wynk.analytics.AnalyticsHashMap
import tv.airtel.wynk.analytics.util.AnalyticsConstants.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Created by Satya on 26/03/18.
 * ViewModel for configuration related operations.
 */
@Singleton
internal class ConfigViewModel @Inject
constructor(private val configRepository: ConfigRepository) : BaseViewModel() {
    @Inject
    internal lateinit var application: Application
    @Suppress("MemberVisibilityCanBePrivate")
    @Inject
    internal lateinit var userViewModel: UserViewModel
    @Suppress("MemberVisibilityCanBePrivate")
    @Inject
    internal lateinit var configurationManager: ConfigurationManager
    @Inject
    internal lateinit var environment: Environment
    @Suppress("MemberVisibilityCanBePrivate")
    @Inject
    internal lateinit var configUtils: ConfigUtils
    @Suppress("MemberVisibilityCanBePrivate")
    @Inject
    internal lateinit var appStatusJob: AppStatusJob
    @Suppress("MemberVisibilityCanBePrivate")
    @Inject
    internal lateinit var currentUser: CurrentUser

    private var appStatusData: String = "none"
    private var configResponse: WiseLiveData<Resource<Boolean>> = WiseLiveData.create()
    private var geoBlockEntity: LiveData<Resource<GeoBlockEntity>> = AbsentLiveData.create()
    private var appConfig: LiveData<Resource<AppConfigEntity>> = AbsentLiveData.create()
    private var userConfig: LiveData<Resource<UserConfig>> = AbsentLiveData.create()

    private var currentUserEntity: LiveData<Resource<CurrentUser>>
    private var currentUserMutableLiveData = MutableLiveData<Boolean>()

    private var checkForUpdate: LiveData<Resource<AppUpdateEntity>>
    private var checkForUpdateResponse: WiseLiveData<Resource<AppUpdateEntity>> = WiseLiveData()
    private var checkForUpdateTrigger = MutableLiveData<Boolean>()

    private var faqList: LiveData<Resource<List<FaqEntity>>>
    private var faqResponse: WiseLiveData<Resource<List<FaqEntity>>> = WiseLiveData()
    private var faqTrigger = MutableLiveData<String>()

    private var helpVideoEntity: LiveData<Resource<HelpVideoEntity>>
    private var helpVideoResponse: WiseLiveData<Resource<HelpVideoEntity>> = WiseLiveData()
    private var helpVideoTrigger = MutableLiveData<String>()

    private var appConfigResponse: AppConfig? = null
    private var isConfigDispatched: Boolean = false
    private var isCurrentUserLoaded: Boolean = false

    private var configRepositoryObserver: Observer<Resource<Boolean>> = Observer {
        LogUtil.d("config Response")
    }

    init {
        currentUserEntity = Transformations.switchMap(currentUserMutableLiveData) {
            if (it == true) {
                userViewModel.loadCurrentUser()
            } else {
                AbsentLiveData.create()
            }
        }
        initLoadCurrentUserResp()

        checkForUpdate = Transformations.switchMap(checkForUpdateTrigger) {
            if (it == true) {
                configRepository.checkForUpdates()
            } else {
                AbsentLiveData.create()
            }
        }
        initCheckForUpdateResponse()


        faqList = Transformations.switchMap(faqTrigger) {
            if (it?.isNotEmpty() == true) {
                configRepository.getFAQData(it)
            } else {
                AbsentLiveData.create()
            }
        }
        initFaqResponse()

        helpVideoEntity = Transformations.switchMap(helpVideoTrigger) {
            if (it?.isNotEmpty() == true) {
                configRepository.getHelpVideos(it)
            } else {
                AbsentLiveData.create()
            }
        }
        initHelpVideoResponse()
    }

    private fun initCheckForUpdateResponse() {
        checkForUpdateResponse.addSource(checkForUpdate) {
            when (it?.status) {
                Status.LOADING -> checkForUpdateResponse.dispatchLoading(it)
                Status.SUCCESS -> checkForUpdateResponse.dispatchSuccess(it)
                Status.ERROR -> checkForUpdateResponse.dispatchError(it)
            }
        }
    }

    private fun initFaqResponse() {
        faqResponse.addSource(faqList) {
            when (it?.status) {
                Status.LOADING -> faqResponse.dispatchLoading(it)
                Status.SUCCESS -> faqResponse.dispatchSuccess(it)
                Status.ERROR -> faqResponse.dispatchError(it)
            }
        }
    }

    private fun initHelpVideoResponse() {
        helpVideoResponse.addSource(helpVideoEntity) {
            when (it?.status) {
                Status.LOADING -> helpVideoResponse.dispatchLoading(it)
                Status.SUCCESS -> helpVideoResponse.dispatchSuccess(it)
                Status.ERROR -> helpVideoResponse.dispatchError(it)
            }
        }
    }

    private fun initLoadCurrentUserResp() {
        addObserverOnConfigResponse()
        configResponse.addSource(currentUserEntity) { it ->
            when (it?.status) {
                Status.SUCCESS -> {
                    isCurrentUserLoaded = true
                    if (it.data?.isLoggedIn() == true) {
                        userViewModel.startUserConfigJob(
                                0,
                                UserConfigJob.DEFAULT_CONFIG_INTERVAL_IN_SECONDS.toLong()
                        )

                        CrashlyticsUtil.setUserInfo(currentUser.uid, currentUser.email)
                    }
                    onConfigDone()
                    configResponse.removeSource(currentUserEntity)
                }

                else -> {
                    // Never Response error and loading
                }
            }
        }
    }

    internal fun initEnvironment(
        debuggable: Boolean,
        flavour: Environment.Flavour,
        deviceType: AtvSdk.DeviceType?
    ) {
        environment.initialize(debuggable, flavour)
        configUtils.init()
        initConfiguration(deviceType)
    }

    private fun initConfiguration(deviceType: AtvSdk.DeviceType?) {
        /* prepare deviceIdentifier to be used in networking calls */
        when (deviceType) {
            AtvSdk.DeviceType.DEVICE_PHONE -> DeviceIdentifier.deviceType =
                    DeviceIdentifier.DeviceType.DEVICE_PHONE
            AtvSdk.DeviceType.DEVICE_STB -> DeviceIdentifier.deviceType =
                    DeviceIdentifier.DeviceType.DEVICE_STB
            AtvSdk.DeviceType.DEVICE_TABLET -> DeviceIdentifier.deviceType =
                    DeviceIdentifier.DeviceType.DEVICE_TABLET
            AtvSdk.DeviceType.DEVICE_STICK -> DeviceIdentifier.deviceType =
                    DeviceIdentifier.DeviceType.DEVICE_STICK
        }
        DeviceIdentifier.getDeviceIdentifierHeader(application.applicationContext)
        DeviceIdentifier.getDeviceId(application.applicationContext)
    }

    /**
     * Configures the SDK
     */
    internal fun configure(): LiveData<Resource<Boolean>> {
        isConfigDispatched = false
        configResponse.dispatchLoading(Resource.loading(null))
        loadCurrentUser() // Returns immediately from cache

        getAppConfig() // App config call is blocking
        appStatusJob.startJob(
                appStatusData, AppStatusJob.DEFAULT_APP_STATUS_COUNTER.toLong(),
                AppStatusJob.DEFAULT_APP_STATUS_INTERVAL.toLong(),
                AppStatusJob.DEFAULT_APP_STATUS_INTERVAL.toLong()
        )
        checkGeoBlock() // Geo Block is Non-Blocking
        updateUserConfigOnAppUpdate() // Non-Blocking
        return this.configResponse
    }

    private fun checkGeoBlock() {
        if (PermissionsUtil.isPermissionGranted(
                        PermissionsUtil.PermissionType.TYPE_APP_START,
                        application.applicationContext
                )
        ) {
            appStatusData = GEOBLOCK_IN_PROGRESS
            appStatusJob.data = GEOBLOCK_IN_PROGRESS
            val params = ParameterBuilder
                    .buildGeoBlockParams(application, currentUser.email)
            checkGeoBlock(params)
        } else {
            dispatchConfigResponseError(
                    AtvError(
                            ErrorCodes.AppError.PHONE_STATE_PERMISSION_NOT_GRANTED,
                            apiCode = ""
                    )
            )
        }
    }

    private fun checkGeoBlock(geoBlockParameter: HashMap<String, String?>) {
        configResponse.removeSource(geoBlockEntity)
        addObserverOnConfigResponse()
        geoBlockEntity = configRepository.checkGeoBlock(geoBlockParameter)
        configResponse.addSource(geoBlockEntity) {
            it?.let {
                when (it.status) {
                    Status.SUCCESS -> {
                        configResponse.removeSource(geoBlockEntity)
                        if (it.data?.isAllowedCountry == true) {
                            updateGeoBlockStatus(GEOBLOCK_SUCCESS)
                        } else {
                            updateGeoBlockStatus(GEOBLOCK_BLOCKED_APP)
                        }
                        removeNetworkObservers()
                    }
                    Status.ERROR -> {
                        configResponse.removeSource(geoBlockEntity)
                        updateGeoBlockStatus(GEOBLOCK_FAIL)
                        sendAppStatusEvent(it.error)
                        removeNetworkObservers()
                    }
                    else -> {
                    }
                }
            }
        }
    }

    private fun getAppConfig() {
        LogUtil.d("getAppConfig")
        configResponse.removeSource(appConfig)
        addObserverOnConfigResponse()
        appConfig = configRepository.getAppConfig()
        configResponse.addSource(appConfig) {
            LogUtil.d("appConfig Response ${it?.status}, ${it?.data?.configs?.pages}")
            it?.let {
                when (it.status) {
                    Status.LOADING -> {
                        appConfigResponse = it.data?.configs
                        LogUtil.d("AppConfig loading data ${it.data}")
                        if (appConfigResponse != null && appConfigResponse?.pages != null) {
                            onConfigDone()
                        }
                    }
                    Status.SUCCESS -> {
                        configResponse.removeSource(appConfig)
                        removeNetworkObservers()
                        if (appConfigResponse == null || appConfigResponse?.pages == null) {
                            appConfigResponse = it.data?.configs
                            if (appConfigResponse == null || appConfigResponse?.pages == null) {
//                            dispatchConfigResponseError(Error.build(Error.ErrorValue.PAGE_IDS_NOT_FOUND))
                                dispatchConfigResponseError(
                                        AtvError(
                                                ErrorCodes.AppError.PAGE_ID_NOT_FOUND,
                                                ErrorCodes.AppSubError.RECEIVED_NULL_DATA,
                                                ""
                                        )
                                )
                            }
                        }
                        onConfigDone()
                    }
                    Status.ERROR -> {
                        configResponse.removeSource(appConfig)
                        removeNetworkObservers()
                        LogUtil.d("AppConfig error data $appConfigResponse")
                        LogUtil.d("AppConfig error ${it.error}")
                        if (appConfigResponse == null || appConfigResponse?.pages == null) {
//                            val originalError = it.error
//                            val modifiedError = AtvError(
//                                    originalError?.respCode,
//                                    originalError?.errorCode,
//                                    originalError?.category,
//                                    originalError?.apiCode,
//                                    ErrorCodes.AppError.PAGE_ID_NOT_FOUND
//                            )
                            dispatchConfigResponseError(it.error)
                        }
                    }
                }
            }
        }
    }

    private fun loadCurrentUser() {
        currentUserMutableLiveData.value = true
    }

    private fun onConfigDone() {
        LogUtil.d(
                "$isConfigDispatched, " +
                        "$appConfigResponse, " +
                        "${appConfigResponse?.pages}, " +
                        "$isCurrentUserLoaded, " +
                        "${appConfigResponse?.cpDetailsList}"
        )

        if (appConfigResponse != null
                && appConfigResponse?.pages != null && isCurrentUserLoaded
        ) {
            dispatchConfigResponseSuccess()
        }
    }

    /**
     * We need to send updated appConfigResponse version to server
     * whenever the appConfigResponse is updated
     */
    private fun updateUserConfigOnAppUpdate() {
        if (DeviceUtil.isAppUpdated(application) && currentUser.isLoggedIn()) {
            updateUserConfig()
        } else {
            UserPreferenceManager.getInstance(application)
                    .putBoolean(SharedPreferenceManager.KEY_PENDING_USER_UPDATE, false)
        }

        if (DeviceUtil.isAppUpdated(application)) {
            DeviceUtil.updateAppVersionCode(application)
        }
    }

    private fun updateUserConfig() {
        configResponse.removeSource(userConfig)
        addObserverOnConfigResponse()
        userConfig = userViewModel.updateUserConfigCall(
                currentUser.name, currentUser.email,
                currentUser.dob
        )
        configResponse.addSource(userConfig) {
            LogUtil.d("updateConfig Response")
            if (it != null) when (it.status) {
                Status.SUCCESS, Status.ERROR -> {
                    configResponse.removeSource(userConfig)
                    removeNetworkObservers()
                    if (it.status == Status.ERROR) {
                        UserPreferenceManager.getInstance(application)
                                .putBoolean(SharedPreferenceManager.KEY_PENDING_USER_UPDATE, true)
                    }
                }
                else -> {
                }
            }
        }
    }

    private fun dispatchConfigResponseError(error: AtvError?) {
        if (!isConfigDispatched) {
            configResponse.dispatchError(Resource.error(error, false))
            isConfigDispatched = true
        }
    }

    private fun dispatchConfigResponseSuccess() {
        if (!isConfigDispatched) {
            configResponse.dispatchSuccess(Resource.success(true))
            isConfigDispatched = true
        }
    }

    private fun updateGeoBlockStatus(status: String) {
        appStatusData = status
        appStatusJob.data = status
        if (GEOBLOCK_SUCCESS.equals(appStatusData, true)
                || GEOBLOCK_BLOCKED_APP.equals(appStatusData, true)
        ) {
            AnalyticsUtil.sendAppStatusEvent(appStatusData)
            appStatusJob.stop()
        }
    }

    private fun sendAppStatusEvent(e: AtvError?) {
        appStatusJob.stop()
        val properties = AnalyticsHashMap()
        properties[APP_STATUS] = appStatusData
        properties[ERROR_MESSAGE] = e?.errorUserMessage
        properties[ERROR_CODE] = e?.errorCode
        AnalyticsUtil.sendAppStatusEvent(properties)
    }

    private fun removeNetworkObservers() {
        if (!(geoBlockEntity.hasObservers()
                        || appConfig.hasObservers()
                        || userConfig.hasObservers())
        ) {
            configResponse.removeObserver(configRepositoryObserver)
        }
    }

    private fun addObserverOnConfigResponse() {
        if (!configResponse.hasObservers()) {
            configResponse.observeForever(configRepositoryObserver)
        }
    }

    fun checkForUpdates(): WiseLiveData<Resource<AppUpdateEntity>> {
        checkForUpdateTrigger.value = true
        return checkForUpdateResponse
    }

    fun getAppConfigResponse(): AppConfig? {
        return appConfigResponse
    }

    fun getFaqList(): LiveData<Resource<List<FaqEntity>>> {

        faqTrigger.value = getAppConfigResponse()?.faqUrl

        return faqResponse
    }

    fun getHelpVideo(): LiveData<Resource<HelpVideoEntity>> {

        helpVideoTrigger.value = getAppConfigResponse()?.helpVideoUrl

        return helpVideoResponse
    }

    fun clearAppUpdateEntity(): Int {
        return configRepository.clearAppUpdateEntity()
    }
}
