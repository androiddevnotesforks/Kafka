package com.airtel.vision.service

import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.Message
import java.util.concurrent.TimeUnit

/**
 * Created by Satya on 04/04/18.
 * Utility to schedule jobs on specific intervals.
 */
abstract class JobScheduler(tag: String, private val what: Int) {
    private var mHandler: JobHandler
    private var mInterval: Long = DEFAULT_INTERVAL.toLong()

    init {
        val thread = HandlerThread(tag)
        thread.start()
        mHandler = JobHandler(thread.looper)
    }

    /**
     * start job after given delay
     */
    fun start(delayInSecs: Long, intervalInSec: Long) {
        if (intervalInSec > 0) {
            mInterval = intervalInSec
        }
        stop()
        restart(delayInSecs)
    }

    /**
     * Restart job after given delay
     */
    private fun restart(delayInSecs: Long) {
        mHandler.sendEmptyMessageDelayed(what, TimeUnit.SECONDS.toMillis(delayInSecs))
    }

    private inner class JobHandler(looper: Looper) : Handler(looper) {
        override fun handleMessage(msg: Message) {
            trigger()
        }
    }

    fun done() {
        restart(mInterval)
    }

    fun stop() {
        mHandler.removeMessages(what, null)
    }

    abstract fun trigger()

    companion object {
        //In Seconds
        private const val DEFAULT_INTERVAL = 1800
    }
}