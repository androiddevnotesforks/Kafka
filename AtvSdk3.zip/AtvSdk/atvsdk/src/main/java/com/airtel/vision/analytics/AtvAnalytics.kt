package com.airtel.vision.analytics

import android.app.Application
import android.support.annotation.DrawableRes
import tv.airtel.data.model.user.CurrentUser
import tv.airtel.data.utilmodule.config.Environment
import tv.airtel.wynk.analytics.Analytics
import tv.airtel.wynk.analytics.AnalyticsHashMap
import tv.airtel.wynk.analytics.events.Event
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Created by Aditya Mehta on 21/03/18.
 */
@Singleton
class AtvAnalytics @Inject constructor() {


    @Inject
    lateinit var context: Application


    internal fun initAnalytics(currentUser: CurrentUser?, environment: Environment, deviceType: String, appId:String, debuggable: Boolean = false) {

        Analytics.instance
                ?.init(context, currentUser,environment, deviceType,appId, debuggable)
    }

    fun trackEvent(eventName: String, isCritical: Boolean, eventProperties: AnalyticsHashMap) {
        Analytics.instance
                ?.trackEvent(eventName, isCritical, eventProperties)
    }

    fun trackEvent(event: Event, eventProperties: AnalyticsHashMap) {
        Analytics.instance
                ?.trackEvent(event.eventId, event.isCritical, eventProperties)
    }

    internal fun initMoEngage(moEngageId: String, @DrawableRes notificationSmallIcon: Int,
                              @DrawableRes notificationLargeIcon: Int) {

        Analytics.instance
                ?.initMoEngage(moEngageId, notificationSmallIcon, notificationLargeIcon)
    }
}
