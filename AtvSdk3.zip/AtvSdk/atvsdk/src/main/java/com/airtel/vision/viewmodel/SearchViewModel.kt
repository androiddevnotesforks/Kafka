package com.airtel.vision.viewmodel

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.core.util.ArrayMap
import com.airtel.vision.livedata.WiseLiveData
import tv.airtel.data.api.ParameterBuilder
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.model.content.Content
import tv.airtel.data.model.search.SearchCategoryWiseRequestModel
import tv.airtel.data.model.search.SearchResponse
import tv.airtel.data.model.search.SearchResponseCategoryWise
import tv.airtel.data.model.user.CurrentUser
import tv.airtel.data.repo.SearchRepository
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Created by AkashGupta on 29/03/18.
 * ViewModel for user related operations.
 */
@Singleton
internal class SearchViewModel @Inject
constructor(private val searchRepository: SearchRepository) : BaseViewModel() {
    @Inject
    internal lateinit var application: Application
    @Inject
    lateinit var currentUser: CurrentUser

    private var searchContentResponse: WiseLiveData<Resource<SearchResponse>> =
        WiseLiveData.create()
    private var searchContent: LiveData<Resource<SearchResponse>>
    private val searchKeywordMutableLiveData = MutableLiveData<ContentSearchParam>()

    private var searchContentCategoricallyResponse: ArrayMap<String, WiseLiveData<Resource<SearchResponseCategoryWise>>> = ArrayMap()
    private var searchContentCategorically: ArrayMap<String, LiveData<Resource<SearchResponseCategoryWise>>> = ArrayMap()
    private var searchCategoryWiseRequest = ArrayMap<String, MutableLiveData<SearchCategoryWiseRequestModel>>()

    private var searchMoreListingCategoryWiseResponse: WiseLiveData<Resource<SearchResponseCategoryWise>> = WiseLiveData.create()
    private var searchMoreListingCategoryWise: LiveData<Resource<SearchResponseCategoryWise>>
    private var searchMoreListingRequest = MutableLiveData<SearchCategoryWiseRequestModel>()

    private var recentSearchResponse: WiseLiveData<Resource<List<String>>> = WiseLiveData.create()
    private var recentSearch: LiveData<Resource<List<String>>>
    private val recentSearchMutableLiveData = MutableLiveData<Int>()


    private var recentSearchConsumedResponse: WiseLiveData<Resource<List<String>>> = WiseLiveData.create()
    private var recentSearchConsumed: LiveData<Resource<List<String>>>
    private val recentSearchConsumedMutableLiveData = MutableLiveData<Int>()

    init {
        searchContent = Transformations.switchMap(searchKeywordMutableLiveData) {
            if (it != null) {
                searchRepository.search(
                    ParameterBuilder
                        .buildSearchParams(
                            it.keyword ?: "", it.subscribedOnly, it.language
                                ?: "", currentUser
                        )
                )
            } else {
                WiseLiveData.create<Resource<SearchResponse>>()
            }
        }

        initSearchContentResponse()

//        searchContentCategorically = Transformations.switchMap(searchCategoryWiseRequest) {
//            if (it != null) {
//                searchRepository.searchCategoryWise(ParameterBuilder
//                        .buildCategorySearchParams(it, currentUser))
//            } else {
//                WiseLiveData.create<Resource<SearchResponseCategoryWise>>()
//            }
//        }
//
//        initSearchContentCategpryWiseResponse()

        searchMoreListingCategoryWise = Transformations.switchMap(searchMoreListingRequest) {
            if (it != null) {
                searchRepository.searchMoreListing(ParameterBuilder
                        .buildCategorySearchParams(it, currentUser))
            } else {
                WiseLiveData.create<Resource<SearchResponseCategoryWise>>()
            }
        }

        initSearchMoreListingResponse()

        recentSearch = Transformations.switchMap(recentSearchMutableLiveData) {
            if (it != null) {
                searchRepository.getRecentSearch(it)

            } else {
                WiseLiveData.create<Resource<List<String>>>()
            }
        }
        initRecentSearchResponse()

        recentSearchConsumed = Transformations.switchMap(recentSearchConsumedMutableLiveData) {
            if (it != null) {
                searchRepository.getRecentConsumedSearch(20)

            } else {
                WiseLiveData.create<Resource<List<String>>>()
            }
        }
        initRecentSearchConsumedResponse()

    }


    private fun initSearchMoreListingResponse() {
        searchMoreListingCategoryWiseResponse.addSource(searchMoreListingCategoryWise) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> {
                    searchMoreListingCategoryWiseResponse.dispatchSuccess(resource)
                }
                Status.LOADING -> searchMoreListingCategoryWiseResponse.dispatchLoading(resource)
                Status.ERROR -> searchMoreListingCategoryWiseResponse.dispatchError(resource)
            }
        }

    }


    private fun initSearchContentResponse() {
        searchContentResponse.addSource(searchContent) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> {
                    searchContentResponse.dispatchSuccess(resource)
                }
                Status.LOADING -> searchContentResponse.dispatchLoading(resource)
                Status.ERROR -> searchContentResponse.dispatchError(resource)
            }
        }
    }

//    private fun initSearchContentCategpryWiseResponse() {
//        searchContentCategoricallyResponse.addSource(searchContentCategorically) { resource ->
//            when (resource?.status) {
//                Status.SUCCESS -> {
//                    searchContentCategoricallyResponse.dispatchSuccess(resource)
//                }
//                Status.LOADING -> searchContentCategoricallyResponse.dispatchLoading(resource)
//                Status.ERROR -> searchContentCategoricallyResponse.dispatchError(resource)
//            }
//        }
//    }

    private fun initRecentSearchResponse() {

        recentSearchResponse.addSource(recentSearch) { resource ->
            if (resource != null) {
                recentSearchResponse.dispatchSuccess(resource)
            }
        }
    }

    private fun initRecentSearchConsumedResponse() {
        recentSearchConsumedResponse.addSource(recentSearchConsumed) { resource ->
            if (resource != null) {
                recentSearchConsumedResponse.dispatchSuccess(resource)
            }
        }
    }


    fun searchContent(
        keyword: String,
        subscribedOnly: Boolean,
        language: String
    ): LiveData<Resource<SearchResponse>> {
        searchKeywordMutableLiveData.value =
                ContentSearchParam(keyword.toLowerCase(), subscribedOnly, language)
        return searchContentResponse
    }

    fun searchContentCategorically(searchCategoryWiseRequestModel: SearchCategoryWiseRequestModel): LiveData<Resource<SearchResponseCategoryWise>> {
        if (!searchCategoryWiseRequest.contains(searchCategoryWiseRequestModel.source)) {
            searchCategoryWiseRequest[searchCategoryWiseRequestModel.source] = MutableLiveData()
        }
        searchCategoryWiseRequest[searchCategoryWiseRequestModel.source]!!.value = searchCategoryWiseRequestModel
        initSearchCategoryWise(searchCategoryWiseRequestModel)
        return searchContentCategoricallyResponse[searchCategoryWiseRequestModel.source]!!
    }

    private fun initSearchCategoryWise(searchCategoryWiseRequestModel: SearchCategoryWiseRequestModel) {
        if (!searchContentCategorically.contains(searchCategoryWiseRequestModel.source)) {
            searchContentCategorically[searchCategoryWiseRequestModel.source] = MutableLiveData()
            searchContentCategorically[searchCategoryWiseRequestModel.source] = Transformations.switchMap(searchCategoryWiseRequest[searchCategoryWiseRequestModel.source]!!) {
                if (it != null) {
                    searchRepository.searchCategoryWise(ParameterBuilder
                            .buildCategorySearchParams(it, currentUser))
                } else {
                    WiseLiveData.create<Resource<SearchResponseCategoryWise>>()
                }
            }
        }

        if (!searchContentCategoricallyResponse.contains(searchCategoryWiseRequestModel.source)) {
            searchContentCategoricallyResponse[searchCategoryWiseRequestModel.source] = WiseLiveData.create()
            searchContentCategoricallyResponse[searchCategoryWiseRequestModel.source]!!
                    .addSource(searchContentCategorically[searchCategoryWiseRequestModel.source]!!) { resource ->
                        when (resource?.status) {
                            Status.SUCCESS -> {
                                searchContentCategoricallyResponse[searchCategoryWiseRequestModel.source]!!.dispatchSuccess(resource)
                            }
                            Status.LOADING -> {
                                searchContentCategoricallyResponse[searchCategoryWiseRequestModel.source]!!.dispatchLoading(resource)
                            }
                            Status.ERROR -> {
                                searchContentCategoricallyResponse[searchCategoryWiseRequestModel.source]!!.dispatchError(resource)
                            }
                        }
                    }
        }
    }

    fun searchMoreContent(searchCategoryWiseRequestModel: SearchCategoryWiseRequestModel): LiveData<Resource<SearchResponseCategoryWise>> {
        searchMoreListingRequest.value = searchCategoryWiseRequestModel
        return searchMoreListingCategoryWiseResponse
    }

    fun searchContentForAssist(keyword: String): List<Content> {
        //        contentList.forEach {
//            contentItem -> contentItem.map.forEach {
//            it.value.content.forEach {
//                content -> if(content.title?.contains(keyword, true)!!) {
//                 returnContentList.add(content)
//            }
//            } } }

        return searchRepository.searchForAssist(keyword.toLowerCase())
    }

    fun searchContentForAssistFromNetwork(keyword: String): SearchResponse? {

        return searchRepository.searchForAssistFromNetwork(
            ParameterBuilder.buildSearchParams(
                keyword.toLowerCase(),
                false,
                "",
                currentUser
            )
        )
    }

    data class ContentSearchParam(
        val keyword: String?,
        val subscribedOnly: Boolean,
        val language: String?
    )

    fun getRecentSearches(limit: Int): LiveData<Resource<List<String>>> {
        recentSearchMutableLiveData.value = limit
        return recentSearchResponse
    }

    fun getRecentSearchesConsumed(limit: Int): LiveData<Resource<List<String>>> {
        recentSearchConsumedMutableLiveData.value = limit
        return recentSearchConsumedResponse
    }

    fun clearRecentSearch() {
        searchRepository.clearRecentSearch()
    }

    fun recentSearchConsumed(keyword: String) {
        searchRepository.recentSearchConsumed(keyword)
    }
}
