package com.airtel.vision.extensions

import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import com.airtel.vision.livedata.WiseLiveData
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status

/**
 * Created by VipulKumar on 25/09/18.
 */

/** Some observers need data only once on UI layer.
 If data has been dispatched with [Status.LOADING],
 we do not send data from [Status.SUCCESS].

 //TODO: make inline
 Kotlin compiler has a bug for inlining functions. This same function works in app but not in SDK.
 Will make it inline after the bug is resolved.
 */

fun <T : Resource<*>> LiveData<T>.observeDataOnce(
        lifecycleOwner: LifecycleOwner, observer: (T?) -> Unit) {
    var dataFromLoading: Any? = null
    this.observe(lifecycleOwner, Observer {
        when (it?.status) {
            Status.LOADING -> {
                dataFromLoading = it.data
                observer(it)
            }

            Status.SUCCESS -> {
                if (dataFromLoading == null) {
                    observer(it)
                }
            }

            Status.ERROR -> {
                observer(it)
            }
        }
    })
}

fun <T> absentLiveData(): LiveData<T> {
    return WiseLiveData()
}
