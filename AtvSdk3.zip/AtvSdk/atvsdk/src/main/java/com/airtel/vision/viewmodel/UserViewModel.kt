package com.airtel.vision.viewmodel

import android.app.Application
import com.airtel.vision.analytics.AnalyticsUtil
import com.airtel.vision.livedata.WiseLiveData
import com.airtel.vision.manager.ViaUserManager
import com.airtel.vision.service.UserConfigJob
import tv.airtel.data.domainmodule.util.CrashlyticsUtil
import tv.airtel.data.api.ParameterBuilder
import tv.airtel.data.api.ParameterBuilder.buildAvailablePlanParams
import tv.airtel.data.api.ParameterBuilder.buildGenerateOtpParams
import tv.airtel.data.api.ParameterBuilder.buildUpdateUserParams
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.error.AtvError
import tv.airtel.data.error.ErrorCodes
import tv.airtel.data.livedata.AbsentLiveData
import tv.airtel.data.model.ResultEntity
import tv.airtel.data.model.user.ActivateDeviceEntity
import tv.airtel.data.model.user.CurrentUser
import tv.airtel.data.model.user.IdentityEntity
import tv.airtel.data.model.user.LoginEntity
import tv.airtel.data.model.user.OtpSuccessEntity
import tv.airtel.data.model.user.UserConfig
import tv.airtel.data.model.user.plan.AvailablePlanEntity
import tv.airtel.data.model.user.profile.ProfileEntity
import tv.airtel.data.repo.UserRepository
import tv.airtel.data.utilmodule.manager.UserPreferenceManager
import tv.airtel.data.utilmodule.DeviceIdentifier
import tv.airtel.data.utilmodule.util.LogUtil
import tv.airtel.wynk.analytics.AnalyticsHashMap
import tv.airtel.wynk.analytics.util.AnalyticsConstants
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Created by AkashGupta on 29/03/18.
 * ViewModel for user related operations.
 */
@Singleton
internal class UserViewModel @Inject
constructor(private val userRepository: UserRepository) : BaseViewModel() {
    @Inject
    internal lateinit var application: Application
    @Suppress("MemberVisibilityCanBePrivate")
    @Inject
    internal lateinit var viaUserManager: ViaUserManager
    @Suppress("MemberVisibilityCanBePrivate")
    @Inject
    internal lateinit var currentUser: CurrentUser

    @Suppress("MemberVisibilityCanBePrivate")
    @Inject
    internal lateinit var userConfigJob: UserConfigJob
    @Inject
    internal lateinit var recentFavoriteViewModel: RecentFavoriteViewModel

    val currentUserMediatorLiveData = MediatorLiveData<Resource<CurrentUser>>()

    private var currentUserConfig: UserConfig? = null
    private var currentLoginEntity: LoginEntity? = null
    private var genOtpResponse: WiseLiveData<Resource<OtpSuccessEntity>> = WiseLiveData()

    private var updateUserConfigResponse: WiseLiveData<Resource<UserConfig>> = WiseLiveData()
    private var updateUserConfig: LiveData<Resource<UserConfig>>
    private var updateUserMutableLiveData = MutableLiveData<UpdateUserConfigTrigger>()

    private var availablePlansResponse: WiseLiveData<Resource<AvailablePlanEntity>> = WiseLiveData()
    private var availablePlans: LiveData<Resource<AvailablePlanEntity>>
    private var availablePlansMutableLiveData = MutableLiveData<Boolean>()

    private var getUserConfigResponse: WiseLiveData<Resource<UserConfig>> = WiseLiveData()
    private var getUserConfig: LiveData<Resource<UserConfig>>
    private var userConfigMutableLiveData = MutableLiveData<Boolean>()

    private var loginResponse = WiseLiveData<Resource<LoginEntity>>()
    private var loginEntity: LiveData<Resource<LoginEntity>>
    private var loginEntityMutableLiveData = MutableLiveData<Boolean>()

    private var generateOtpResponse = WiseLiveData<Resource<OtpSuccessEntity>>()
    private var generateOtpEntity: LiveData<Resource<OtpSuccessEntity>>
    private var generateOtpEntityMutableLiveData = MutableLiveData<String>()

    private var verifyOtpResponse = WiseLiveData<Resource<LoginEntity>>()
    private var verifyOtpEntity: LiveData<Resource<LoginEntity>>
    private var verifyOtpEntityMutableLiveData = MutableLiveData<VerifyOtpTrigger>()

    private var identifyUserResponse: WiseLiveData<Resource<IdentityEntity>> = WiseLiveData()
    private var activateDeviceResponse: WiseLiveData<Resource<ActivateDeviceEntity>> =
            WiseLiveData()
    private var verifyDeviceResponse: WiseLiveData<Resource<LoginEntity>> = WiseLiveData()

    private var otpSuccessEntity: LiveData<Resource<OtpSuccessEntity>> = AbsentLiveData.create()
    private var identityEntity: LiveData<Resource<IdentityEntity>> = AbsentLiveData.create()
    private var activateDeviceEntity: LiveData<Resource<ActivateDeviceEntity>> =
            AbsentLiveData.create()
    private var verifyDeviceEntity: LiveData<Resource<LoginEntity>> =
            AbsentLiveData.create()

    private var airtelOnlyResponseEntity: LiveData<Resource<ResultEntity>>
    private var airtelOnlyContentMutableLiveData = MutableLiveData<String?>()


    init {
        loginEntity = Transformations.switchMap(loginEntityMutableLiveData) {
            if (DeviceIdentifier.projectType == DeviceIdentifier.AppId.APP_PRIMETIME || DeviceIdentifier.projectType == DeviceIdentifier.AppId.APP_MITRA) {
                userRepository.loginUserForPrimeTime(ParameterBuilder
                        .buildLoginUserParams(application, viaUserManager.getGmaillD()), it)
            } else {
                userRepository.loginUser(ParameterBuilder
                        .buildLoginUserParams(application, viaUserManager.getGmaillD()), it)
            }
        }
        initLoginResponse()

        generateOtpEntity = Transformations.switchMap(generateOtpEntityMutableLiveData) {
            if (it != null) {
                userRepository
                        .generateOtp(buildGenerateOtpParams(application, it))
            } else {
                AbsentLiveData.create()
            }
        }
        initGenerateOtpResponse()

        verifyOtpEntity = Transformations.switchMap(verifyOtpEntityMutableLiveData) {
            if (it != null) {
                userRepository.loginUser(
                        ParameterBuilder
                                .buildVerifyOtpParams(application, it.email, it.mobNo, it.otp)
                )
            } else {
                AbsentLiveData.create()
            }
        }
        initVerifyOtpResponse()

        updateUserConfig = Transformations.switchMap(updateUserMutableLiveData) {
            if (it != null) {
                userRepository
                        .updateUserConfig(
                                buildUpdateUserParams(
                                        application,
                                        it.name, it.email, it.dob, it.lang
                                )
                        )
            } else {
                AbsentLiveData.create()
            }
        }
        initUpdateConfigResponse()

        airtelOnlyResponseEntity = Transformations.switchMap(airtelOnlyContentMutableLiveData) {
            if (it != null) {
                userRepository.checkForAirtelOnly(
                        ParameterBuilder
                                .buildAirtelOnlyParams(application, currentUser, it)
                )
            } else {
                AbsentLiveData.create()
            }
        }

        availablePlans = Transformations.switchMap(availablePlansMutableLiveData) {
            userRepository.getAvailablePlans(it, buildAvailablePlanParams(application))
        }
        initAvailablePlansResponse()

        getUserConfig = Transformations.switchMap(userConfigMutableLiveData) {
            userRepository.getUserConfig(it)
        }
        initGetUserConfigResponse()
    }

    private fun initLoginResponse() {
//        loginResponse.removeSource(loginEntity)
        loginResponse.addSource(loginEntity) {
            LogUtil.d("initLoginResponse ${it?.data?.msisdnDetected}")
            when (it?.status) {
                Status.SUCCESS -> {
                    it.data?.let { data ->
                        if (data?.msisdnDetected == true) {
                            onLoginSuccess(data)
                        }
                    }
                    updateCurrentUser(it.data)
                    loginResponse.dispatchSuccess(it)

                }
                Status.ERROR -> {
                    loginResponse.dispatchError(it)
//                    loginResponse.removeSource(loginEntity)
                    val properties = AnalyticsHashMap()
                    properties[AnalyticsConstants.FAILURE_REASON] = it.error?.errorUserMessage
                    properties[AnalyticsConstants.ERROR_CODE] = it.error?.errorCode.toString()

                    AnalyticsUtil.onRegistrationFailed(properties)
                }
                Status.LOADING -> {
                    loginResponse.dispatchLoading(it)
                }
            }
        }

    }

    private fun updateCurrentUser(data: LoginEntity?) {
        this.currentLoginEntity = data
        currentUser.buildCurrentUser(this.currentLoginEntity)
        currentUserMediatorLiveData.value = Resource.success(currentUser)
    }

    private fun updateCurrentUser(userConfig: UserConfig?){
        if (currentLoginEntity == null) {
            currentLoginEntity = LoginEntity()
        }
        if (userConfig != null) {
            this.currentLoginEntity?.userConfig = userConfig
        }
        currentUser
            .buildCurrentUser(this.currentLoginEntity)
        if (currentUser.isLoggedIn()) {
            recentFavoriteViewModel.handleSync()
        }
    }

    private fun initGenerateOtpResponse() {
        generateOtpResponse.addSource(generateOtpEntity) {
            when (it?.status) {
                Status.ERROR -> {
                    genOtpResponse.dispatchError(it)
                }
                Status.SUCCESS -> {
                    if (it.data != null && it.data?.success == true) {
                        genOtpResponse.dispatchSuccess(it)
                    } else {
                        genOtpResponse.dispatchError(
                                Resource.error(
                                        AtvError(
                                                ErrorCodes.AppError.OTP_GENERATION_FAILED,
                                                apiCode = ""
                                        ), it.data
                                )
                        )
                    }
                    genOtpResponse.dispatchSuccess(it)
                }
                Status.LOADING -> genOtpResponse.dispatchLoading(it)
            }
        }
    }

    private fun initVerifyOtpResponse() {
        verifyOtpResponse.removeSource(verifyOtpEntity)
        verifyOtpResponse.addSource(verifyOtpEntity) {
            LogUtil.d("initVerifyOtpResponse ${it?.data}")
            when (it?.status) {
                Status.ERROR -> {
                    verifyOtpResponse.dispatchError(it)
                    verifyOtpResponse.removeSource(verifyOtpEntity)
                }
                Status.SUCCESS -> {
                    if (it.data != null && it.data?.msisdnDetected == true) {
                        onLoginSuccess(it.data)
                        verifyOtpResponse.dispatchSuccess(it)
                    } else {
                        verifyOtpResponse.dispatchError(
                                Resource.error(
                                        AtvError(
                                                ErrorCodes.AppError.OTP_VERIFICATION_FAILED,
                                                if (it.data == null) ErrorCodes.AppSubError.RECEIVED_NULL_DATA
                                                else ErrorCodes.AppSubError.RECEIVED_SUCCESS_FALSE, ""
                                        )
                                        , it.data
                                )
                        )
                    }
                    verifyOtpResponse.removeSource(verifyOtpEntity)
                }
                Status.LOADING -> verifyOtpResponse.dispatchLoading(it)
            }
        }
    }

    private fun onLoginSuccess(data: LoginEntity?) {

        LogUtil.d("onLoginSuccess ${data?.uid}")
        UserPreferenceManager.getInstance(application).putString(
            UserPreferenceManager.KEY_USER_TOKEN, data?.token
                ?: "")
        UserPreferenceManager.getInstance(application)
                .putString(UserPreferenceManager.KEY_USER_UID, data?.uid ?: "")
        UserPreferenceManager.getInstance(application)
            .putBoolean(
                UserPreferenceManager.IS_USER_LOGGED_IN, data?.msisdnDetected
                    ?: false
            )

        if (data?.msisdnDetected == true) {
            startUserConfigJob(0, UserConfigJob.DEFAULT_CONFIG_INTERVAL_IN_SECONDS.toLong())
            if (currentUser.getLoginState() === CurrentUser.LOGIN_STATE.MOBILE_ONLY) {
                AnalyticsUtil.partialRegistrationEvent(AnalyticsConstants.AIRTEL)
            } else if (currentUser.getLoginState() === CurrentUser.LOGIN_STATE.EMAIL_COMPLETE) {
                AnalyticsUtil.completeRegistrationEvent(AnalyticsConstants.AIRTEL)
            }
            CrashlyticsUtil.setUserInfo(currentUser.uid, currentUser.email)
        }
        AnalyticsUtil.setMoEUserAttribute()
    }

    internal fun startUserConfigJob(delayInSecs: Long, intervalInSec: Long) {
        userConfigJob.startJob({
            getUserConfig().observeForever{}
        }, delayInSecs, intervalInSec)
    }

    private fun initUpdateConfigResponse() {
        updateUserConfigResponse.addSource(updateUserConfig) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> {
                    if (resource.data?.userInfo != null) {
                        updateUserConfigResponse.dispatchSuccess(resource)
                    } else {
                        updateUserConfigResponse.dispatchError(resource)
                    }
                }
                Status.ERROR -> updateUserConfigResponse.dispatchError(resource)
                Status.LOADING -> updateUserConfigResponse.dispatchLoading(resource)
            }
        }
    }


    private fun initGetUserConfigResponse() {
        getUserConfigResponse.addSource(getUserConfig) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> {
                    updateCurrentUser(resource.data)
                    AnalyticsUtil.setMoEUserAttribute()
                    getUserConfigResponse.dispatchSuccess(resource)}
                Status.ERROR -> getUserConfigResponse.dispatchError(resource)
                Status.LOADING -> getUserConfigResponse.dispatchLoading(resource)
            }
        }
    }

    private fun initAvailablePlansResponse() {
        availablePlansResponse.addSource(availablePlans) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> {
                    availablePlansResponse.dispatchSuccess(resource)
                }
                Status.LOADING -> {
                    availablePlansResponse.dispatchLoading(resource)
                }
                Status.ERROR -> {
                    availablePlansResponse.dispatchError(resource)
                }
            }
        }
    }

    internal fun identifyUser(): LiveData<Resource<IdentityEntity>> {
        identityEntity = userRepository.identifyUser(
                ParameterBuilder
                        .buildIdentifyUserParams(application)
        )
        identifyUserResponse.addSource(identityEntity) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> {
                    resource.data?.let { data ->
                        UserPreferenceManager.getInstance(application).putString(
                                UserPreferenceManager.KEY_USER_TOKEN, data.token
                                ?: ""
                        )
                        UserPreferenceManager.getInstance(application)
                                .putString(UserPreferenceManager.KEY_USER_UID, data.uid)
                        identifyUserResponse.dispatchSuccess(resource)
                        identifyUserResponse.removeSource(identityEntity)
                    }
                }
                Status.ERROR -> {
                    identifyUserResponse.dispatchError(resource)
                    identifyUserResponse.removeSource(identityEntity)
                }
                Status.LOADING -> identifyUserResponse.dispatchLoading(resource)
            }
        }
        return identifyUserResponse
    }

    internal fun activateDevice(): LiveData<Resource<ActivateDeviceEntity>> {
        activateDeviceEntity = userRepository.activateDevice(
                ParameterBuilder
                        .buildActivateDeviceParams(application)
        )
        activateDeviceResponse.addSource(activateDeviceEntity) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> {
                    resource.data?.let { data ->
                        UserPreferenceManager.getInstance(application).putString(
                                UserPreferenceManager.KEY_USER_TOKEN, data.token
                                ?: ""
                        )
                        UserPreferenceManager.getInstance(application)
                                .putString(UserPreferenceManager.KEY_USER_UID, data.uid)
                        activateDeviceResponse.dispatchSuccess(resource)
                        activateDeviceResponse.removeSource(activateDeviceEntity)
                    }
                }
                Status.ERROR -> {
                    activateDeviceResponse.dispatchError(resource)
                    activateDeviceResponse.removeSource(activateDeviceEntity)
                }
                Status.LOADING -> activateDeviceResponse.dispatchLoading(resource)
            }
        }
        return activateDeviceResponse
    }

    internal fun verifyDevice(devicePin: String): LiveData<Resource<LoginEntity>> {
        verifyDeviceEntity = userRepository.verifyDevice(
                DeviceIdentifier
                        .getDeviceIdentifierHeader(application.applicationContext), devicePin
        )
        verifyDeviceResponse.addSource(verifyDeviceEntity) { resource ->
            LogUtil.d("Verify Device ${resource?.status}")
            when (resource?.status) {
                Status.SUCCESS -> {
                    resource.data?.let { data ->
                        if (data?.msisdnDetected == true) {
                            onLoginSuccess(data)
                        }

                        verifyDeviceResponse.dispatchSuccess(resource)
                        verifyDeviceResponse.removeSource(verifyDeviceEntity)
                    }
                }
                Status.ERROR -> {
                    verifyDeviceResponse.dispatchError(resource)
                    verifyDeviceResponse.removeSource(verifyDeviceEntity)
                }
                Status.LOADING -> verifyDeviceResponse.dispatchLoading(resource)
            }
        }
        return verifyDeviceResponse
    }

    fun generateOtp(mobileNo: String?): LiveData<Resource<OtpSuccessEntity>> {
        otpSuccessEntity = userRepository
                .generateOtp(buildGenerateOtpParams(application, mobileNo))
        genOtpResponse.addSource(otpSuccessEntity) { resource ->
            when (resource?.status) {
                Status.ERROR -> {
                    genOtpResponse.dispatchError(resource)
                    genOtpResponse.removeSource(otpSuccessEntity)
                }
                Status.SUCCESS -> {
                    if (resource.data?.success == true) {
                        genOtpResponse.dispatchSuccess(resource)
                    } else {
                        genOtpResponse.dispatchError(
                                Resource.error(
                                        AtvError(
                                                ErrorCodes.AppError.OTP_GENERATION_FAILED,
                                                if (resource.data == null) ErrorCodes.AppSubError.RECEIVED_NULL_DATA
                                                else ErrorCodes.AppSubError.RECEIVED_SUCCESS_FALSE, ""
                                        )
                                        , resource.data
                                )
                        )
                    }
                    genOtpResponse.dispatchSuccess(resource)
                    genOtpResponse.removeSource(otpSuccessEntity)
                }
                Status.LOADING -> genOtpResponse.dispatchLoading(resource)
            }
        }
        return genOtpResponse
    }

    fun verifyOtp(mobileNo: String?, otp: String?): LiveData<Resource<LoginEntity>>? {
        verifyOtpEntityMutableLiveData.value =
                VerifyOtpTrigger(viaUserManager.getGmaillD(), mobileNo, otp)
        initVerifyOtpResponse()
        return verifyOtpResponse
    }

    internal fun updateUserConfigCall(
            name: String?, email: String?, dob: Long?,
            lang: ArrayList<String> = arrayListOf()
    ): LiveData<Resource<UserConfig>> {
        return userRepository
                .updateUserConfig(buildUpdateUserParams(application, name, email, dob, lang))
    }

    fun getCurrentUser(): CurrentUser? {
        return currentUser
    }

    internal fun loadCurrentUser(): LiveData<Resource<CurrentUser>> {
        LogUtil.d("loadCurrentUser()")
        loginUser(false).observeForever {  }
        return currentUserMediatorLiveData
    }

    fun isUserLoggedIn(): Boolean {
//        return userRepository.isLoggedIn()
        return UserPreferenceManager.getInstance(application)
            .getBoolean(UserPreferenceManager.IS_USER_LOGGED_IN, false)
    }

    fun checkForAirtelOnly(contentId: String?): LiveData<Resource<Boolean>> {
        airtelOnlyContentMutableLiveData.value = contentId
        return Transformations.map(airtelOnlyResponseEntity) {
            Resource(it.status, it.data?.success, it.error)
        }
    }

    fun getAvailablePlans(fetchFromNetwork: Boolean): LiveData<Resource<AvailablePlanEntity>> {
        availablePlansMutableLiveData.value = fetchFromNetwork
        return availablePlansResponse
    }

    fun updateUserConfig(name: String?, email: String?, dob: Long?, lang: ArrayList<String>):
            LiveData<Resource<UserConfig>> {
        updateUserMutableLiveData.value = UpdateUserConfigTrigger(name, email, dob, lang)
        return updateUserConfigResponse
    }

    fun loginUser(shouldFetch: Boolean = true): WiseLiveData<Resource<LoginEntity>> {
        loginEntityMutableLiveData.value = shouldFetch
        return loginResponse
    }

    fun getUserConfig(shouldFetch: Boolean = true): LiveData<Resource<UserConfig>> {
        userConfigMutableLiveData.value = shouldFetch
        return getUserConfigResponse
    }

    fun stopUserConfigJob() {
        userConfigJob.stop()
    }

    fun resetCurrentUser() {
        val blankLoginEntity = LoginEntity()
        blankLoginEntity.userConfig = UserConfig()
        currentUser.buildCurrentUser(blankLoginEntity, ProfileEntity())
    }

    data class UpdateUserConfigTrigger(
            var name: String?,
            var email: String?, var dob: Long?, var lang: ArrayList<String>
    )

    data class VerifyOtpTrigger(var email: String?, var mobNo: String?, var otp: String?)
}
