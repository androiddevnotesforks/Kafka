package com.airtel.vision.service

import android.os.Handler
import android.os.Looper
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Created by Satya on 04/04/18.
 *
 */
@Singleton
internal class UserConfigJob
@Inject constructor() :
        JobScheduler(UserConfigJob::class.java.simpleName, 99) {
    private val mainThreadHandler: Handler = Handler(Looper.getMainLooper())
    private var task: (() -> Unit)? = null
    fun startJob(task: () -> Unit, delay: Long, interval: Long) {
        this.task = task
        start(delay, interval)
    }

    override fun trigger() {
        mainThreadHandler.post {
            task?.let {
                it.invoke()
                done()
            }
        }
    }

    companion object {
        const val DEFAULT_CONFIG_INTERVAL_IN_SECONDS = 60 * 10
    }
}
