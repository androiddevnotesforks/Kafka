package tv.airtel.visionsample.di.modules

import dagger.Module

/**
 * Dagger module that provides objects which will live during the application lifecycle.
 */
@Module(includes = [(ViewModelModule::class)])
class AppModule {

}
