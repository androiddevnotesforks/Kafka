package tv.airtel.visionsample.activity

import android.app.Application
import androidx.lifecycle.Observer
import androidx.databinding.DataBindingUtil
import android.os.Bundle
import android.os.Handler
import android.text.TextUtils
import com.airtel.vision.AtvSdk
import com.airtel.vision.util.MemoryUtil
import com.airtel.vision.util.PermissionsUtil
import tv.airtel.data.api.model.Status
import tv.airtel.data.di.Injectable
import tv.airtel.data.utilmodule.DeviceIdentifier
import tv.airtel.data.utilmodule.FeedbackUtil
import tv.airtel.visionsample.R
import tv.airtel.visionsample.databinding.ActivitySplashBinding
import tv.airtel.visionsample.util.Navigator
import tv.airtel.wynk.analytics.AnalyticsHashMap
import tv.airtel.wynk.analytics.events.Event
import tv.airtel.wynk.analytics.util.AnalyticsConstants
import javax.inject.Inject

class SplashActivity : BaseActivity(), Injectable, PermissionsUtil.OnRunTimePermissionListener {
    private lateinit var binding: ActivitySplashBinding
    @Inject
    lateinit var applicationX: Application

    private var appLaunchFrom = AnalyticsConstants.APP_ICON
    private val WYNK_PUSH_META_INFO = "wynkPushMetaInfo"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_splash)
        applicationX.applicationContext
        sendAppInitEvent()
        managePermissions()
//        throw  RuntimeException("This is a crash")

//        Crashlytics.logException(Exception("test crash"))
    }

    override fun onResume() {
        super.onResume()

    }

    private fun managePermissions() {
        initConfigure()
        /*if (PermissionsUtil.isPermissionGranted(PermissionsUtil.PermissionType.TYPE_APP_START, this)) {
            initConfigure()
        } else {
            PermissionsUtil.requestPermission(PermissionsUtil.PermissionType.TYPE_APP_START, this)
        }*/
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        PermissionsUtil.onRequestPermissionsResult(this, requestCode, permissions, grantResults)
    }

    override fun onPermissionDenied(type: PermissionsUtil.PermissionType) {
        initConfigure()
    }

    override fun onPermissionGranted(type: PermissionsUtil.PermissionType) {
        initConfigure()
    }

    private fun initConfigure() {
        AtvSdk.getInstance().configure().observe(this, Observer { resource ->
            if (resource != null) {
                when (resource.status) {
                    Status.SUCCESS -> {
                        AtvSdk.getInstance().authenticateUserWithMsisdn("+912222222222")
//                        AtvSdk.getInstance().authenticateUserWithCustomerId("3018469643")
                                .observe(this, Observer {
                                    it.let {
                                        when (it?.status) {
                                            Status.SUCCESS -> {
                                                onConfigureSuccess()
                                            }
                                            else -> {
                                            }
                                        }
                                    }
                                })

                    }
                    Status.ERROR -> {
                        resource.error?.errorUserMessage?.let { FeedbackUtil.showMessage(this, it) }
                    }
                    else -> {
                    }
                }
            }
        })
    }

    private fun onConfigureSuccess() {
        // adding a delay because configure response is almost immediate
        Handler().postDelayed({
            finish()
            Navigator.startActivity(this, MainActivity::class.java)
        }, 1000)
    }

    private fun appLaunchedFrom(): String {
        val intentData = checkDeepLinkedData()
        if (!TextUtils.isEmpty(intentData)) {
            if (intentData!!.contains("wynkpremiere:")) {
                return AnalyticsConstants.DEEP_LINK
            }
        } else if (intent != null && !TextUtils.isEmpty(intent.getStringExtra(WYNK_PUSH_META_INFO))) {
            return AnalyticsConstants.NOTIFCATION
        }

        return AnalyticsConstants.APP_ICON
    }

    private fun sendAppInitEvent() {

        val properties = AnalyticsHashMap()
        properties.put(AnalyticsConstants.NETWORK_TYPE, DeviceIdentifier.getNetworkTypeInfo(applicationContext))
        properties.put(AnalyticsConstants.SOURCE, appLaunchFrom)
        properties.put(AnalyticsConstants.IMSI, DeviceIdentifier.getIMSI(applicationContext))
        properties.put(AnalyticsConstants.FREE_SPACE, MemoryUtil.getAvailableSpaceInMB().toString() + "mb")
        AtvSdk.getInstance().getAnalytics().trackEvent(Event.APP_INIT, properties)

    }

    private fun checkDeepLinkedData(): String? {
        val intent = intent
        val data = intent.data
        val deepLinkingUrl = data?.toString()

        return deepLinkingUrl
    }
}
