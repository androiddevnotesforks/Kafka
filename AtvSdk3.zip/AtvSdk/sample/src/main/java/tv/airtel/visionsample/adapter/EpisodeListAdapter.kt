package tv.airtel.visionsample.adapter

import com.airbnb.epoxy.TypedEpoxyController
import timber.log.Timber
import tv.airtel.data.model.content.detail.Episode
import tv.airtel.visionsample.ItemEpisodeBindingModel_
import tv.airtel.visionsample.ItemHomeCardSeparatorBindingModel_
import tv.airtel.visionsample.ItemSeasonHeaderBindingModel_
import java.lang.RuntimeException

/**
 * Epoxy controller for building and adding models to recyclerView in related content list on detail page.
 */
class EpisodeListAdapter constructor(val itemClickListener: ItemClickListener)
    : TypedEpoxyController<List<Episode>>() {
    override fun buildModels(list: List<Episode>?) {


        if (list != null && list.isNotEmpty()) {
            ItemHomeCardSeparatorBindingModel_()
                    .id("id_sep")
                    .addTo(this)

            ItemSeasonHeaderBindingModel_()
                    .id("id_season_header")
                    .addTo(this)

            list.forEach {
                ItemEpisodeBindingModel_()
                        .id(it.refId!!)
                        .itemClickListener { model, parentView, clickedView, position ->
                            itemClickListener.onEpisodeItemClicked(model.episode())
                        }
                        .episode(it)
                        .addTo(this)
            }
        }
    }

    interface ItemClickListener {
        fun onEpisodeItemClicked(episode: Episode)
    }

    override fun onExceptionSwallowed(exception: RuntimeException) {
        // we swallow exceptions related to duplicate IDs for now
        Timber.e(exception.cause)
    }
}