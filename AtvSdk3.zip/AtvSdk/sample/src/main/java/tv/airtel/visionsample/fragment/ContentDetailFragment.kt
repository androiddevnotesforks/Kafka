package tv.airtel.visionsample.fragment

import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.content.Intent
import android.os.Bundle
import androidx.core.content.ContextCompat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.di.Injectable
import tv.airtel.data.model.PeopleProfile
import tv.airtel.data.model.content.Content
import tv.airtel.data.model.content.ContentDetail
import tv.airtel.data.model.content.detail.Episode
import tv.airtel.data.model.content.detail.EpisodeDetail
import tv.airtel.data.model.content.detail.SeasonDetail
import tv.airtel.data.model.content.related.RelatedContent
import tv.airtel.data.model.content.related.RelatedSports
import tv.airtel.data.model.search.SearchResponse
import tv.airtel.data.model.user.UserConfig
import tv.airtel.data.model.user.profile.ProfileEntity
import tv.airtel.data.utilmodule.FeedbackUtil
import tv.airtel.data.utilmodule.util.LogUtil
import tv.airtel.visionsample.R
import tv.airtel.visionsample.activity.MainActivity
import tv.airtel.visionsample.activity.VisionPlayerActivity
import tv.airtel.visionsample.adapter.EpisodeListAdapter
import tv.airtel.visionsample.adapter.RelatedContentAdapter
import tv.airtel.visionsample.adapter.RelatedSportsAdapter
import tv.airtel.visionsample.databinding.FragmentContentDetailBinding
import tv.airtel.visionsample.util.AutoClearedValue
import tv.airtel.visionsample.util.Navigator
import tv.airtel.visionsample.util.ext.inflateWithDataBinding
import tv.airtel.visionsample.util.ext.isNotNullOrEmpty
import tv.airtel.visionsample.viewmodel.SampleContentViewModel
import tv.airtel.visionsample.viewmodel.SampleUserViewModel

/**
 * Created by VipulKumar on 2/22/18.
 *
 */
class ContentDetailFragment : BaseFragment(), Injectable {
    private lateinit var binding: AutoClearedValue<FragmentContentDetailBinding>
    private lateinit var sampleContentViewModel: SampleContentViewModel
    private lateinit var sampleUserViewModel: SampleUserViewModel
    private lateinit var relatedContentAdapter: RelatedContentAdapter
    private lateinit var relatedSportsAdapter: RelatedSportsAdapter
    private lateinit var episodeListAdapter: EpisodeListAdapter
    private lateinit var contentDetail: ContentDetail
    private var contentId: String = ""
    private var contentType: String = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val dataBinding = container
            ?.inflateWithDataBinding(R.layout.fragment_content_detail)
                as FragmentContentDetailBinding
        binding = AutoClearedValue(this, dataBinding)
        return dataBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        contentId = arguments?.getString("contentId") ?: ""
        contentType = arguments?.getString("contentType") ?: ""
        initUi()
        initViewModels()
        fetchContentDetail(contentId)
        fetchRelatedContent(contentId)
    }

    private fun initUi() {
        hidePlayer()
        relatedContentAdapter =
                RelatedContentAdapter(object : RelatedContentAdapter.ItemClickListener {
                    override fun onContentItemClicked(content: Content) {
                        if (activity is MainActivity) {
                            (activity as MainActivity)
                                .launchContentDetailFragment(content.id, content.programType!!)
                        }
                    }
                })
        recycler_view_related.adapter = relatedContentAdapter.adapter
        // this degrades performance but we won't need recycling as the grids are small in size
        recycler_view_related.isNestedScrollingEnabled = false

        relatedSportsAdapter =
                RelatedSportsAdapter(object : RelatedSportsAdapter.ItemClickListener {
                    override fun onContentItemClicked(content: Content) {
                        if (activity is MainActivity) {
                            (activity as MainActivity)
                                .launchContentDetailFragment(content.id, content.programType!!)
                        }
                    }
                })
        recycler_view_sports_related.adapter = relatedSportsAdapter.adapter
        // this degrades performance but we won't need recycling as the grids are small in size
        recycler_view_sports_related.isNestedScrollingEnabled = false

        episodeListAdapter = EpisodeListAdapter(object : EpisodeListAdapter.ItemClickListener {
            override fun onEpisodeItemClicked(episode: Episode) {
                sampleContentViewModel.fetchContentDetail(episode.refId)
            }
        })
        recycler_view_episodes.adapter = episodeListAdapter.adapter
        recycler_view_episodes.isNestedScrollingEnabled = false

        iv_favorite.setOnClickListener {
            if (contentDetail.isFavorite != null) {
                if (contentDetail.isFavorite!!) {
                    sampleContentViewModel.markFavorite(contentId, false)
                } else {
                    sampleContentViewModel.markFavorite(contentId, true)
                }
            }
        }


        player_view.setOnClickListener {
            //            if (::contentDetail.isInitialized) {
//                val intent = Intent(context!!, PlayerActivity::class.java)
//                intent.putExtra(Constants.EXTRA_INTENT_CONTENT_DETAIL, contentDetail)
//                Navigator.startActivity(context!!, intent)
//            } else {
//                FeedbackUtil.showMessage(context!!, getString(R.string.please_wait_for_data_to_load))
//            }

            if (::contentDetail.isInitialized) {
                val intent = Intent(context!!, VisionPlayerActivity::class.java)
                intent.putExtra("content", contentDetail)
                Navigator.startActivity(context!!, intent)
            } else {
                FeedbackUtil.showMessage(
                    context!!,
                    getString(R.string.please_wait_for_data_to_load)
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
    }

    private fun initViewModels() {
        sampleContentViewModel = ViewModelProviders.of(this)
            .get(SampleContentViewModel::class.java)

        sampleUserViewModel = ViewModelProviders.of(this)
            .get(SampleUserViewModel::class.java)

        //  observe the changes on content
        sampleContentViewModel.contentDetail?.observe(this, Observer {
            onContentResponse(it)
        })

        sampleContentViewModel.contentRelatedList?.observe(this, Observer {
            onRelatedContentResponse(it)
        })

        sampleContentViewModel.sportsRelatedList?.observe(this, Observer {
            onRelatedSportsResponse(it)
        })

        sampleContentViewModel.contentSeasonDetail?.observe(this, Observer {
            onSeasonDetailResponse(it)
        })

        sampleContentViewModel.contentEpisodeDetail?.observe(this, Observer {
            onEpisodeDetailResponse(it)
        })

        sampleContentViewModel.userConfig?.observe(this, Observer {
            onUserConfigUpdated(it)
        })

        sampleContentViewModel.peopleContent?.observe(this, Observer {
            onPeopleRelatedResponse(it)
        })

        sampleContentViewModel.peopleProfile?.observe(this, Observer {
            onPeopleProfileResponse(it)
        })

        sampleUserViewModel.airtelOnlyResponse?.observe(this, Observer {
            if (it?.status == Status.SUCCESS && it.data != null) {
                val message = if (it.data!!) "Success" else "Failure"
                FeedbackUtil.showMessage(context!!, message)
            }
        })

//        sampleUserViewModel.checkForAirtelOnly(contentId)

        sampleContentViewModel.markFavorite?.observe(this, Observer {
            if (it?.status == Status.SUCCESS) {
                contentDetail.isFavorite = !contentDetail.isFavorite!!
                iv_favorite.setColorFilter(
                    when (contentDetail.isFavorite) {
                        true -> ContextCompat.getColor(context!!, R.color.colorPrimary)
                        else -> ContextCompat.getColor(context!!, R.color.icon_tint)
                    }
                )
            }
        })
        sampleContentViewModel.updateUserConfig("bh")

        sampleContentViewModel.userProfiles?.observe(this, Observer {
            onProfilesFetched(it)
        })

//        sampleContentViewModel.getProfiles()
    }

    private fun onProfilesFetched(it: Resource<ProfileEntity>?) {
        LogUtil.d(it?.status.toString())
    }

    private fun onUserConfigUpdated(it: Resource<UserConfig>?) {
        LogUtil.d(it?.status.toString())
    }

    private fun onPeopleProfileResponse(it: Resource<PeopleProfile>?) {
        it?.data?.images?.portrait
    }

    private fun onPeopleRelatedResponse(it: Resource<SearchResponse>?) {
        LogUtil.e(it?.data?.toString() ?: "")
    }

    private fun onEpisodeDetailResponse(resource: Resource<EpisodeDetail>?) {
        binding.get()?.resource = resource
        if (resource?.data != null && resource.data!!.episodes.isNotNullOrEmpty()) {
            episodeListAdapter.setData(resource.data!!.episodes!!)
        }
    }

    private fun onSeasonDetailResponse(resource: Resource<SeasonDetail>?) {
        binding.get()?.resource = resource
        //resource is null
        if (resource?.data != null) {
            binding.get()?.content = resource.data
            contentDetail = resource.data!!
            if (resource.data!!.seriesTvSeasons.isNotNullOrEmpty()) {
                sampleContentViewModel
                    .fetchEpisodeDetail(resource.data!!.seriesTvSeasons!![0].seasonId!!)
            } else {
                sampleContentViewModel.fetchEpisodeDetail(contentId)
            }
        }
    }

    private fun fetchContentDetail(contentId: String) {
        when (contentType) {
            "TVSHOW", "LIVETVSHOW" -> sampleContentViewModel.fetchSeasonDetail(contentId)
            else -> sampleContentViewModel.fetchContentDetail(contentId)
        }
    }

    private fun fetchRelatedContent(contentId: String) {
        when (contentType) {
            "TVSHOW", "LIVETVSHOW" -> {
            }
            "SPORTS" -> sampleContentViewModel.fetchRelatedSports(contentId)
            else -> sampleContentViewModel.fetchRelatedContent(contentId)
        }
    }

    private fun onRelatedContentResponse(resource: Resource<RelatedContent>?) {
        if (resource?.data?.relatedContentDetailsEntity?.results.isNotNullOrEmpty()) {
            relatedContentAdapter.setData(resource?.data?.relatedContentDetailsEntity?.results)
        }
    }

    private fun onRelatedSportsResponse(resource: Resource<RelatedSports>?) {
        if (resource?.data?.sportsRelatedContentDetailsEntity != null) {
            relatedSportsAdapter.setData(resource.data!!)
        }
    }

    private fun onContentResponse(resource: Resource<ContentDetail>?) {
        binding.get()?.resource = resource
        if (resource?.data != null) {
            binding.get()?.content = resource.data
            contentDetail = resource.data!!
            showPlayer()

            sampleContentViewModel.fetchPeopleRelated(resource.data?.credits!![0].id!!)
//            sampleContentViewModel.fetchPeopleProfile(resource.data?.credits?.get(0)?.id ?: "")
            sampleContentViewModel.fetchPeopleProfile("5ad065e1e4b04b8cc71ca7e4")
        }
    }

    private fun showPlayer() {
        video_overlay.visibility = View.VISIBLE
        iv_play.visibility = View.VISIBLE
    }

    private fun hidePlayer() {
        video_overlay.visibility = View.GONE
        iv_play.visibility = View.GONE
    }

    companion object {
        fun newInstance(contentId: String, contentType: String): ContentDetailFragment {
            val args = Bundle()
            val fragment = ContentDetailFragment()
            args.putString("contentId", contentId)
            args.putString("contentType", contentType)
            fragment.arguments = args
            return fragment
        }
    }
}
