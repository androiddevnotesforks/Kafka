package tv.airtel.visionsample.fragment

import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.airtel.vision.AtvSdk
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.di.Injectable
import tv.airtel.data.model.content.RowItemContent
import tv.airtel.data.utilmodule.FeedbackUtil
import tv.airtel.visionsample.R
import tv.airtel.visionsample.activity.LoginActivity
import tv.airtel.visionsample.databinding.FragmentProfileBinding
import tv.airtel.visionsample.util.AutoClearedValue
import tv.airtel.visionsample.util.Navigator
import tv.airtel.visionsample.util.ext.inflateWithDataBinding
import tv.airtel.visionsample.viewmodel.SampleContentViewModel

/**
 * Created by VipulKumar on 2/22/18.
 *
 */
class ProfileFragment : BaseFragment(), Injectable {
    private lateinit var binding: AutoClearedValue<FragmentProfileBinding>
    private lateinit var sampleContentViewModel: SampleContentViewModel
    private val vision = AtvSdk.getInstance()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val dataBinding = container?.inflateWithDataBinding(R.layout.fragment_profile)
                as FragmentProfileBinding
        binding = AutoClearedValue(this, dataBinding)
        return dataBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initUi()
        initViewModels()
    }

    private fun initUi() {
        binding.get()?.user = vision.getCurrentUser()
        binding.get()?.authLayout?.setOnClickListener { Navigator.startActivity(context!!, LoginActivity::class.java) }
        favorites.setOnClickListener {
            sampleContentViewModel.fetchFavorites()
        }
        sign_out.setOnClickListener {

        }
    }

    private fun initViewModels() {
        sampleContentViewModel = ViewModelProviders.of(this)
                .get(SampleContentViewModel::class.java)

        sampleContentViewModel.favoritesList.observe(this, Observer { onFavoriteListResponse(it) })

    }

    private fun onFavoriteListResponse(resource: Resource<List<RowItemContent>>?) {
        when (resource?.status) {
            Status.ERROR, Status.SUCCESS -> FeedbackUtil.showMessage(context!!, resource.status.toString())
            else -> {
            }
        }

        Log.d("Featured Fragment", "Response ${resource?.status} ${resource?.data}")
    }

    companion object {
        fun newInstance(): ProfileFragment {
            val args = Bundle()
            val fragment = ProfileFragment()
            fragment.arguments = args
            return fragment
        }
    }
}
