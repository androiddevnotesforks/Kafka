package tv.airtel.visionsample.viewmodel

import androidx.lifecycle.ViewModel

/**
 * Created by VipulKumar on 2/22/18.
 * A ViewModel to inherit from.
 */
open class BaseViewModel : ViewModel()
