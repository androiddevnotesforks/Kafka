package tv.airtel.visionsample.di.modules

import dagger.Module
import dagger.android.ContributesAndroidInjector
import tv.airtel.visionsample.fragment.*

/**
 * DI module for Fragments.
 */
@Module
abstract class FragmentBuildersModule {
    @ContributesAndroidInjector
    internal abstract fun contributeHomeFragment(): HomeFragment

    @ContributesAndroidInjector
    internal abstract fun contributeFeaturedFragment(): ContentListFragment

    @ContributesAndroidInjector
    internal abstract fun contributeProfileFragment(): ProfileFragment

    @ContributesAndroidInjector
    internal abstract fun contributeContentDetailFragment(): ContentDetailFragment

    @ContributesAndroidInjector
    internal abstract fun contributeLoginFragment(): LoginFragment

    @ContributesAndroidInjector
    internal abstract fun contributeSearchFragment(): SearchFragment
}