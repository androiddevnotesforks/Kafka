package tv.airtel.visionsample.util

/**
 * Created by Aditya Mehta on 25/04/18.
 */
class Constants {
    companion object {
        const val EXTRA_INTENT_CONTENT_DETAIL = "wynk.stb.contentDetail"
    }
}