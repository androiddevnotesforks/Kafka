package tv.airtel.visionsample.activity

import androidx.lifecycle.Observer
import android.os.Bundle
import android.support.design.widget.BottomSheetDialog
import android.util.Log
import com.airtel.vision.AtvSdk
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.dialog_auth.view.*
import tv.airtel.data.api.model.Status
import tv.airtel.data.di.Injectable
import tv.airtel.visionsample.R
import tv.airtel.visionsample.fragment.ContentDetailFragment
import tv.airtel.visionsample.fragment.HomeFragment
import tv.airtel.visionsample.fragment.SearchFragment
import tv.airtel.visionsample.fragment.observeK
import tv.airtel.visionsample.util.Navigator
import tv.airtel.visionsample.util.ext.inTransaction
import tv.airtel.visionsample.util.widget.WynkSearchView

class MainActivity : BaseActivity(), Injectable {
    private val vision = AtvSdk.getInstance()
    private val searchFragment = SearchFragment.newInstance()
    private var bottomSheetDialog: BottomSheetDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(0, 0)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initUi()
        showBottomSheetIfEligible()

    }

    private fun initUi() {
        search_view.searchToggleListener = object : WynkSearchView.SearchToggleListener {
            override fun onSearchOpened() {
                supportFragmentManager.inTransaction {
                    add(R.id.fragment_container, searchFragment)
                            .addToBackStack("")
                }
            }

            override fun onSearchClosed() {
                supportFragmentManager.inTransaction {
                    remove(searchFragment)
                }
            }
        }

        search_view.setSearchTextChangeListener(object : WynkSearchView.SearchTextChangeListener {
            override fun onSearchTextChanged(text: String) {

            }

            override fun onSearchTextSubmit(text: String) {
                searchFragment.setSearchText(text)
            }
        })

        AtvSdk.getInstance().deleteProfile("").observeK(this) {
//            LogUtil.d("Delete profile ${it?.status} ${it?.error}")
        }

        launchFeaturedFragment()
    }

    override fun onResume() {
        hideBottomSheetIfEligible()
        super.onResume()
    }

    private fun launchFeaturedFragment() {
        supportFragmentManager.inTransaction {
            replace(R.id.fragment_container, HomeFragment.newInstance())
        }
    }

    internal fun launchContentDetailFragment(contentId: String, contentType: String) {
        supportFragmentManager.inTransaction {
            addToBackStack("")
            add(R.id.fragment_container, ContentDetailFragment.newInstance(contentId, contentType))
        }
    }

    override fun onBackPressed() {
        val fragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
        if (fragment != null && fragment is ContentDetailFragment) {
            supportFragmentManager.popBackStackImmediate()
        } else if (search_view != null && search_view.isSearchShown) {
            search_view.hideSearch()
        } else {
            super.onBackPressed()
        }
    }

    private fun showBottomSheetIfEligible() {
        val currentUser = vision.getCurrentUser()
        if (currentUser != null && !currentUser.isLoggedIn()) {

            if (!AtvSdk.getInstance().isUserLoggedIn()) {
                AtvSdk.getInstance()

//                    .authenticateUserWithMsisdn("+919717870359")
                        .authenticateUserWithMsisdn("+919560011966")
//                    .authenticateUserWithMsisdn("+912222222222")
//                    .authenticateUserWithMsisdn("+919999069011")
                        //this code will not be in
                        .observe(this, Observer { resource ->
                            resource.let {
                                when (it?.status) {
                                    Status.SUCCESS -> {
                                        Log.i("loginResult", "result is success")
                                    }
                                    else -> {
                                        Log.i("loginResult", "result is success status " + it?.status)
                                    }
                                }
                            }
                        })
            }

            showBottomSheet()
        }
    }

    private fun hideBottomSheetIfEligible() {

        if (AtvSdk.getInstance().getCurrentUser()?.isLoggedIn()!!) {
            if (bottomSheetDialog != null && bottomSheetDialog?.isShowing!!) {
                bottomSheetDialog?.dismiss()
            }
        }
    }

    private fun showBottomSheet() {
        bottomSheetDialog = BottomSheetDialog(this)
        val sheetView = this.layoutInflater.inflate(R.layout.dialog_auth, null)
        bottomSheetDialog?.setContentView(sheetView)
        sheetView.btn_register.setOnClickListener {
            Navigator.startActivityWithClipReveal(this,
                    LoginActivity::class.java, sheetView.btn_register)
            bottomSheetDialog?.dismiss()
        }
        bottomSheetDialog?.show()
    }
}
