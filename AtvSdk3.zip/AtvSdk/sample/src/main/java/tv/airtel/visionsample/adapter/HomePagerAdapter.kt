package tv.airtel.visionsample.adapter

import androidx.core.app.Fragment
import androidx.core.app.FragmentManager
import androidx.core.app.FragmentPagerAdapter
import tv.airtel.data.model.user.Page
import tv.airtel.visionsample.fragment.ContentListFragment
import tv.airtel.visionsample.fragment.ProfileFragment

internal
class HomePagerAdapter(fragmentManager: FragmentManager,
                       private val pages: ArrayList<Page>) : FragmentPagerAdapter(fragmentManager) {

    override fun getItem(position: Int): Fragment {
        if (position == 4) {
            return ProfileFragment.newInstance()
        }
        return ContentListFragment.newInstance(pages[position].id)
    }

    override fun getCount(): Int {
        return pages.size
    }
}
