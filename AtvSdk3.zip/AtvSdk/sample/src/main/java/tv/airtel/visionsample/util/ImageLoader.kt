package tv.airtel.visionsample.util

import android.content.Context
import android.text.TextUtils
import android.widget.ImageView
import com.bumptech.glide.Glide
import tv.airtel.visionsample.R

/**
 * Authored by vipulkumar on 27/09/17.
 */

object ImageLoader {
    fun loadImage(context: Context, url: String?, imageView: ImageView) {
        if (!TextUtils.isEmpty(url)) {
            Glide.with(context)
                    .load(url)
                    .into(imageView)
        } else {
            Glide.with(context)
                    .load(R.color.background_dark_200)
                    .into(imageView)
        }
    }
}
