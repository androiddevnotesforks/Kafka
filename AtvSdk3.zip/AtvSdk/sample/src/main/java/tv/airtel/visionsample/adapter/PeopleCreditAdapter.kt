package tv.airtel.visionsample.adapter

import com.airbnb.epoxy.CarouselModel_
import com.airbnb.epoxy.TypedEpoxyController
import tv.airtel.data.model.content.Credit
import tv.airtel.visionsample.ItemArtistProfileBindingModel_
import tv.airtel.visionsample.ItemHomeCardSeparatorBindingModel_
import tv.airtel.visionsample.util.ext.isNotNullOrEmpty

class PeopleCreditAdapter constructor(val itemClickListener: ItemClickListener)
    : TypedEpoxyController<List<Credit>>() {
    override fun buildModels(list: List<Credit>) {
        val models = arrayListOf<ItemArtistProfileBindingModel_>()

        if (list.isNotNullOrEmpty()) {
            ItemHomeCardSeparatorBindingModel_()
                    .id("id_sep")
                    .addTo(this)

                list.mapTo(models) {
                    ItemArtistProfileBindingModel_()
                            .id(it.id!!)
                            .itemClickListener { model, parentView, clickedView, position ->
                                itemClickListener.onContentItemClicked(model.credit())
                            }
                            .credit(it)
                }

                CarouselModel_()
                        .id("list")
                        .models(models)
                        .numViewsToShowOnScreen(4.2f)
                        .addTo(this)
            }
        }

    interface ItemClickListener {
        fun onContentItemClicked(credit: Credit)
    }
}