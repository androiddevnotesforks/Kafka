package tv.airtel.visionsample

import android.app.Activity
import android.app.Application
import com.airtel.vision.AtvSdk
import com.facebook.stetho.Stetho
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasActivityInjector
import hugo.weaving.DebugLog
import timber.log.Timber
import tv.airtel.visionsample.di.DaggerInjector
import tv.airtel.visionsample.util.epoxy.EpoxyGlobalSettings
import javax.inject.Inject

/**
 * Created by VipulKumar on 1/16/18.
 * Application class for the project.
 */

class AtvApplication : Application(), HasActivityInjector {
    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Activity>

    override fun activityInjector(): DispatchingAndroidInjector<Activity>? {
        return dispatchingAndroidInjector
    }

    @DebugLog
    override fun onCreate() {
        super.onCreate()

        Stetho.initializeWithDefaults(this)
        initTimber()
        initDagger()
        initEpoxy()
        initVision()
    }

    private fun initTimber() {
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
    }

    private fun initVision() {
        AtvSdk.getInstance().init(this, "", true,
                AtvSdk.Flavour.STAGING, AtvSdk.DeviceType.DEVICE_STICK)
    }

    private fun initDagger() {

        // prepare to inject all activities and fragments at application startup
        DaggerInjector.injectAll(this)
    }

    private fun initEpoxy() {
        // make default snapping behaviour in all recyclerViews to 'none'
        EpoxyGlobalSettings.setSnapHelper()
    }
}
