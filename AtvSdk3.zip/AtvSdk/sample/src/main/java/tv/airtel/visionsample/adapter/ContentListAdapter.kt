package tv.airtel.visionsample.adapter

import com.airbnb.epoxy.CarouselModel_
import com.airbnb.epoxy.EpoxyModel
import com.airbnb.epoxy.Typed2EpoxyController
import com.airtel.vision.AtvSdk
import tv.airtel.data.model.content.BaseRow
import tv.airtel.data.model.content.Content
import tv.airtel.data.model.layout.RowSubType
import tv.airtel.data.model.user.Page
import tv.airtel.visionsample.ItemHomeCardBannerBindingModel_
import tv.airtel.visionsample.ItemHomeCardContinueWatchingBindingModel_
import tv.airtel.visionsample.ItemHomeCardHeaderBindingModel_
import tv.airtel.visionsample.ItemHomeCardLandscapeBindingModel_
import tv.airtel.visionsample.ItemHomeCardLogoBindingModel_
import tv.airtel.visionsample.ItemHomeCardPortraitBindingModel_
import tv.airtel.visionsample.ItemHomeCardSeparatorBindingModel_
import tv.airtel.visionsample.ItemHomeFooterBindingModel_
import tv.airtel.visionsample.util.ext.isNotNullOrEmpty
import java.util.ArrayList

/**
 * Epoxy controller for building and adding models to recyclerView on homepage.
 * We use [CarouselModel_]s to build inner recyclerViews so that they share the RecyclerViewPool
 * and utilize other optimizations provided by Epoxy.
 * Having single adapter for entire homepage also simplifies things for us.
 * See https://github.com/airbnb/epoxy for more info.
 */
class ContentListAdapter constructor(val itemClickListener: ItemClickListener)
    : Typed2EpoxyController<List<BaseRow>, String>() {
    var pageId = ""
    override fun buildModels(list: List<BaseRow>?, pageId: String) {
        setFilterDuplicates(true)
        this.pageId = pageId
        var pages: List<Page>? = AtvSdk.getInstance().getAppConfig()?.pages
//        val titleMap = mapOf(pages?.get(0)?.id to pages?.get(0)?.title,
//                pages?.get(1)?.id to "Explore", pages?.get(2)?.id to pages?.get(2)?.title, pages?.get(3)?.id to pages?.get(3)?.title)

        // show search bar on explore page
//        if (titleMap[pageId].equals("Explore")) {
//            ItemHomeSearchBindingModel_()
//                    .id("id_search")
//                    .addTo(this)
//        } else {
//            ItemHomeHeadingBindingModel_()
//                    .id("id_title")
//                    .text(titleMap[pageId])
//                    .addTo(this)
//        }

        // logic to add row items is temporary and for demo purposes only
        list?.forEach {
            if (it.contents?.content != null && it.subType != null) {
                when {
                    it.subType?.name?.startsWith("TVSHOW", true)!! -> {
                        if (it.contents?.content.isNotNullOrEmpty()
                                && it.contents?.content!![0].programType == "LIVETVCHANNEL") {
                            // do not add
                        } else {
                            val models = addLandscapeItems(it).distinct()
                            addHeadingItem(it)
                            addCarouselModels(it, models, 1.5f)
                            addSeparatorItem(it)
                        }
                    }

                    it.subType == RowSubType.BANNER -> {
                        val models = addBannerItems(it).distinct()
                        addCarouselModels(it, models, 1.03f)
                    }

                    it.subType == RowSubType.CONTINUE_WATCHING -> {
                        val models = addContinueWatchingItems(it).distinct()
                        it.title = "Continue Watching"
                        addHeadingItem(it)
                        addCarouselModels(it, models, 2.75f)
                        addSeparatorItem(it)
                    }

                    else -> {
                        val models = addPortraitItems(it).distinct()
                        addHeadingItem(it)
                        addCarouselModels(it, models, 2.7f)
                        addSeparatorItem(it)
                    }
                }
            }
        }

        ItemHomeFooterBindingModel_()
                .id("id_footer")
                .addTo(this)
    }

    private fun addPortraitItems(it: BaseRow): ArrayList<ItemHomeCardPortraitBindingModel_> {
        val models = arrayListOf<ItemHomeCardPortraitBindingModel_>()
        it.contents?.content?.forEach {
            models.add(ItemHomeCardPortraitBindingModel_()
                    .id(it.id!!)
                    .itemClickListener { model, parentView, clickedView, position ->
                        itemClickListener.onContentItemClicked(model.content())
                    }
                    .content(it))
        }
        return models
    }


    private fun addLandscapeItems(it: BaseRow): ArrayList<ItemHomeCardLandscapeBindingModel_> {
        val models = arrayListOf<ItemHomeCardLandscapeBindingModel_>()
        it.contents?.content?.forEach {
            models.add(ItemHomeCardLandscapeBindingModel_()
                    .id(it.id!!)
                    .itemClickListener { model, parentView, clickedView, position ->
                        itemClickListener.onContentItemClicked(model.content())
                    }
                    .content(it))
        }
        return models
    }

    private fun addLogoItems(it: BaseRow): ArrayList<ItemHomeCardLogoBindingModel_> {
        val models = arrayListOf<ItemHomeCardLogoBindingModel_>()
        it.contents?.content?.forEach {
            models.add(ItemHomeCardLogoBindingModel_()
                    .id(it.id!!)
                    .itemClickListener { model, parentView, clickedView, position ->
                        itemClickListener.onContentItemClicked(model.content())
                    }
                    .content(it))
        }
        return models
    }

    private fun addBannerItems(it: BaseRow): ArrayList<ItemHomeCardBannerBindingModel_> {
        val models = arrayListOf<ItemHomeCardBannerBindingModel_>()
        it.contents?.content?.forEach {
            models.add(ItemHomeCardBannerBindingModel_()
                    .id(it.id!!)
                    .itemClickListener { model, parentView, clickedView, position ->
                        itemClickListener.onContentItemClicked(model.content())
                    }
                    .content(it))
        }
        return models
    }

    private fun addContinueWatchingItems(it: BaseRow): ArrayList<ItemHomeCardContinueWatchingBindingModel_> {
        val models = arrayListOf<ItemHomeCardContinueWatchingBindingModel_>()
        it.contents?.content?.forEach {
            models.add(ItemHomeCardContinueWatchingBindingModel_()
                    .id(it.id!!)
                    .itemClickListener { model, parentView, clickedView, position ->
                        itemClickListener.onContentItemClicked(model.content())
                    }
                    .content(it))
        }
        return models
    }

    private fun addHeadingItem(it: BaseRow) {
        ItemHomeCardHeaderBindingModel_()
                .id(it.id + " heading")
                .text(it.title)
                .addTo(this)
    }

    private fun addSeparatorItem(it: BaseRow) {
        ItemHomeCardSeparatorBindingModel_()
                .id(it.id + " sep")
                .addTo(this)
    }

    private fun addCarouselModels(it: BaseRow, models: List<EpoxyModel<*>>, noOnScreen: Float) {
        CarouselModel_()
                .id(it.id + "carousel")
                .models(models)
                .numViewsToShowOnScreen(noOnScreen)
                .addTo(this)
    }

    interface ItemClickListener {
        fun onContentItemClicked(content: Content)
    }

    override fun onExceptionSwallowed(exception: RuntimeException) {
        super.onExceptionSwallowed(exception)
    }
}
