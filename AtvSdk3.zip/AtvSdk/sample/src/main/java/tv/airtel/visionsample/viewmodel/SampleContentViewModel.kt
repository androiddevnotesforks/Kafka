package tv.airtel.visionsample.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.airtel.vision.AtvSdk
import tv.airtel.data.api.model.Resource
import tv.airtel.data.livedata.AbsentLiveData
import tv.airtel.data.model.PeopleProfile
import tv.airtel.data.model.ResultEntity
import tv.airtel.data.model.content.ContentDetail
import tv.airtel.data.model.content.ContentResult
import tv.airtel.data.model.content.RowItemContent
import tv.airtel.data.model.content.detail.EpisodeDetail
import tv.airtel.data.model.content.detail.SeasonDetail
import tv.airtel.data.model.content.related.RelatedContent
import tv.airtel.data.model.content.related.RelatedSports
import tv.airtel.data.model.search.SearchCategoryWiseRequestModel
import tv.airtel.data.model.search.SearchResponse
import tv.airtel.data.model.search.SearchResponseCategoryWise
import tv.airtel.data.model.user.UserConfig
import tv.airtel.data.model.user.profile.ProfileEntity
import javax.inject.Inject

/**
 * Created by VipulKumar on 2/22/18.
 * ViewModel to handle the data flow for content calls.
 * As a best practice, ViewModels (or presenters) should not know anything about Android framework.
 * Keep an eye on imports starting with `android.*` (except for arch component imports).
 */

class SampleContentViewModel @Inject
constructor() : BaseViewModel() {
    private val vision = AtvSdk.getInstance()
    private var pageIdMutableLiveData = MutableLiveData<String>()
    val contentList: LiveData<Resource<ContentResult>>?

    private var contentIdForDetail = MutableLiveData<String>()
    val contentDetail: LiveData<Resource<ContentDetail>>?

    private var contentIdForRelated = MutableLiveData<String>()
    val contentRelatedList: LiveData<Resource<RelatedContent>>?

    private var contentIdForRelatedSports = MutableLiveData<String>()
    val sportsRelatedList: LiveData<Resource<RelatedSports>>?

    private var contentIdForSeasonDetail = MutableLiveData<String>()
    val contentSeasonDetail: LiveData<Resource<SeasonDetail>>?

    private var contentIdForEpisodeDetail = MutableLiveData<String>()
    val contentEpisodeDetail: LiveData<Resource<EpisodeDetail>>?

    private var contentIdForMarkFavorite = MutableLiveData<Pair<String, Boolean>>()
    val markFavorite: LiveData<Resource<ResultEntity>>?

    private var triggerForFetchFavorites = MutableLiveData<Boolean>()
    val favoritesList: LiveData<Resource<List<RowItemContent>>>

    private var searchKeyword = MutableLiveData<String>()
    val searchResults: LiveData<Resource<SearchResponse>>?

    private var searchRequestCategorically = MutableLiveData<SearchCategoryWiseRequestModel>()
    val searchResultsCatgerically: LiveData<Resource<SearchResponseCategoryWise>>?

    private var peopleProfileIdForRelatedContent = MutableLiveData<String>()
    val peopleContent: LiveData<Resource<SearchResponse>>?

    private var peopleProfileId = MutableLiveData<String>()
    val peopleProfile: LiveData<Resource<PeopleProfile>>?

    private var userConfigTrigger = MutableLiveData<String>()
    val userConfig: LiveData<Resource<UserConfig>>?

    private var getUserProfilesTrigger = MutableLiveData<Boolean>()
    val userProfiles: LiveData<Resource<ProfileEntity>>?

    init {
        userConfig = Transformations.switchMap(userConfigTrigger) { list ->
            if (list != null) {
                vision.updateUserConfig(lang = arrayListOf(list))
            } else {
                AbsentLiveData.create<Resource<UserConfig>>()
            }
        }

        userProfiles = Transformations.switchMap(getUserProfilesTrigger) { list ->
            if (list != null) {
                vision.getProfileData()
            } else {
                AbsentLiveData.create<Resource<ProfileEntity>>()
            }
        }

        // Fetches content every time value of pageIdMutableLiveData changes
        contentList = Transformations.switchMap(pageIdMutableLiveData) { pageId ->
            if (pageId != null) {
                vision.getContent(pageId)
            } else {
                // create an empty LiveData to prevent being null
                AbsentLiveData.create<Resource<ContentResult>>()
            }
        }

        peopleContent = Transformations.switchMap(peopleProfileIdForRelatedContent) { pageId ->
            if (pageId != null) {
                vision.getContentByCreditId(pageId)
            } else {
                // create an empty LiveData to prevent being null
                AbsentLiveData.create<Resource<SearchResponse>>()
            }
        }

        peopleProfile = Transformations.switchMap(peopleProfileId) { pageId ->
            if (pageId != null) {
                vision.getPeopleProfile(pageId)
            } else {
                // create an empty LiveData to prevent being null
                AbsentLiveData.create<Resource<PeopleProfile>>()
            }
        }

        contentDetail = Transformations.switchMap(contentIdForDetail) { contentId ->
            if (contentId != null) {
                vision.getContentDetail(contentId)
            } else {
                AbsentLiveData.create<Resource<ContentDetail>>()
            }
        }

        contentRelatedList = Transformations.switchMap(contentIdForRelated) { contentId ->
            if (contentId != null) {
                vision.getRelatedContent(contentId)
            } else {
                AbsentLiveData.create<Resource<RelatedContent>>()
            }
        }

        sportsRelatedList = Transformations.switchMap(contentIdForRelatedSports) { contentId ->
            if (contentId != null) {
                vision.getRelatedSports(contentId)
            } else {
                AbsentLiveData.create<Resource<RelatedSports>>()
            }
        }

        contentSeasonDetail = Transformations.switchMap(contentIdForSeasonDetail) { contentId ->
            if (contentId != null) {
                vision.getSeasonDetail(contentId)
            } else {
                AbsentLiveData.create<Resource<SeasonDetail>>()
            }
        }

        contentEpisodeDetail = Transformations.switchMap(contentIdForEpisodeDetail) { contentId ->
            if (contentId != null) {
                vision.getEpisodeDetail(contentId)
            } else {
                AbsentLiveData.create<Resource<EpisodeDetail>>()
            }
        }

        markFavorite = Transformations.switchMap(contentIdForMarkFavorite) { content ->
            if (content != null) {
                vision.markFavorite(content.first, content.second)
            } else {
                AbsentLiveData.create<Resource<ResultEntity>>()
            }
        }

        favoritesList = Transformations.switchMap(triggerForFetchFavorites) { trigger ->
            if(trigger) {
                vision.getFavoritesList()
            } else {
                AbsentLiveData.create<Resource<List<RowItemContent>>>()
            }
        }

        searchResults = Transformations.switchMap(searchKeyword) { keyword ->
            if (keyword != null) {
                vision.searchContent(keyword, false, "")
            } else {
                AbsentLiveData.create<Resource<SearchResponse>>()
            }
        }
        searchResultsCatgerically = Transformations.switchMap(searchRequestCategorically) { request ->
            if (request != null) {
                vision.searchContentCategorically(request)
            } else {
                AbsentLiveData.create<Resource<SearchResponseCategoryWise>>()
            }
        }
    }

    fun fetchContentList(pageId: String) {
        // simply change the value of pageIdMutableLiveData and content will be downloaded again
        // see LiveData.TransformationMap()
        pageIdMutableLiveData.value = pageId
    }

    fun fetchContentDetail(contentIdString: String) {
        contentIdForDetail.value = contentIdString
    }

    fun fetchSeasonDetail(contentIdString: String) {
        contentIdForSeasonDetail.value = contentIdString
    }

    fun fetchEpisodeDetail(contentIdString: String) {
        contentIdForEpisodeDetail.value = contentIdString
    }

    fun retryContentList() {
        if (this.pageIdMutableLiveData.value != null) {
            fetchContentList(pageIdMutableLiveData.value!!)
        }
    }

    fun fetchRelatedContent(contentIdString: String) {
        contentIdForRelated.value = contentIdString
    }

    fun fetchRelatedSports(contentIdString: String) {
        contentIdForRelatedSports.value = contentIdString
    }

    fun markFavorite(contentIdString: String, isFavorite: Boolean) {
        contentIdForMarkFavorite.value = Pair(contentIdString, isFavorite)
    }

    fun fetchFavorites() {
        triggerForFetchFavorites.value = true
    }

    fun fetchPeopleRelated(profileId: String) {
        peopleProfileIdForRelatedContent.value = profileId
    }

    fun fetchPeopleProfile(profileId: String) {
        peopleProfileId.value = profileId
    }

    fun searchContent(keyword: String) {
        searchKeyword.value = keyword
    }
    fun searchContentCategorically(searchCategoryWiseRequestModel: SearchCategoryWiseRequestModel) {
        searchRequestCategorically.value = searchCategoryWiseRequestModel
    }

    fun updateUserConfig(lang: String) {
        userConfigTrigger.value = lang
    }

    fun getProfiles() {
        getUserProfilesTrigger.value = true
    }
}
