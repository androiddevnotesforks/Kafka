package tv.airtel.visionsample.adapter

import com.airbnb.epoxy.CarouselModel_
import com.airbnb.epoxy.TypedEpoxyController
import timber.log.Timber
import tv.airtel.data.model.content.Content
import tv.airtel.data.model.content.related.RelatedSports
import tv.airtel.visionsample.ItemHomeCardHeaderBindingModel_
import tv.airtel.visionsample.ItemHomeCardLandscapeBindingModel_
import tv.airtel.visionsample.ItemHomeCardSeparatorBindingModel_
import tv.airtel.visionsample.util.ext.isNotNullOrEmpty
import java.lang.RuntimeException

/**
 * Epoxy controller for building and adding models to recyclerView in related content list on detail page.
 */
class RelatedSportsAdapter constructor(val itemClickListener: ItemClickListener)
    : TypedEpoxyController<RelatedSports>() {
    override fun buildModels(relatedSports: RelatedSports?) {
        val relatedModels = arrayListOf<ItemHomeCardLandscapeBindingModel_>()

        val entity = relatedSports?.sportsRelatedContentDetailsEntity
        if (entity != null) {
            ItemHomeCardSeparatorBindingModel_()
                    .id("id_sep")
                    .addTo(this)

            if (entity.bymatch.isNotNullOrEmpty()) {
                ItemHomeCardHeaderBindingModel_()
                        .id(relatedSports.id + "match_title")
                        .text("Recent from Match")
                        .more(false)
                        .addTo(this)

                val relatedMatchModels = arrayListOf<ItemHomeCardLandscapeBindingModel_>()

                entity.bymatch?.mapTo(relatedMatchModels) {
                    ItemHomeCardLandscapeBindingModel_()
                            .id(it.id!!)
                            .itemClickListener { model, parentView, clickedView, position ->
                                itemClickListener.onContentItemClicked(model.content())
                            }
                            .content(it)
                }

                CarouselModel_()
                        .id(relatedSports.id + "match")
                        .models(relatedMatchModels)
                        .numViewsToShowOnScreen(3.03f)
                        .addTo(this)
            }
            if (entity.byTournament.isNotNullOrEmpty()) {
                ItemHomeCardHeaderBindingModel_()
                        .id(relatedSports.id + "tournament_title")
                        .text("Popular from Tournament")
                        .more(false)
                        .addTo(this)

                val relatedTournamentModels = arrayListOf<ItemHomeCardLandscapeBindingModel_>()

                entity.byTournament?.mapTo(relatedTournamentModels) {
                    ItemHomeCardLandscapeBindingModel_()
                            .id(it.id!!)
                            .itemClickListener { model, parentView, clickedView, position ->
                                itemClickListener.onContentItemClicked(model.content())
                            }
                            .content(it)
                }

                CarouselModel_()
                        .id(relatedSports.id + "tournament")
                        .models(relatedTournamentModels)
                        .numViewsToShowOnScreen(3.03f)
                        .addTo(this)

            }
            if (entity.byGenre.isNotNullOrEmpty()) {
                ItemHomeCardHeaderBindingModel_()
                        .id(relatedSports.id + "genre_title")
                        .text("You may also like")
                        .more(false)
                        .addTo(this)

                val relatedGenreModels = arrayListOf<ItemHomeCardLandscapeBindingModel_>()

                entity.byGenre?.mapTo(relatedGenreModels) {
                    ItemHomeCardLandscapeBindingModel_()
                            .id(it.id!!)
                            .itemClickListener { model, parentView, clickedView, position ->
                                itemClickListener.onContentItemClicked(model.content())
                            }
                            .content(it)
                }

                CarouselModel_()
                        .id(relatedSports.id + "genre")
                        .models(relatedGenreModels)
                        .numViewsToShowOnScreen(3.03f)
                        .addTo(this)
            }

        }
    }

    interface ItemClickListener {
        fun onContentItemClicked(content: Content)
    }

    override fun onExceptionSwallowed(exception: RuntimeException) {
        // we swallow exceptions related to duplicate IDs for now
        Timber.e(exception.cause)
    }
}