package tv.airtel.visionsample.di

import android.app.Application
import dagger.BindsInstance
import dagger.Component
import dagger.android.AndroidInjectionModule
import tv.airtel.visionsample.AtvApplication
import tv.airtel.visionsample.di.modules.ActivityModule
import tv.airtel.visionsample.di.modules.AppModule
import javax.inject.Singleton

/**
 * Authored by vipulkumar on 19/09/17.
 */

@Singleton
@Component(modules = [(AppModule::class), (AndroidInjectionModule::class), (ActivityModule::class)])
internal interface AppComponent {
    @Component.Builder
    interface Builder {

        @BindsInstance
        fun application(application: Application): Builder

        fun build(): AppComponent
    }
    fun inject(app: AtvApplication)
//    fun inject(hooqPlayer: HooqPlayer)
}
