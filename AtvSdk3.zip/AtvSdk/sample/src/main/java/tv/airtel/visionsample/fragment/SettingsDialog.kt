package tv.airtel.visionsample.fragment

import android.os.Bundle
import androidx.core.app.DialogFragment
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import tv.airtel.visionsample.R


class SettingsDialog : DialogFragment(), View.OnClickListener {

    lateinit var parentLayout : LinearLayout
    lateinit var data: ArrayList<String>
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        dialog.window!!.setGravity(Gravity.END or Gravity.TOP)
        val height = ViewGroup.LayoutParams.MATCH_PARENT
        val width = ViewGroup.LayoutParams.WRAP_CONTENT
        dialog.window?.setLayout(width, height)
        dialog.window?.setBackgroundDrawableResource(R.color.background_semi_transparent)
        data = arguments?.get("data") as ArrayList<String>
        return inflater.inflate(R.layout.settings_dialog, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        parentLayout = view.findViewById(R.id.parentLayout)
        addItems()
    }

    private fun addItems() {
        for (indexView in 0 until data.size) {
            val textView = TextView(context)
            textView.id = indexView
            textView.setPadding(30, 30, 30, 30)
            textView.gravity = Gravity.END
            textView.text = "${data[indexView]}"
            textView.textSize = 16.0f
            textView.setTextColor(resources.getColor(R.color.white))
            textView.setOnClickListener(this)
            val layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT)
            parentLayout.addView(textView, layoutParams)
        }
    }

//    companion object{
//        private lateinit var settingsDialog: SettingsDialog
//        fun getInstance(data: ArrayList<String>): SettingsDialog {
////            settingsDialog?.let {
////
////            }
//            settingsDialog?: run{
//                settingsDialog = SettingsDialog()
//            }
//            return SettingsDialog()
//        }
//    }

    override fun onClick(v: View?) {
    }
}
