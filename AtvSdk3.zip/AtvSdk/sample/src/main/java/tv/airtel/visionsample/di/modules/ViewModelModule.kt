package tv.airtel.visionsample.di.modules

import androidx.lifecycle.ViewModel
import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoMap
import tv.airtel.visionsample.di.ViewModelKey
import tv.airtel.visionsample.viewmodel.SampleContentViewModel

/**
 * binds all the viewModels.
 */
@Module
public abstract class ViewModelModule {

    @Binds
    @IntoMap
    @ViewModelKey(SampleContentViewModel::class)
    abstract fun bindContentViewModel(viewModelSample: SampleContentViewModel): ViewModel
}
