package tv.airtel.util.util;

/**
 * Created by Accedo India on 15-03-2016.
 */
public class QualityConfiguration {

    private String preferred_quality;

    private String connection_id;

    public String getPreferred_quality ()
    {
        return preferred_quality;
    }

    public String getConnection_id ()
    {
        return connection_id;
    }
}