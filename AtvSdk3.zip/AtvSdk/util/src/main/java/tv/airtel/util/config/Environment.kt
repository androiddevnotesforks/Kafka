@file:Suppress("unused", "MemberVisibilityCanBePrivate")

package tv.airtel.util.config

import android.app.Application
import android.content.SharedPreferences
import tv.airtel.util.BuildConfig
import tv.airtel.util.manager.AppPreferenceManager
import tv.airtel.util.util.LogUtil
import tv.airtel.util.util.NoArgSingletonHolder
import tv.airtel.util.util.SingletonHolder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Created by VipulKumar on 2/22/18.
 *
 */
@Singleton
class Environment @Inject internal constructor(val application: Application) {
    companion object {
        private const val KEY_CURRENT_FLAVOUR = "currentFlavour"
        private const val KEY_FLAVOUR_STAGING = "Staging"
        private const val KEY_FLAVOUR_PRODUCTION = "Production"
        private const val KEY_FLAVOUR_CUSTOM = "Custom"
        private const val KEY_SHOW_LOGS = "show_logs"
        private const val KEY_BUILD_TYPE_DEBUG = "debug"
        private const val KEY_BUILD_TYPE_RELEASE = "release"
        private const val KEY_BUILD_TYPE_INTERNAL = "internal"
        private const val KEY_CUSTOM_URL_BASE = "custom_url_base"
        private const val KEY_CUSTOM_URL_LAYOUT = "custom_url_layout"
        private const val KEY_CUSTOM_URL_CMS = "custom_url_cms"
        private const val KEY_CUSTOM_URL_EVENT = "custom_url_event"
        private const val KEY_CUSTOM_URL_SEARCH = "custom_url_search"
        const val KEY_CURRENT_DB_VERSION = "current_db_version"
        private const val LOG_TAG = "Environment"

        var showNetworkLogs = true
        var showSnackbarAsDefaultFeedback = false
        var APP_VERSION_CODE = -1
        var APP_VERSION_NAME = ""
        const val accountType = BuildConfig.APPLICATION_ID
        const val authority = BuildConfig.APPLICATION_ID + ".provider"

        /**
         * Boolean to check if in Debug mode
         */
        var isDebug = false
    }

    fun initialize(debuggable: Boolean, flavour: Flavour) {
        isDebug = debuggable
        showLogs = isDebug && AppPreferenceManager.getInstance(application)
                .getBoolean(KEY_SHOW_LOGS, true)
        showNetworkLogs = isDebug
        flavourString = flavour.name()
        currentFlavour = Flavour.valueOf(application, flavourString)
        if (showLogs) {
            LogUtil.d(LOG_TAG, "Current Flavour: " + currentFlavour.name())
        }

        initUrls(currentFlavour)
    }

    private fun initUrls(flavour: Flavour) {
        middleWareEndpoint = flavour.middleWareEndpoint
        middlewareLayoutEndpoint = flavour.middlewareLayoutEndpoint
        middlewareCMSEndpoint = flavour.middlewareCMSEndpoint
        middlewareEventsEndpoint = flavour.middlewareEventsEndpoint
        middlewareGeoEndpoint = flavour.middlewareGeoEndpoint
        middlewareSearchEndPoint = flavour.middlewareSearchEndpoint

        middleWareEndpointHttp = flavour.middleWareEndpointHttp
        middlewareLayoutEndpointHttp = flavour.middlewareLayoutEndpointHttp
        middlewarePlayEndPoint = flavour.middlewarePlayBackHost
        middlewareCMSEndpointHttp = flavour.middlewareCMSEndpointHttp
        middlewareEventsEndpointHttp = flavour.middlewareEventsEndpointHttp
        middlewareGeoEndpointHttp = flavour.middlewareGeoEndpointHttp
    }

    /**
     *  Determines if should show logs
     */
    var showLogs = false
    var showFeedback = showLogs

    /**
     * Currently active [Flavour] from [SharedPreferences].
     */
    private lateinit var flavourString: String

    /**
     * Currently active currentFlavour.
     */
    lateinit var currentFlavour: Flavour

    fun setFlavour(context: Application, flavour: Flavour) {
        AppPreferenceManager.getInstance(context).putString(KEY_CURRENT_FLAVOUR, flavour.name())
        flavourString = flavour.name()
        currentFlavour = flavour
    }

    fun setShowLogsToSharedPref(context: Application, isShowLogs: Boolean) {
        AppPreferenceManager.getInstance(context)
                .putBoolean(KEY_SHOW_LOGS, isShowLogs)
        showLogs = isShowLogs
        showFeedback = showLogs
    }

    lateinit var middleWareEndpoint: String
    lateinit var middlewareLayoutEndpoint: String
    lateinit var middlewareCMSEndpoint: String
    lateinit var middlewareEventsEndpoint: String
    lateinit var middlewareGeoEndpoint: String

    lateinit var middleWareEndpointHttp: String
    lateinit var middlewareLayoutEndpointHttp: String
    lateinit var middlewareCMSEndpointHttp: String

    lateinit var middlewarePlayEndPoint: String
    lateinit var middlewareSearchEndPoint: String

    private lateinit var middlewareEventsEndpointHttp: String
    private lateinit var middlewareGeoEndpointHttp: String


    abstract class Flavour {
        abstract val middleWareEndpoint: String
        abstract val middlewareLayoutEndpoint: String
        abstract val middlewareCMSEndpoint: String
        abstract val middlewareEventsEndpoint: String
        abstract val middlewareGeoEndpoint: String
        abstract val middlewareSearchEndpoint: String

        abstract val middleWareEndpointHttp: String
        abstract val middlewareLayoutEndpointHttp: String
        abstract val middlewareCMSEndpointHttp: String
        abstract val middlewareEventsEndpointHttp: String
        abstract val middlewareGeoEndpointHttp: String
        abstract val middlewareSearchEndpointHttp: String

        abstract val middlewarePlayBackHost: String

        abstract fun name(): String

        companion object {
            fun valueOf(context: Application, flavourString: String): Flavour {
                return when (flavourString) {
                    Environment.KEY_FLAVOUR_STAGING -> Staging.getInstance()
                    Environment.KEY_FLAVOUR_PRODUCTION -> Production.getInstance()
                    Environment.KEY_FLAVOUR_CUSTOM -> Custom.getInstance(context)
                    else -> {
                        throw RuntimeException()
                    }
                }
            }
        }
    }

    class Staging : Flavour() {
        companion object : NoArgSingletonHolder<Staging>(::Staging)

        //        override val middleWareEndpoint = "http://play-dev.wynk.in/"
        override val middleWareEndpoint = "http://apimaster-dev2.wynk.in/"
        override val middlewareLayoutEndpoint = "http://layoutapi-dev2.wynk.in/"
        override val middlewareCMSEndpoint = "http://contentapi-dev2.wynk.in/"
        override val middlewareEventsEndpoint = "http://eventapi-dev2.wynk.in/"
        override val middlewareGeoEndpoint = "http://location.wynk.in/"
        override val middlewareSearchEndpoint = "http://search-dev2.wynk.in/"

        override val middleWareEndpointHttp = "http://apimaster-dev2.wynk.in/"
        override val middlewareLayoutEndpointHttp = "http://layoutapi-dev2.wynk.in/"
        override val middlewareCMSEndpointHttp = "http://contentapi-dev2.wynk.in/"
        override val middlewareEventsEndpointHttp = "http://eventapi-dev2.wynk.in/"
        override val middlewareGeoEndpointHttp = "http://location.wynk.in/"
        override val middlewareSearchEndpointHttp = "http://search-dev2.wynk.in/"

        override val middlewarePlayBackHost = "http://play-dev2.wynk.in/"

        override fun name(): String {
            return Environment.KEY_FLAVOUR_STAGING
        }
    }

    class Production : Flavour() {
        companion object : NoArgSingletonHolder<Production>(::Production)

        override val middleWareEndpoint = "https://api.airtel.tv/"
        override val middlewareLayoutEndpoint = "https://layout.airtel.tv/"
        override val middlewareCMSEndpoint = "https://content.airtel.tv/"
        override val middlewareEventsEndpoint = "https://events.airtel.tv/"
        override val middlewareGeoEndpoint = "http://location.wynk.in/"
        override val middlewareSearchEndpoint = "https://search.airtel.tv/"

        override val middleWareEndpointHttp = "http://api.airtel.tv/"
        override val middlewareLayoutEndpointHttp = "http://layout.airtel.tv/"
        override val middlewareCMSEndpointHttp = "http://content.airtel.tv/"
        override val middlewareEventsEndpointHttp = "http://events.airtel.tv/"
        override val middlewareGeoEndpointHttp = "http://location.wynk.in/"
        override val middlewareSearchEndpointHttp = "http://search.airtel.tv/"

        override val middlewarePlayBackHost = "https://play.airtel.tv/"

        override fun name(): String {
            return Environment.KEY_FLAVOUR_PRODUCTION
        }
    }

    class Custom(val context: Application) : Flavour() {
        companion object : SingletonHolder<Custom, Application>(::Custom)

        override var middleWareEndpoint: String = AppPreferenceManager.getInstance(context)
                .getString(Environment.KEY_CUSTOM_URL_BASE, Staging().middleWareEndpoint)
        override var middlewareLayoutEndpoint: String = AppPreferenceManager.getInstance(context)
                .getString(Environment.KEY_CUSTOM_URL_LAYOUT, Staging().middlewareLayoutEndpoint)
        override var middlewareCMSEndpoint: String = AppPreferenceManager.getInstance(context)
                .getString(Environment.KEY_CUSTOM_URL_CMS, Staging().middlewareCMSEndpoint)
        override var middlewareEventsEndpoint: String = AppPreferenceManager.getInstance(context)
                .getString(Environment.KEY_CUSTOM_URL_EVENT, Staging().middlewareEventsEndpoint)
        override var middlewareSearchEndpoint: String = AppPreferenceManager.getInstance(context)
                .getString(Environment.KEY_CUSTOM_URL_SEARCH, Staging().middlewareSearchEndpoint)
        override var middlewareGeoEndpoint = Staging().middlewareGeoEndpoint
        override val middlewarePlayBackHost = Staging().middlewarePlayBackHost

        override val middleWareEndpointHttp = middleWareEndpoint
        override val middlewareLayoutEndpointHttp = middlewareLayoutEndpoint
        override val middlewareCMSEndpointHttp = middlewareCMSEndpoint
        override val middlewareEventsEndpointHttp = middlewareEventsEndpoint
        override val middlewareGeoEndpointHttp = middlewareGeoEndpoint
        override val middlewareSearchEndpointHttp = middlewareSearchEndpoint

        fun setBasicUrl(url: String) {
            AppPreferenceManager.getInstance(context)
                    .putString(Environment.KEY_CUSTOM_URL_BASE, url)
            middleWareEndpoint = url
        }

        fun setLayoutUrl(url: String) {
            AppPreferenceManager.getInstance(context)
                    .putString(Environment.KEY_CUSTOM_URL_LAYOUT, url)
            middlewareLayoutEndpoint = url
        }

        fun setCMSUrl(url: String) {
            AppPreferenceManager.getInstance(context)
                    .putString(Environment.KEY_CUSTOM_URL_CMS, url)
            middlewareCMSEndpoint = url
        }

        fun setEventUrl(url: String) {
            AppPreferenceManager.getInstance(context)
                    .putString(Environment.KEY_CUSTOM_URL_EVENT, url)
            middlewareEventsEndpoint = url
        }

        override fun name(): String {
            return Environment.KEY_FLAVOUR_CUSTOM
        }
    }
}
