package tv.airtel.util.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import tv.airtel.util.callbacks.OnNetworkChangeListener;


public class NetworkUtil {

    public static Set<OnNetworkChangeListener> networkChangeListeners;
	public static int TYPE_WIFI = 1;
	public static int TYPE_MOBILE = 2;
	public static int TYPE_NOT_CONNECTED = 0;

    private static final String CONNECTION_2G = "2g";
    private static final String CONNECTION_3G = "3g";
    private static final String CONNECTION_4G = "4g";
    public static final String CONNECTION_WIFI = "wifi";
    public static final String CONNECTION_MOBILE_DATA = "Mobile";
    private static final String CONNECTION_UNKNOWN = "unknown";


    /**
     * Function that will return connection
     * @param context
     * @return connection type (2g,3g,4g, WIFI)
     */
    public static String getNetworkClass(Context context) {
        String connectionType = CONNECTION_UNKNOWN;

        if (context != null) {
            ConnectivityManager cm = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);

            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

            //Checking whether there is any active connection.
            if (null != activeNetwork) {
                //If active connection is WIFI
                if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                    connectionType = CONNECTION_WIFI;

                } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {// checking whether the active connection is mobile
                    //Getting telephonic service for correct connection type.
                    TelephonyManager mTelephonyManager = (TelephonyManager)
                            context.getSystemService(Context.TELEPHONY_SERVICE);
                    int networkType = mTelephonyManager.getNetworkType();

                    switch (networkType) {
                        case TelephonyManager.NETWORK_TYPE_GPRS:
                        case TelephonyManager.NETWORK_TYPE_EDGE:
                        case TelephonyManager.NETWORK_TYPE_CDMA:
                        case TelephonyManager.NETWORK_TYPE_1xRTT:
                        case TelephonyManager.NETWORK_TYPE_IDEN:
                            connectionType = CONNECTION_2G;
                            break;
                        case TelephonyManager.NETWORK_TYPE_UMTS:
                        case TelephonyManager.NETWORK_TYPE_EVDO_0:
                        case TelephonyManager.NETWORK_TYPE_EVDO_A:
                        case TelephonyManager.NETWORK_TYPE_HSDPA:
                        case TelephonyManager.NETWORK_TYPE_HSUPA:
                        case TelephonyManager.NETWORK_TYPE_HSPA:
                        case TelephonyManager.NETWORK_TYPE_EVDO_B:
                        case TelephonyManager.NETWORK_TYPE_EHRPD:
                        case TelephonyManager.NETWORK_TYPE_HSPAP:
                            connectionType = CONNECTION_3G;
                            break;
                        case TelephonyManager.NETWORK_TYPE_LTE:
                            connectionType = CONNECTION_4G;
                            break;
                        default:
                            connectionType = CONNECTION_UNKNOWN;
                            break;
                    }
                }
            }
        }

        return connectionType;
    }

    public static boolean alertDismissed = false;

    public static int getConnectivityStatus(Context context) {
		ConnectivityManager cm = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);

		NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
		if (null != activeNetwork) {
			if(activeNetwork.getType() == ConnectivityManager.TYPE_WIFI)
				return TYPE_WIFI;

			if(activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE)
				return TYPE_MOBILE;
		}
		return TYPE_NOT_CONNECTED;
	}

	public static String getConnectivityStatusString(Context context) {
		int conn = NetworkUtil.getConnectivityStatus(context);
		String status = null;
		if (conn == TYPE_WIFI) {
			status = CONNECTION_WIFI;
            sendNotification(true);
            setAlertDismissed(false);
        } else if (conn == TYPE_MOBILE) {
			status = CONNECTION_MOBILE_DATA;
            sendNotification(true);
		} else if (conn == TYPE_NOT_CONNECTED) {
			status = "Not connected to Internet";
            sendNotification(false);
		}
		return status;
	}

    public static void sendNotification(boolean isNetworkAvailable){
        if(networkChangeListeners != null) {
            synchronized (networkChangeListeners) {
                for (OnNetworkChangeListener mListener : networkChangeListeners) {
                    if (isNetworkAvailable)
                        mListener.hideMessage();
                    else
                        mListener.onNetworkChange(isNetworkAvailable);
                }
            }
        }
    }

    public static void removeListener(OnNetworkChangeListener mListener){
        if(networkChangeListeners != null){
            synchronized (networkChangeListeners) {
                networkChangeListeners.remove(mListener);
            }
        }
    }

    public static void hideAllAlerts() {
        if (networkChangeListeners != null) {
            synchronized (networkChangeListeners) {
                for (OnNetworkChangeListener mListener : networkChangeListeners) {
                    mListener.hideMessage();
                }
            }
        }
    }

    public static void setAlertDismissed(boolean dismissed){
        alertDismissed = dismissed;
    }

    public static boolean getAlertDismissed(){
        return alertDismissed;
    }


    public static void setNetworkChangeListeners(OnNetworkChangeListener networkChangeListenert) {
        if(networkChangeListeners == null){
            networkChangeListeners = Collections.synchronizedSet(new HashSet<OnNetworkChangeListener>());
        }
        networkChangeListeners.add(networkChangeListenert);
    }

    /**
     * This method checks for a connected network
     * @param context Android context which initiated the request
     * @return true for connected network, else false
     */
    public static boolean isOnline(Context context) {
        ConnectivityManager cm = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        boolean isConnected = (netInfo != null && netInfo.isConnected());
//        LogUtil.d("Network Change", "isConnected : " + isConnected);
        return isConnected;
    }


    public static boolean isConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager) (context).getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnectedOrConnecting();
    }

    public static NetworkInfo getActiveNetworkInfo(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo();
    }

    public static boolean isConnectedToMI(Context context) {
        if (!isConnected(context)) {
            return false;
        }

        NetworkInfo info = getActiveNetworkInfo(context);
        return info != null && isNetworkMobileData(info.getType());
    }

    private static boolean isNetworkMobileData(int networkType) {
        switch (networkType) {
            case ConnectivityManager.TYPE_MOBILE:
            case ConnectivityManager.TYPE_MOBILE_DUN:
            case ConnectivityManager.TYPE_MOBILE_HIPRI:
            case ConnectivityManager.TYPE_MOBILE_MMS:
            case ConnectivityManager.TYPE_MOBILE_SUPL:
                return true;
            default:
                return false;
        }
    }


    /**
     *
     * @param useIPv4 if useIPv4 = true  return ipv4; if useIPv4 = false return ipv6;
     * @return ip Address
     */
    public static String getIPAddress(boolean useIPv4) {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface
                    .getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                for (InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress()) {
                        String sAddr = addr.getHostAddress().toUpperCase();
                        boolean isIPv4 = isIPv4Address(addr);
                        if (useIPv4) {
                            if (isIPv4)
                                return sAddr;
                        } else {
                            if (!isIPv4) {
                                int delim = sAddr.indexOf('%'); // drop ip6 port suffix
                                return delim<0 ? sAddr : sAddr.substring(0, delim);
                            }
                        }
                    }
                }
            }
        } catch (Exception ex) { } // for now eat exceptions
        return "";
    }

    //ToDo test this method
    private static boolean  isIPv4Address(InetAddress inetAddress) {

        if (inetAddress instanceof Inet4Address) return true;

        return false;
    }
    /**
     * Check if the connection is fast
     *
     * @param type
     * @param subType
     * @return
     */
    // Courtsey: https://gist.github.com/emil2k/5130324
    public static boolean isConnectionFast(int type, int subType) {
        if (type == ConnectivityManager.TYPE_WIFI) {
            return true;
        } else if (type == ConnectivityManager.TYPE_MOBILE) {
            switch (subType) {
                case TelephonyManager.NETWORK_TYPE_1xRTT:
                    return false; // ~ 50-100 kbps
                case TelephonyManager.NETWORK_TYPE_CDMA:
                    return false; // ~ 14-64 kbps
                case TelephonyManager.NETWORK_TYPE_EDGE:
                    return false; // ~ 50-100 kbps
                case TelephonyManager.NETWORK_TYPE_EVDO_0:
                    return true; // ~ 400-1000 kbps
                case TelephonyManager.NETWORK_TYPE_EVDO_A:
                    return true; // ~ 600-1400 kbps
                case TelephonyManager.NETWORK_TYPE_GPRS:
                    return false; // ~ 100 kbps
                case TelephonyManager.NETWORK_TYPE_HSDPA:
                    return true; // ~ 2-14 Mbps
                case TelephonyManager.NETWORK_TYPE_HSPA:
                    return true; // ~ 700-1700 kbps
                case TelephonyManager.NETWORK_TYPE_HSUPA:
                    return true; // ~ 1-23 Mbps
                case TelephonyManager.NETWORK_TYPE_UMTS:
                    return true; // ~ 400-7000 kbps
                /*
                 * Above API level 7, make sure to set android:targetSdkVersion
                 * to appropriate level to use these
                 */
                case TelephonyManager.NETWORK_TYPE_EHRPD: // API level 11
                    return true; // ~ 1-2 Mbps
                case TelephonyManager.NETWORK_TYPE_EVDO_B: // API level 9
                    return true; // ~ 5 Mbps
                case TelephonyManager.NETWORK_TYPE_HSPAP: // API level 13
                    return true; // ~ 10-20 Mbps
                case TelephonyManager.NETWORK_TYPE_IDEN: // API level 8
                    return false; // ~25 kbps
                case TelephonyManager.NETWORK_TYPE_LTE: // API level 11
                    return true; // ~ 10+ Mbps
                // Unknown
                case TelephonyManager.NETWORK_TYPE_UNKNOWN:
                default:
                    return false;
            }
        } else {
            return false;
        }
    }

    public static boolean isConnectedTo2G(Context context) {
        NetworkInfo info = getActiveNetworkInfo(context);
        if (info == null) {
            return false;
        }
        if (!info.isConnected()) {
            return false;
        }
        int type = info.getType();
        int subType = info.getSubtype();
        if (type == ConnectivityManager.TYPE_WIFI) {
            return false;
        }
        if (type == ConnectivityManager.TYPE_MOBILE) {
            switch (subType) {
                case TelephonyManager.NETWORK_TYPE_1xRTT:
                    return true; // ~ 50-100 kbps
                case TelephonyManager.NETWORK_TYPE_CDMA:
                    return true; // ~ 14-64 kbps
                case TelephonyManager.NETWORK_TYPE_EDGE:
                    return true; // ~ 50-100 kbps
                case TelephonyManager.NETWORK_TYPE_EVDO_0:
                    return false; // ~ 400-1000 kbps
                case TelephonyManager.NETWORK_TYPE_EVDO_A:
                    return false; // ~ 600-1400 kbps
                case TelephonyManager.NETWORK_TYPE_GPRS:
                    return true; // ~ 100 kbps
                case TelephonyManager.NETWORK_TYPE_HSDPA:
                    return false; // ~ 2-14 Mbps
                case TelephonyManager.NETWORK_TYPE_HSPA:
                    return false; // ~ 700-1700 kbps
                case TelephonyManager.NETWORK_TYPE_HSUPA:
                    return false; // ~ 1-23 Mbps
                case TelephonyManager.NETWORK_TYPE_UMTS:
                    return false; // ~ 400-7000 kbps
                /*
                 * Above API level 7, make sure to set android:targetSdkVersion
                 * to appropriate level to use these
                 */
                case TelephonyManager.NETWORK_TYPE_EHRPD: // API level 11
                    return false; // ~ 1-2 Mbps
                case TelephonyManager.NETWORK_TYPE_EVDO_B: // API level 9
                    return false; // ~ 5 Mbps
                case TelephonyManager.NETWORK_TYPE_HSPAP: // API level 13
                    return false; // ~ 10-20 Mbps
                case TelephonyManager.NETWORK_TYPE_IDEN: // API level 8
                    return true; // ~25 kbps
                case TelephonyManager.NETWORK_TYPE_LTE: // API level 11
                    return false; // ~ 10+ Mbps
                // Unknown
                case TelephonyManager.NETWORK_TYPE_UNKNOWN:
                default:
                    return false;
            }
        }
        return false;
    }
}
