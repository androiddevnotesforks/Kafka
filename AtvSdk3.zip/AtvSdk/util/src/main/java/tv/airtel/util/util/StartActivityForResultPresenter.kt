package tv.airtel.util.util

import android.app.Activity
import android.content.Intent

abstract class StartActivityForResultPresenter : StartActivityPresenter {


//    private inner class ActivityResultObserver : DisposableObserver<ActivityResult>() {
//
//        override fun onComplete() {
//
//        }
//
//        override fun onError(e: Throwable?) {
//
//        }
//
//        override fun onNext(result: ActivityResult) {
////            Timber.d("Start activity for result " + result.requestCode)
//            onActivityResult(result)
//        }
//    }
//
//    fun startActivityForResult(context: Activity, intent: Intent, requestCode: Int) {
//        RxActivityResult.getInstance().startActivityForResult(context, intent, requestCode).subscribe(ActivityResultObserver())
//    }

}