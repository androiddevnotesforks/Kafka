package tv.airtel.util.callbacks;

/**
 * Created by unnikrishnan on 9/5/16.
 *
 */
public interface OnNetworkChangeListener {
    void onNetworkChange(boolean isConnected);
    void hideMessage();
}