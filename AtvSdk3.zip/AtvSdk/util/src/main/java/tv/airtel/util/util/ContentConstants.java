package tv.airtel.util.util;

/**
 * Created by manishmalhotra on 18/09/17.
 */
public interface ContentConstants {

    String PHONE_NO = "phone_no";
    String PROFILE_TOKEN = "profile_token";
    String PROFILE_UID = "profile_uid";
    String EMAIL = "email";
    String OTP = "otp";
    String MSISDN = "msisdn";
    String REQUIRE_OTP = "requireOtp";
    String MCC = "mcc";
    String MNC = "mnc";
    String USER_PROPERTIES = "user_properties";
    String QUERY = "query";
    int MAX_ITEM = 6;
    String CATEGORY = "category";
    String SOURCE_NAME = "source_name";
    String RAIL_TITLE = "rail_title";
    String HUAWEI = "HUAWEI";
    String MWTV = "MWTV";
    String RAIL_ICON = "rail_icon";
    String PLAYBILLID = "playbillid";
    String PLAYTYPE = "playtype";
    String TVPROMO = "TVPROMO";
    String RAIL_POSITION = "rail_position";

    String CPID = "cp";
    String FIRST_CONSENT = "firstConsent";
    String SECOND_CONSENT = "secondConsent";
    String TYPE = "type";
    String UNKNOWN = "UNKNOWN";

    interface ContentType {
        String CHANNEL = "channel";
        String MOVIE = "movie";
        String SEASON = "season";
        String SHORT_MOVIE = "shortmovie";
        String VIDEO = "video";
        String EPISODE = "episode";
        String SERIES = "series";
        String SPORTS = "sports";
        String TVSHOW = "tvshow";
        String OTHER = "other";
        String PEOPLE = "people";
        String CATCHUP = "catchup";
        String LIVETV = "livetv";
        String LIVE = "live";
        String LIVETVSHOW = "livetvshow";
        String LIVETVCHANNEL = "livetvchannel";
        String LIVETVMOVIE = "livetvmovie";
    }

    String FREE_CONTENT_PRICE_TYPE = "FREE";
    String DIRECTOR = "director";
    String ACTOR = "actor";

    String contentId = "contentId";
    String reportingAction = "action";
    String isMax = "ismax";
    ;
    String HEADER_FORCE_REFRESH = "force_refresh";
    String LANG = "lang";
    String SUB_CP = "sub_cp";
    String LASTWATCHEDPOSITION = "lastWatchedPosition";
    String PAGEID = "pageid";
    String FORCEUPDATE = "forceupdate";
    String CONTENTID = "contentid";
    String ISMAX = "ismax";
    String BASEROW = "baserow";
    String CATCH_UP_DATA = "catchup_data";
    String KEY_PAGE_SIZE = "pageSize";
    String KEY_PAGE_NO = "offset";
    String ASC = "title_asc";
    String PRODUCTID = "productId";
    String PACKID = "packId";
    String TRANSACTIONEVENT = "transactionEvent";
    String VALIDTILLDATE = "validTillDate";
    String TRANSACTIONSTATUS = "transactionStatus";
    String LIVE_TV_CONSTANT = "2";
    String CATCHUP_TV_CONSTANT = "4";
    
}
