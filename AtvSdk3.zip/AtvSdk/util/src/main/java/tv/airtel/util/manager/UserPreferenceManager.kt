package tv.airtel.util.manager

import android.app.Application
import android.content.Context
import tv.airtel.util.util.SingletonHolder
import javax.inject.Inject

/**
 * Created by Aditya Mehta on 26/03/18.
 */
class UserPreferenceManager @Inject constructor(context: Application) : SharedPreferenceManager(context) {


    //named default to make it compatible with older versions of airtel tv
    private val appPreferenceName = "default"

    init {
        pref = context.getSharedPreferences(appPreferenceName, Context.MODE_PRIVATE)
    }

    companion object : SingletonHolder<UserPreferenceManager, Application>(::UserPreferenceManager) {
        const val KEY_USER_TOKEN = "user_token"
        const val KEY_USER_UID = "user_uid"
        const val KEY_USER_PROFILE_ID = "profile_id"
        const val IS_USER_LOGGED_IN = "is_user_logged_in_key"
        const val IS_USER_LOGGED_IN_OLD = "is_user_logged_in"
        const val KEY_LOCAL_CONTINUE_WATCHING_UPDATED = "recent_updated"
        const val KEY_LAST_SERVER_RECENT_SYNC_TIME = "old_server_recent_sync_time"
    }
}
