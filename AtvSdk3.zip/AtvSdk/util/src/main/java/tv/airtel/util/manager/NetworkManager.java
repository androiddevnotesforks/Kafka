package tv.airtel.util.manager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;

import java.util.HashSet;
import java.util.Set;

import tv.airtel.util.util.CommonConstants;
import tv.airtel.util.util.ConnectionQuality;
import tv.airtel.util.util.LogUtil;
import tv.airtel.util.util.NetworkUtil;


public class NetworkManager implements ConnectionClassManager.ConnectionClassStateChangeListener {

    private static final String LOG_TAG = "NETWORK_MANAGER";

    private boolean mConnected;

    private int mNetworkType;

    private int mNetworkSubtype;

    private int mNetworkTypeForApi;

    private int mNetworkQuality;

    private Set<ConnectivityListener> mListeners = new HashSet<>();

    private Set<NetworkParamsListener> mNetworkparamsListeners = new HashSet<>();

    private static NetworkManager INSTANCE;// = new NetworkManager();

    public static final int NETWORK_QUALITY_NOT_CONNECTED = -2;                                                                                          // to
    // be
    // used
    // for
    // Analytics
    // only.

    public static final int NETWORK_QUALITY_UNKNOWN = -1;

    public static final int NETWORK_QUALITY_AWFUL = 0;

    public static final int NETWORK_QUALITY_INDIAN_POOR = 1;

    public static final int NETWORK_QUALITY_POOR = 2;

    public static final int NETWORK_QUALITY_MODERATE = 3;

    public static final int NETWORK_QUALITY_GOOD = 4;

    public static final int NETWORK_QUALITY_EXCELLENT = 5;

    private int mPreviousNetworkStatus = -1;

    private Context context;

    public static NetworkManager getInstance(Context context) {

        if (INSTANCE == null) {

            synchronized (NetworkManager.class) {
                if (INSTANCE == null) {
                    INSTANCE = new NetworkManager(context);
                }
            }
        }
        return INSTANCE;
    }

    private NetworkManager(Context context) {
        //TODO fix this
        this.context = context;
        context.registerReceiver(new ConnectivityBroadcastReceiver(), new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        ConnectionClassManager.getInstance().register(this);
        boolean connected = NetworkUtil.isConnected(context);
        NetworkInfo networkInfo = NetworkUtil.getActiveNetworkInfo(context);
        int networkType = -1;
        int networkSubtype = -1;
        if (networkInfo != null) {
            networkType = networkInfo.getType();
            networkSubtype = networkInfo.getSubtype();
        }
        int networkQuality = NETWORK_QUALITY_UNKNOWN;
        if (connected) {
            networkQuality = NetworkManager.getNetworkQualityInt(ConnectionClassManager.getInstance().getCurrentBandwidthQuality());
        }
        setNetworkParams(connected, networkType, networkSubtype, networkQuality);
    }

    public void forceNetworkQualitySync() {
        if (NetworkUtil.isConnected(context)) {
            int networkQuality = NetworkManager.getNetworkQualityInt(ConnectionClassManager.getInstance().getCurrentBandwidthQuality());
            setNetworkQuality(networkQuality);
        }
    }

    @Override
    public void onBandwidthStateChange(ConnectionQuality bandwidthState) {
        LogUtil.INSTANCE.d(LOG_TAG, "onBandwidthStateChange");
        LogUtil.INSTANCE.d(LOG_TAG, "ConnectionQuality " + bandwidthState.name() + " : " + bandwidthState.ordinal());
        setNetworkQuality(NetworkManager.getNetworkQualityInt(bandwidthState));
        setNetworkParams(mConnected, mNetworkType, mNetworkSubtype, mNetworkQuality);
    }


    public interface ConnectivityListener {

        void onConnectivityChanged(boolean connected, int networkType, int networkSubtype);
    }

    public interface NetworkParamsListener {

        void onNetworkParamsChanged(boolean connected, int networkType, int networkSubtype, int networkTypeForApi, int networkQuality);
    }

    private class ConnectivityBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            boolean connected = NetworkUtil.isConnected(context);
            NetworkInfo networkInfo = NetworkUtil.getActiveNetworkInfo(context);
            LogUtil.INSTANCE.d(LOG_TAG, " Network change detected");
            int networkType = -1;
            int networkSubtype = -1;
            if (networkInfo != null) {
                networkType = networkInfo.getType();
                networkSubtype = networkInfo.getSubtype();
            }

            if (mConnected == connected && mNetworkType == networkType && mNetworkSubtype == networkSubtype) {
                LogUtil.INSTANCE.d(LOG_TAG, "No network change detected");
                return;
            }

            if (!connected) {
                ConnectionClassManager.getInstance().reset();
                setNetworkQuality(NETWORK_QUALITY_UNKNOWN);
            }
            int networkQuality = NetworkManager.getNetworkQualityInt(ConnectionClassManager.getInstance().getCurrentBandwidthQuality());

            setNetworkParams(connected, networkType, networkSubtype, networkQuality);

            for (ConnectivityListener listener : mListeners) {
                listener.onConnectivityChanged(mConnected, mNetworkType, mNetworkSubtype);
            }
//            if (AppModeManager.getInstance().getAppMode() == AppModeManager.AppModeType.OFFLINE && NetworkUtils.isConnected()) {
//                LogUtil.e(LOG_TAG, "Airplane Mode Issue : in onReceive method of ConnectivityChangeReceiver", new Exception("Unexpected connection status exception : onReceive"));
//            }
        }
    }


    private void setNetworkParams(boolean connected, int networkType, int networkSubtype, int networkQuality) {
        mConnected = connected;
        mNetworkType = networkType;
        mNetworkSubtype = networkSubtype == TelephonyManager.NETWORK_TYPE_UNKNOWN ? -1 : networkSubtype;
        mNetworkQuality = networkQuality;
        if (connected) {
            if (NetworkUtil.isConnectedToMI(context)) {
                mNetworkTypeForApi = CommonConstants.ApiConstants.Network.Companion.getNETWORK_TYPE_MOBILE();
            } else {
                mNetworkTypeForApi = CommonConstants.ApiConstants.Network.Companion.getNETWORK_TYPE_OTHER();
            }
        } else {
            mNetworkTypeForApi = CommonConstants.ApiConstants.Network.Companion.getNETWORK_NOT_CONNECTED();
        }

        LogUtil.INSTANCE.d(LOG_TAG, "connected:" + mConnected + ", networkType:" + mNetworkType + ", networkSubtype:" + mNetworkSubtype + ", apiNetworkType:" + mNetworkTypeForApi + ", networkQuality: " + networkQuality);

        for (NetworkParamsListener listener : mNetworkparamsListeners) {
            listener.onNetworkParamsChanged(mConnected, mNetworkType, mNetworkSubtype, mNetworkTypeForApi, mNetworkQuality);
        }
    }

    public void addListener(ConnectivityListener listener) {
        mListeners.add(listener);
    }

    public void removeListener(ConnectivityListener listener) {
        mListeners.remove(listener);
    }

    public void addNetworkParamsListener(NetworkParamsListener listener) {
        mNetworkparamsListeners.add(listener);
    }

    public void removeNetworkParamsListener(NetworkParamsListener listener) {
        mNetworkparamsListeners.remove(listener);
    }

    public int getNetworkTypeForApi() {
        return mNetworkTypeForApi;
    }

    public int getNetworkSubtypeForApi() {
        return mNetworkSubtype;
    }

    public int getNetworkQuality() {
        return mNetworkQuality;
    }

    private static int getNetworkQualityInt(ConnectionQuality quality) {
        switch (quality) {
            case AWFUL:
                return 0;
            case INDIAN_POOR:
                return 1;
            case POOR:
                return 2;
            case MODERATE:
                return 3;
            case GOOD:
                return 4;
            case EXCELLENT:
                return 5;
            case UNKNOWN:
            default:
                return -1;
        }
    }

    private void setNetworkQuality(int networkQuality) {
        mNetworkQuality = networkQuality;
        LogUtil.INSTANCE.i(LOG_TAG, "Network quality changed: " + networkQuality + ", Bandwidth: " + ConnectionClassManager.getInstance().getDownloadKBitsPerSecond());
    }

    public int getNeyworkConnectionType() {
        TelephonyManager mTelephonyManager = (TelephonyManager)
                context.getSystemService(Context.TELEPHONY_SERVICE);
        int networkType = mTelephonyManager.getNetworkType();
        switch (networkType) {


            case TelephonyManager.NETWORK_TYPE_GPRS:
                return 1;
            case TelephonyManager.NETWORK_TYPE_EDGE:
                return 2;
            case TelephonyManager.NETWORK_TYPE_UMTS:
                return 3;
            case TelephonyManager.NETWORK_TYPE_CDMA:
                return 4;
            case TelephonyManager.NETWORK_TYPE_EVDO_0:
                return 5;
            case TelephonyManager.NETWORK_TYPE_EVDO_A:
                return 6;
            case TelephonyManager.NETWORK_TYPE_HSDPA:
                return 8;
            case TelephonyManager.NETWORK_TYPE_HSUPA:
                return 9;
            case TelephonyManager.NETWORK_TYPE_EVDO_B:
                return 12;
            case TelephonyManager.NETWORK_TYPE_LTE:
                return 13;
            case TelephonyManager.NETWORK_TYPE_EHRPD:
                return 14;
            default:
                return TelephonyManager.NETWORK_TYPE_UNKNOWN;
        }

    }


    public int getNetworkType() {

        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null) {
            if (ConnectivityManager.TYPE_MOBILE == netInfo.getType()) {
                return 1;
            } else if (ConnectivityManager.TYPE_WIFI == netInfo.getType() && netInfo.isConnected()) {
                return 2;
            } else {
                return 0;
            }
        }
        return -1;
    }
}
