package tv.airtel.util.util

/**
 * Created by VipulKumar on 1/19/18.
 *
 */
//made const val outside of class to access it in java
//without using @JVMFIELD

interface CommonConstants {
    interface ApiConstants {
        interface Network {
            companion object {

                val NETWORK_NOT_CONNECTED = 0

                /* All TYPE_MOBILE* network types */
                val NETWORK_TYPE_MOBILE = 1

                /* Could be Bluetooth, Ethernet, VPN, WiFi, WiMax */
                val NETWORK_TYPE_OTHER = 2
            }
        }
    }

    enum class PLAYBACK_ASSET {
        AD,
        CONTENT,
        GMS_AD
    }

    interface ContentType {
        companion object {
            const val CHANNEL = "channel"
            const val MOVIE = "movie"
            const val SEASON = "season"
            const val SHORT_MOVIE = "shortmovie"
            const val VIDEO = "video"
            const val EPISODE = "episode"
            const val SERIES = "series"
            const val SPORTS = "sports"
            const val TVSHOW = "tvshow"
            const val OTHER = "other"
            const val PEOPLE = "people"
            const val CATCHUP = "catchup"
            const val LIVETV = "livetv"
            const val LIVE = "live"
            const val LIVETVSHOW = "livetvshow"
            const val LIVETVCHANNEL = "livetvchannel"
            const val LIVETVMOVIE = "livetvmovie"
        }
    }

    companion object {
        val DUMMY_UID = "preUid"
        val DUMMY_TOKEN = "preToken"
        val ANDROID_OS = "Android"
        val SCREEN_ID = "screen_id"
        val CATEGORY = "category"

        val TABLET = "tablet"
        val PHONE = "phone"
        const val YOUTUBE = "youtube"
        const val HUAWEI = "HUAWEI"
        const val MWTV = "mwtv"
        const val TVPROMO = "tvpromo"
        const val HOOQ = "hooq"
        const val EROSNOW = "erosnow"
        const val HLS_URL = "HLS_URL"
        const val FASTFILMZ = "FASTFILMZ"

        const val DEFAULT_LANGUAGE = "en_US"
        const val EMPTY = ""
        const val CHANNEL_DETAIL_PAGE = "channel_detail_page"
        const val CATCHUP_DETAIL_PAGE = "catchup_detail_page"
    }
}
