package tv.airtel.util.config;

import android.content.Context;

/**
 * Created by VipulKumar on 20/03/18.
 *
 */

public class WynkApplication {
    public static Context getContext() {
        return context;
    }

    public static Context context;
}
