package tv.airtel.util.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

import tv.airtel.util.callbacks.OnNetworkChangeListener;

public class NetworkChangeReceiver extends BroadcastReceiver {



    private static NetworkChangeReceiver networkChangeReceiver = null;

    public static NetworkChangeReceiver getInstance() {
        if (networkChangeReceiver == null) {
            synchronized (NetworkChangeReceiver.class) {
                if (networkChangeReceiver == null)
                    networkChangeReceiver = new NetworkChangeReceiver();
            }
        }
        return networkChangeReceiver;
    }

    public static void registerForNetworkChange(Context context, OnNetworkChangeListener networkChangeListenerArg) {
        context.registerReceiver(NetworkChangeReceiver.getInstance(), new IntentFilter(
                ConnectivityManager.CONNECTIVITY_ACTION));

        if (networkChangeListeners == null) {
            networkChangeListeners = new CopyOnWriteArrayList<>();
        }
        networkChangeListeners.add(networkChangeListenerArg);
    }

    public static void unRegisterForNetworkChange(Context context,OnNetworkChangeListener networkChangeListenerArg) {
        if (networkChangeListeners != null) {
            /*
            use CopyOnWriteArrayList as vector also have concurent modification exception
            while remove the element
             */
            synchronized (networkChangeListeners) {
                if (networkChangeListeners != null) {
                    networkChangeListeners.remove(networkChangeListenerArg);
                }
            }
        }
        if (networkChangeListeners != null && networkChangeListeners.size() == 0) {
            context.unregisterReceiver(NetworkChangeReceiver.getInstance());
        }

    }

    public static volatile CopyOnWriteArrayList<OnNetworkChangeListener> networkChangeListeners;

    @Override
    public void onReceive(final Context context, final Intent intent) {
//TODO : replace this with -> isInitialStickyBroadcast()?  - Udit
        if (isInitialStickyBroadcast()) {
            //Return as the system returns a sticky broadcast whenever somebody registers
            return;
        }
        if (intent.getAction().equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
            boolean isConnected = false;

            NetworkInfo networkInfo = intent.getParcelableExtra(ConnectivityManager.EXTRA_NETWORK_INFO);
            String status = NetworkUtil.getConnectivityStatusString(context);
            if (networkInfo != null && networkInfo.getDetailedState() == NetworkInfo.DetailedState.CONNECTED) {

                isConnected = NetworkUtil.isOnline(context);

//                ViaUserManager manager = ManagerProvider.initManagerProvider().getViaUserManager();

//                if (NetworkUtil.CONNECTION_WIFI.equalsIgnoreCase(status)) {
//                    if (context != null && userStateManager.isUserLoggedIn()) {
//                        //manager.checkNetworkInfo(context, null);
//                    }
//                } else if (NetworkUtil.CONNECTION_MOBILE_DATA.equalsIgnoreCase(status)) {
//                    if (context != null && userStateManager.isUserLoggedIn()) {
//                        //manager.checkNetworkInfo(context, null);
//                    }
//                }
                LogUtil.INSTANCE.d("WIFI STATUS", status);

            } else if (networkInfo != null && networkInfo.getDetailedState() == NetworkInfo.DetailedState.DISCONNECTED) {
                isConnected = false;
            }

            if (isConnected) {
                LogUtil.INSTANCE.d("Network", "Internet YAY");
            } else {
                LogUtil.INSTANCE.d("Network", "No internet :(");
            }

            if (null != networkChangeListeners) {
                synchronized (networkChangeListeners) {
                    Iterator<OnNetworkChangeListener> itr = networkChangeListeners.iterator();
                    while (itr.hasNext()) {
                        OnNetworkChangeListener listener = itr.next();
                        if (listener != null) {
                            listener.onNetworkChange(isConnected);
                        }
                    }
                }
            }
            trackNetworkTypeAnalytics(context);
        }
    }

    private void trackNetworkTypeAnalytics(Context context) {
        //TODO analytics need to impelment yet
//        try {
//            JSONObject properties_analytics = new JSONObject();
//            properties_analytics.put(AnalyticConstants.LOGIN_STATUS, userStateManager.isUserLoggedIn() ? Constants.USER_REGISTERED : Constants.USER_GUEST);
//            String netType = ManagerProvider.initManagerProvider().getViaUserManager().isWifi() ? "Wifi" +
//                    "" : DeviceIdentifier.getNetworkType();
//            properties_analytics.put(AnalyticConstants.NETWORKTYPE, netType);
//            ManagerProvider.initManagerProvider().getAnalyticsManager().trackEvent(AnalyticConstants.TRACK_NETWORK, properties_analytics);
//
//        } catch (JSONException e) {
//
//        }
    }

}
