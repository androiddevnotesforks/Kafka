package tv.airtel.sampleleanback.presenter.list

import android.content.Context
import android.support.v17.leanback.widget.Presenter
import android.support.v17.leanback.widget.PresenterSelector
import tv.airtel.sampleleanback.R

/**
 *
 * Created by Satya on 08/06/18.
 */

class EpisodeCardPresenterSelector(private val mContext: Context, private val image: String?) : PresenterSelector() {

    private var presenter: EpisodeCardViewPresenter? = null

    override fun getPresenter(item: Any): Presenter {
        val themeResId = R.style.MovieCardBadgeStyle
        if (presenter == null) {
            presenter = EpisodeCardViewPresenter(mContext, themeResId, image)
        }
        return  presenter!!
    }
}