package tv.airtel.sampleleanback.activity

import android.arch.lifecycle.Observer
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.v4.app.FragmentActivity
import com.airtel.vision.AtvSdk
import com.airtel.vision.util.PermissionsUtil
import tv.airtel.data.api.model.Status
import tv.airtel.sampleleanback.R

class SplashActivity : FragmentActivity(), PermissionsUtil.OnRunTimePermissionListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        managePermissions()
    }


    override fun onResume() {
        super.onResume()
    }

    private fun managePermissions() {
        AtvSdk.getInstance().init(application, "", true, AtvSdk.Flavour.STAGING,
                AtvSdk.DeviceType.DEVICE_STB)
        if (PermissionsUtil.isPermissionGranted(PermissionsUtil.PermissionType.TYPE_APP_START, this)) {
            initConfigure()
        } else {
            PermissionsUtil.requestPermission(PermissionsUtil.PermissionType.TYPE_APP_START, this)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        PermissionsUtil.onRequestPermissionsResult(this, requestCode, permissions, grantResults)
    }

    override fun onPermissionDenied(type: PermissionsUtil.PermissionType) {
        initConfigure()
    }

    override fun onPermissionGranted(type: PermissionsUtil.PermissionType) {
        initConfigure()
    }

    private fun initConfigure() {
        AtvSdk.getInstance().configure().observe(this, Observer { resource ->
            if (resource != null) {
                when (resource.status) {
                    Status.SUCCESS -> {
                        onConfigureSuccess()
                    }
                    else -> {
                    }
                }
            }
        })
    }

    private fun onConfigureSuccess() {
        if(!AtvSdk.getInstance().isUserLoggedIn()){
            AtvSdk.getInstance().authenticateUserWithCustomerId("3018469643").observe(this, Observer {
                it.let {
                    when(it?.status) {
                        Status.SUCCESS -> {
                            onLoginSuccess()
                        }
                    }
                }
            })
        } else{
            launchHomeScreen()
        }
    }

    private fun onLoginSuccess() {
        if(AtvSdk.getInstance().isUserLoggedIn()){
            launchHomeScreen()
        } else {
            launchSignInActivity()
        }
    }

    private fun launchHomeScreen() {
        // adding a delay because configure response is almost immediate
        Handler().postDelayed({
            val mainIntent = Intent(this,MainActivity::class.java)
            if (intent.hasExtra(AssistantSearchActivity.FROM) && intent.extras.getInt(AssistantSearchActivity.FROM) == AssistantSearchActivity.FROM_SEARCHABLE_ACTIVITY) {
                mainIntent.putExtra(KEY_SEARCHABLE_BUNDLE, intent.extras)
            }
            finish()
            startActivity(mainIntent)
        }, 1000)
    }

    private fun launchSignInActivity() {
        val signInIntent = Intent(this,SignInActivity::class.java)
        if (intent.hasExtra(AssistantSearchActivity.FROM) && intent.extras.getInt(AssistantSearchActivity.FROM) == AssistantSearchActivity.FROM_SEARCHABLE_ACTIVITY) {
            signInIntent.putExtra(KEY_SEARCHABLE_BUNDLE, intent.extras)
        }
        finish()
        startActivity(signInIntent)
    }

    companion object {
        const  val KEY_SEARCHABLE_BUNDLE="key_searchable_bundle"
    }
}
