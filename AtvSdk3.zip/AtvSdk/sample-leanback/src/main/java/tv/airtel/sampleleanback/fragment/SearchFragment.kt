package tv.airtel.sampleleanback.fragment

import android.Manifest
import android.app.Activity
import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.support.v17.leanback.app.SearchSupportFragment
import android.support.v17.leanback.widget.ArrayObjectAdapter
import android.support.v17.leanback.widget.ListRow
import android.support.v17.leanback.widget.ListRowPresenter
import android.support.v17.leanback.widget.ObjectAdapter
import android.util.Log
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.model.content.Content
import tv.airtel.data.model.search.SearchResponse
import tv.airtel.sampleleanback.activity.DetailActivity
import tv.airtel.sampleleanback.presenter.search.SearchContentCardPresenterSelector
import tv.airtel.sampleleanback.viewmodel.ContentViewModel

/**
 *
 * Created by VipulKumar on 30/05/18.
 */
class SearchFragment : SearchSupportFragment(), android.support.v17.leanback.app.SearchSupportFragment.SearchResultProvider {

    private val TAG = "SearchFragmentDebug"
    private val REQUEST_SPEECH = 101
    private val PERMS_REQUEST_CODE = 200
    private var mAdapter: ArrayObjectAdapter? = null
    private var contentViewModel: ContentViewModel? = null
    private lateinit var rowPresenter: ListRowPresenter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initUi()
    }

    private var listRowAdapter: ArrayObjectAdapter? = null


    private fun initUi() {

        setSearchResultProvider(this)

        rowPresenter = ListRowPresenter()
        mAdapter = ArrayObjectAdapter(rowPresenter)
        val cardPresenterSelector = SearchContentCardPresenterSelector(context!!)
        listRowAdapter = ArrayObjectAdapter(cardPresenterSelector)

        contentViewModel = ViewModelProviders.of(this).get(ContentViewModel::class.java)
        contentViewModel?.searchResults?.observe(this, Observer {
            onSearchResponse(it)
        })

        setOnItemViewClickedListener { itemViewHolder, item, rowViewHolder, row ->
            if (item is Content) {
                val intent = Intent(activity?.baseContext,
                        DetailActivity::class.java)
                intent.putExtra(ContentDetailFragment.KEY_CONTENT_ID, item.id)
                intent.putExtra(ContentDetailFragment.KEY_CONTENT_TYPE, item.programType)
                startActivity(intent)
            }
        }

        if (hasPermission(activity!!.baseContext, Manifest.permission.RECORD_AUDIO)) {
            setSpeechCallbck()
        } else {
            val perms = arrayOf(Manifest.permission.RECORD_AUDIO)
            requestPermissions(perms, PERMS_REQUEST_CODE)
        }
    }

    private fun onSearchResponse(it: Resource<SearchResponse>?) {
        if (it?.status == Status.SUCCESS) {
            Log.i(TAG, "" + it.data?.searchContentEntity?.results?.size)
            addDataToAdapter(it.data?.searchContentEntity?.results)
//            rowPresenter.setNumRows(5)
//            listRowAdapter?.clear()
//            listRowAdapter?.addAll(0, it.data?.searchContentEntity?.results)
////            rowPresenter.setNumRows(5)
//            mAdapter?.clear()
//            mAdapter?.add(ListRow(listRowAdapter))
        }
    }


    private fun addDataToAdapter(searchResults: List<Content>?) {
        val cardPresenterSelector = SearchContentCardPresenterSelector(context!!)
        var listRowAdapter = ArrayObjectAdapter(cardPresenterSelector)
        mAdapter?.clear()
        searchResults?.forEachIndexed { index, searchContent ->

            listRowAdapter.add(searchContent)
            if ((index + 1) % 6 == 0 || index == searchResults.size - 1) {
                mAdapter?.add(ListRow(listRowAdapter))
                listRowAdapter = ArrayObjectAdapter(cardPresenterSelector)
            }
        }
    }

    override fun onQueryTextSubmit(query: String): Boolean {
       searchQuery(query)
        return true
    }

    override fun getResultsAdapter(): ObjectAdapter? {
        return mAdapter
    }

    override fun onQueryTextChange(newQuery: String?): Boolean {
        searchQuery(newQuery)
        return true
    }

    private fun searchQuery(newQuery: String?) {
        if (newQuery.isNullOrBlank()) {
            addDataToAdapter(ArrayList())
        } else {
            contentViewModel?.searchContent(newQuery!!)
        }
    }

    companion object {
        fun newInstance(): SearchFragment {
            return SearchFragment()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_SPEECH) {
            if (requestCode == Activity.RESULT_OK) {
                setSearchQuery(data, true);
            }
        }

    }


    override fun onRequestPermissionsResult(permsRequestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (permsRequestCode) {
            PERMS_REQUEST_CODE -> {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    setSpeechCallbck()
                }
            }
        }
    }

    private fun setSpeechCallbck() {
        @Suppress("DEPRECATION")
        setSpeechRecognitionCallback {
            try {
                startActivityForResult(recognizerIntent, REQUEST_SPEECH)
            } catch (e: ActivityNotFoundException) {
            }
        }
    }

    private fun hasPermission(context: Context, permission: String): Boolean {
        return PackageManager.PERMISSION_GRANTED == context.packageManager.checkPermission(
                permission, context.packageName)
    }
}