/*
 * Copyright (c) 2017 Google Inc.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package tv.airtel.sampleleanback.util


import android.app.Notification
import android.app.NotificationManager
import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.VectorDrawable
import android.media.tv.TvContract
import android.net.Uri
import android.support.annotation.WorkerThread
import android.support.media.tv.*
import android.support.v4.app.NotificationCompat
import android.util.Log
import tv.airtel.data.model.content.BaseRow
import tv.airtel.sampleleanback.R
import tv.airtel.sampleleanback.util.AppLinkHelper.URI_VIEW

/** Manages interactions with the TV Provider.  */
object TvRecommadationUtil {

    private val TAG = "TvUtil"
    private val CHANNEL_JOB_ID_OFFSET: Long = 1000

    private val CHANNELS_PROJECTION = arrayOf(TvContractCompat.Channels._ID, TvContract.Channels.COLUMN_DISPLAY_NAME, TvContractCompat.Channels.COLUMN_BROWSABLE)

    /**
     * Converts a [BaseRow] into a [Channel] and adds it to the tv provider.
     *
     * @param context used for accessing a content resolver.
     * @param subscription to be converted to a channel and added to the tv provider.
     * @return the id of the channel that the tv provider returns.
     */
    @WorkerThread
    fun createChannel(context: Context, subscription: BaseRow): Long {

        // Checks if our subscription has been added to the channels before.
        val cursor = context.contentResolver
                .query(
                        TvContractCompat.Channels.CONTENT_URI,
                        CHANNELS_PROJECTION, null, null, null)
        if (cursor != null && cursor.moveToFirst()) {
            do {
                val channel = Channel.fromCursor(cursor)
                if ("Feature" == channel.displayName) {
                    Log.d(
                            TAG,
                            "Channel already exists. Returning channel "
                                    + channel.id
                                    + " from TV Provider.")
                    return channel.id
                }
            } while (cursor.moveToNext())
        }

        // Create the channel since it has not been added to the TV Provider.
//        val appLinkIntentUri = Uri.parse("https://wynk.in")
        val appLinkIntentUri = Uri.parse(URI_VIEW)

        val builder = Channel.Builder()
        builder.setType(TvContractCompat.Channels.TYPE_PREVIEW)
                .setDisplayName("Feature")
                .setDescription("STB Channel")
                .setAppLinkIntentUri(appLinkIntentUri)

        Log.d(TAG, "Creating channel: Feature")
        val channelUrl = context.contentResolver
                .insert(
                        TvContractCompat.Channels.CONTENT_URI,
                        builder.build().toContentValues())

        Log.d(TAG, "channel insert at " + channelUrl!!)
        val channelId = ContentUris.parseId(channelUrl)
        Log.d(TAG, "channel id $channelId")

        val bitmap = convertToBitmap(context, R.drawable.img_logo)
        ChannelLogoUtils.storeChannelLogo(context, channelId, bitmap)

        return channelId
    }

    fun getNumberOfChannels(context: Context): Int {
        val cursor = context.contentResolver
                .query(
                        TvContractCompat.Channels.CONTENT_URI,
                        CHANNELS_PROJECTION, null, null, null)
        return cursor?.count ?: 0
    }

    /**
     * Converts a resource into a [Bitmap]. If the resource is a vector drawable, it will be
     * drawn into a new Bitmap. Otherwise the [BitmapFactory] will decode the resource.
     *
     * @param context used for getting the drawable from resources.
     * @param resourceId of the drawable.
     * @return a bitmap of the resource.
     */
    fun convertToBitmap(context: Context, resourceId: Int): Bitmap {
        val drawable = context.getDrawable(resourceId)
        if (drawable is VectorDrawable) {
            val bitmap = Bitmap.createBitmap(
                    drawable.intrinsicWidth,
                    drawable.intrinsicHeight,
                    Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            return bitmap
        }
        return BitmapFactory.decodeResource(context.resources, resourceId)
    }

    fun addPrograms(context: Context, channelId: Long, baseRow: BaseRow) {

        if (baseRow.contents?.content != null) {
            for (content in baseRow.contents!!.content) {

                val programBuilder = PreviewProgram.Builder()
                programBuilder.setChannelId(channelId)
                        .setType(TvContractCompat.PreviewPrograms.TYPE_CLIP)
                        .setTitle(content.title)
                        .setDescription(content.description)
                        .setPosterArtUri(Uri.parse(content.images?.getFeaturedBannerImage()))
                        .setIntentUri(AppLinkHelper.buildBrowseUri(content.id))
                        .setThumbnailUri(Uri.parse(content.images?.getPortraitImage()))
                val programUri = context.getContentResolver()?.insert(TvContractCompat.PreviewPrograms.CONTENT_URI,
                        programBuilder.build().toContentValues())
            }
        }
    }

    fun addToWatchNext(context: Context, baseRow: BaseRow) {

        if (baseRow.contents?.content != null) {
            for (content in baseRow.contents!!.content) {

                val watchNextProgramBuilder = WatchNextProgram.Builder()
                watchNextProgramBuilder.setType(TvContractCompat.WatchNextPrograms.TYPE_CLIP)
                        .setWatchNextType(TvContractCompat.WatchNextPrograms.WATCH_NEXT_TYPE_CONTINUE)
                        .setLastEngagementTimeUtcMillis(System.currentTimeMillis())
                        .setTitle(content.title)
                        .setDescription(content.description)
                        .setPosterArtUri(Uri.parse(content.images?.getLandscapeImage()))
//                .setIntentUri(uri)
                val watchNextProgramUri = context.getContentResolver()
                        ?.insert(TvContractCompat.WatchNextPrograms.CONTENT_URI, watchNextProgramBuilder.build().toContentValues())
            }
        }
    }

    fun recommedationBuilder(context: Context) {
        val notification = NotificationCompat.BigPictureStyle(
                NotificationCompat.Builder(context)
                        .setContentTitle("Old title")
                        .setContentText("old descr")
                        .setPriority(1)
                        .setLocalOnly(true)
                        .setOngoing(true)
                        .setColor(context.resources.getColor(R.color.app_red))
                        .setCategory(Notification.CATEGORY_RECOMMENDATION)
                        .setSmallIcon(R.mipmap.ic_launcher))
//                        .setLargeIcon(" ")

//                        .setContentIntent(mIntent)
//                        .setExtras(extras))
                .build()

        val mNotifManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager?

        mNotifManager?.notify(1, notification)
    }
}
