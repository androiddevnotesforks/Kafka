package tv.airtel.sampleleanback.fragment

import android.arch.lifecycle.Observer
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import com.airtel.vision.AtvSdk

import tv.airtel.data.api.model.Status

import tv.airtel.sampleleanback.R
import tv.airtel.sampleleanback.activity.AssistantSearchActivity
import tv.airtel.sampleleanback.activity.MainActivity
import tv.airtel.sampleleanback.activity.SplashActivity

class SignInFragment : android.support.v4.app.Fragment(), View.OnClickListener {

    private var mNumberEditText: EditText? = null
    private var txtCountryCode: TextView? = null
    private var labelAction: TextView? = null
    private var phoneNumber: String? = null
    private var otp: String? = null

    private var verifyPinText: EditText? = null
    private var mSendPinBtn: Button? = null
    private var verifyPinBtn: Button? = null

    private var layoutMobileNo: LinearLayout? = null
    private var layoutOtp: LinearLayout? = null

    private val isValidate: Boolean
        get() {
            if (phoneNumber!!.length < 10) {
                Toast.makeText(activity, "Please enter valid mobile number", Toast.LENGTH_SHORT).show()
                return false
            } else
                return true
        }

    companion object {

        fun newInstance(): SignInFragment {
            return SignInFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_sign_in, container, false)
        layoutMobileNo = view.findViewById<View>(R.id.layoutMobileNo) as LinearLayout
        layoutOtp = view.findViewById<View>(R.id.layoutOtp) as LinearLayout
        mSendPinBtn = view.findViewById<View>(R.id.send_pin_btn) as Button
        mNumberEditText = view.findViewById<View>(R.id.phone_number_text) as EditText
        txtCountryCode = view.findViewById<View>(R.id.txtCountryCode) as TextView
        labelAction = view.findViewById<View>(R.id.labelAction) as TextView
        verifyPinBtn = view.findViewById<View>(R.id.verifyPinBtn) as Button
        verifyPinText = view.findViewById<View>(R.id.verifyPinText) as EditText
        layoutOtp?.visibility = View.GONE

        mSendPinBtn!!.setOnClickListener(this)
        verifyPinBtn!!.setOnClickListener(this)

        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        init()
    }

    private fun init() {

        mNumberEditText!!.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                onClick(null)
            }
            true
        }
        mNumberEditText!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (mNumberEditText?.getText().toString().length == 10) {
                    mSendPinBtn?.requestFocus()
                    mSendPinBtn?.performClick()
                    if (context != null) {
                        val imm = activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                        imm.hideSoftInputFromWindow(mNumberEditText?.windowToken, 0)
                    }

                }
            }
        })

        verifyPinText!!.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                onClick(null)
            }
            true
        }
        verifyPinText!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (verifyPinText?.getText().toString().length == 4) {
                    verifyPinBtn?.requestFocus()
                    verifyPinBtn?.performClick()
                    if (context != null) {
                        val imm = activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                        imm.hideSoftInputFromWindow(verifyPinText?.windowToken, 0)
                    }

                }
            }
        })
    }

    override fun onClick(view: View?) {

        if (view?.id == R.id.send_pin_btn) {
            phoneNumber = mNumberEditText?.text.toString()

            if (isValidate) {
                registerUserTv(phoneNumber!!, activity!!)
            }
        } else {
            otp = verifyPinText?.text.toString()
            AtvSdk.getInstance().verifyOtp(phoneNumber, otp)?.observe(this, Observer { resource ->
                if (resource != null) {
                    when (resource!!.status) {
                        Status.SUCCESS -> {
                            var mainIntent = Intent(activity, MainActivity::class.java)
                            if (arguments?.getInt(AssistantSearchActivity.FROM) == AssistantSearchActivity.FROM_SEARCHABLE_ACTIVITY) {
                                mainIntent.putExtra(SplashActivity.KEY_SEARCHABLE_BUNDLE, arguments)
                            }
                            activity?.finish()
                            startActivity(mainIntent)
                        }
                        Status.ERROR -> {
                            //                                hideLoader();
                            Toast.makeText(activity, "Unable to verify number", Toast.LENGTH_LONG).show()
                            System.out.println("OOPS THERE IS SOME PROBLEM " + resource.data.toString())
                        }
                        else -> {
                        }
                    }
                }
            })
        }
    }

    internal fun registerUserTv(phoneNumber: String, context: Context) {
        var phoneNumber = phoneNumber

        if (phoneNumber.length < 10) {
            Toast.makeText(context, "Please enter valid mobile number", Toast.LENGTH_SHORT).show()
        } else {
            if (phoneNumber.startsWith("0")) {
                Toast.makeText(context, "Please enter valid mobile number", Toast.LENGTH_SHORT).show()
            } else {
                //                showLoader();
                val countryCode = "+91"
                phoneNumber = countryCode + phoneNumber
                println("OOPS DATA \n$phoneNumber")

                AtvSdk.getInstance().generateOtp(phoneNumber).observe(this, Observer
                { resource ->
                    if (resource != null) {
                        when (resource!!.status) {
                            Status.SUCCESS -> {
                                if (activity != null) {
                                    System.out.println("OOPS " + resource.data.toString())
                                    transferControl()
                                }
                            }
                            Status.ERROR -> {
                                //                                hideLoader();
                                Toast.makeText(activity, "Unable to Generate OTP", Toast.LENGTH_LONG).show()
                                System.out.println("OOPS THERE IS SOME PROBLEM " + resource.data.toString())
                            }
                            else -> {
                            }
                        }
                    }
                })
            }
        }
    }

    internal fun transferControl() {
        layoutMobileNo?.visibility = View.GONE
        layoutOtp?.visibility = View.VISIBLE
        labelAction?.text = "Enter OTP and verify"
    }
}
