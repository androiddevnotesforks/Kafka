package tv.airtel.sampleleanback.page

import android.content.Context
import android.support.v4.view.ViewPager
import android.util.AttributeSet
import android.view.KeyEvent

class FocusableViewPager(context: Context, attributeSet: AttributeSet): ViewPager(context, attributeSet) {
    override fun executeKeyEvent(event: KeyEvent): Boolean {
        return false
    }
}