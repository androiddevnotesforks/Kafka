package tv.airtel.sampleleanback.fragment


import android.os.Bundle
import android.app.Fragment
import android.support.v17.leanback.app.RowsSupportFragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import tv.airtel.sampleleanback.R

/**
 * A simple [Fragment] subclass.
 *
 */
class ContentListRowsFragment : RowsSupportFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        return TextView(activity).apply {
            setText(R.string.hello_blank_fragment)
        }
    }

    companion object {

        fun newInstance(): ContentListRowsFragment {
            return ContentListRowsFragment()
        }
    }

}
