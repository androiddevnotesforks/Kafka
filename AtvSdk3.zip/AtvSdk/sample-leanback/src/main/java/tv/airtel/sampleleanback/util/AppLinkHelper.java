package tv.airtel.sampleleanback.util;

import android.net.Uri;
import androidx.annotation.StringDef;

import java.util.List;

/**
 * Builds and parses uris for deep linking within the app.
 */
public class AppLinkHelper {

    public static final String SCHEMA_URI_PREFIX = "tvrecommendation://app/";
    public static final String BROWSE = "browse";
    public static final String URI_VIEW = SCHEMA_URI_PREFIX + BROWSE;
    private static final int URI_INDEX_OPTION = 0;
    private static final int URI_INDEX_CHANNEL = 1;
    private static final int URI_INDEX_MOVIE = 2;
    private static final int URI_INDEX_POSITION = 3;
    public static final int DEFAULT_POSITION = -1;

    /**
     * Builds a {@link Uri} to deep link into viewing a subscription.
     *
     * @return a uri.
     */
    public static Uri buildBrowseUri(String contentId) {
        return Uri.parse(URI_VIEW).buildUpon().appendPath(contentId).build();
    }

    /**
     * Returns an {@link AppLinkAction} for the given Uri.
     *
     * @param uri to determine the intended action.
     * @return an action.
     */
    public static AppLinkAction extractAction(Uri uri) {

        return new BrowseAction(extractSubscriptionName(uri));
    }

    /**
     * Tests if a {@link Uri} was built for browsing a subscription.
     *
     * @param uri to examine.
     * @return true if the Uri is for browsing a subscription.
     */
    private static boolean isBrowseUri(Uri uri) {
        if (uri.getPathSegments().isEmpty()) {
            return false;
        }
        String option = uri.getPathSegments().get(URI_INDEX_OPTION);
        return BROWSE.equals(option);
    }

    /**
     * Extracts the subscription name from the {@link Uri}.
     *
     * @param uri that contains a subscription name.
     * @return the subscription name.
     */
    private static String extractSubscriptionName(Uri uri) {
        return extract(uri, URI_INDEX_CHANNEL);
    }

    /**
     * Extracts the channel id from the {@link Uri}.
     *
     * @param uri that contains a channel id.
     * @return the channel id.
     */
    private static long extractChannelId(Uri uri) {
        return extractLong(uri, URI_INDEX_CHANNEL);
    }

    /**
     * Extracts the movie id from the {@link Uri}.
     *
     * @param uri that contains a movie id.
     * @return the movie id.
     */
    private static long extractMovieId(Uri uri) {
        return extractLong(uri, URI_INDEX_MOVIE);
    }

    /**
     * Extracts the playback mPosition from the {@link Uri}.
     *
     * @param uri that contains a playback mPosition.
     * @return the playback mPosition.
     */
    private static long extractPosition(Uri uri) {
        return extractLong(uri, URI_INDEX_POSITION);
    }

    private static long extractLong(Uri uri, int index) {
        return Long.valueOf(extract(uri, index));
    }

    private static String extract(Uri uri, int index) {
        List<String> pathSegments = uri.getPathSegments();
        if (pathSegments.isEmpty() || pathSegments.size() < index) {
            return null;
        }
        return pathSegments.get(index);
    }


    /**
     * Action for deep linking.
     */
    public interface AppLinkAction {
        /**
         * Returns an string representation of the action.
         */
//        @ActionFlags
        String getAction();
    }

    /**
     * Browse a subscription.
     */
    public static class BrowseAction implements AppLinkAction {

        private final String mSubscriptionName;

        private BrowseAction(String subscriptionName) {
            this.mSubscriptionName = subscriptionName;
        }

        public String getSubscriptionName() {
            return mSubscriptionName;
        }

        @Override
        public String getAction() {
            return BROWSE;
        }
    }
}
