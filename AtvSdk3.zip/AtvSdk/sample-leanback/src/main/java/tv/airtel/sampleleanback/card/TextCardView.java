/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package tv.airtel.sampleleanback.card;

import android.content.Context;
import android.support.v17.leanback.widget.BaseCardView;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import tv.airtel.data.model.content.Content;
import tv.airtel.sampleleanback.R;

public class TextCardView extends BaseCardView {

    public TextCardView(Context context) {
        super(context, null, R.style.TextCardStyle);
        LayoutInflater.from(getContext()).inflate(R.layout.view_text_card, this);
        setFocusable(true);
    }

    public void updateUi(Content card) {
        TextView extraText = (TextView) findViewById(R.id.extra_text);
        TextView primaryText = (TextView) findViewById(R.id.primary_text);
        final ImageView imageView = (ImageView) findViewById(R.id.main_image);

        extraText.setText(card.getDescription());
        primaryText.setText(card.getTitle());

//        // Create a rounded drawable.
//        int resourceId = card.getLocalImageResourceId(getContext());

        Glide.with(getContext())
                .load(card.getImages().getPortraitImage())
                .into(imageView);
//        Bitmap bitmap = BitmapFactory
//                .decodeResource(getContext().getResources(), resourceId);
//        RoundedBitmapDrawable drawable = RoundedBitmapDrawableFactory.create(getContext().getResources(), bitmap);
//        drawable.setAntiAlias(true);
//        drawable.setCornerRadius(
//                Math.max(bitmap.getWidth(), bitmap.getHeight()) / 2.0f);
//        imageView.setImageDrawable(drawable);
    }

}
