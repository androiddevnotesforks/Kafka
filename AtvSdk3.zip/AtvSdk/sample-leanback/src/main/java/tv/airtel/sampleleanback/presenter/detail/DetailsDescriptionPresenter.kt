/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 *
 */

package tv.airtel.sampleleanback.presenter.detail

import android.content.Context
import android.support.v17.leanback.widget.Presenter
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import tv.airtel.data.model.content.ContentDetail
import tv.airtel.sampleleanback.R
import tv.airtel.sampleleanback.util.ResourceCache
import javax.inject.Inject

class DetailsDescriptionPresenter @Inject
constructor(private val mContext: Context) : Presenter() {

    private val mResourceCache = ResourceCache()

    override fun onCreateViewHolder(parent: ViewGroup): Presenter.ViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.detail_view_content, null)
        return Presenter.ViewHolder(view)
    }

    override fun onBindViewHolder(viewHolder: Presenter.ViewHolder, item: Any) {
        val primaryText = mResourceCache.getViewById<TextView>(viewHolder.view, R.id.primary_text)
        val sndText1 = mResourceCache.getViewById<TextView>(viewHolder.view, R.id.secondary_text_first)
        val sndText2 = mResourceCache.getViewById<TextView>(viewHolder.view, R.id.secondary_text_second)
        val extraText = mResourceCache.getViewById<TextView>(viewHolder.view, R.id.extra_text)

        val card = item as ContentDetail
        primaryText.text = card.title
        sndText1.text = card.programType
        sndText2.text = card.releaseYear
        extraText.text = card.description
    }

    override fun onUnbindViewHolder(viewHolder: Presenter.ViewHolder) {
        // Nothing to do here.
    }
}
