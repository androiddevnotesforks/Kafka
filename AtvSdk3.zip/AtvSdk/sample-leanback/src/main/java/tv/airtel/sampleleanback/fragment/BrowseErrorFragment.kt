/*
 * Copyright (c) 2014 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package tv.airtel.sampleleanback.fragment

import android.content.res.Resources
import android.os.Bundle
import android.os.Handler
import android.support.v17.leanback.app.ErrorFragment
import android.support.v17.leanback.app.ErrorSupportFragment
import android.support.v4.app.Fragment
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ProgressBar

import tv.airtel.sampleleanback.R


/*
 * This class demonstrates how to extend ErrorFragment to create an error dialog.
 */
class BrowseErrorFragment : ErrorSupportFragment() {

    private val mHandler = Handler()
    private var mSpinnerFragment: SpinnerFragment? = null

    private lateinit var errorFragmentInteraction: ErrorFragmentInteraction
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = resources.getString(R.string.app_name)
    }

    override fun onStart() {
        super.onStart()

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mSpinnerFragment = SpinnerFragment()
        activity!!.supportFragmentManager.beginTransaction().add(R.id.fragment_container, mSpinnerFragment).commit()
        mHandler.postDelayed({
            fragmentManager!!.beginTransaction().remove(mSpinnerFragment).commit()
            setErrorContent()
        }, TIMER_DELAY.toLong())

        view.setOnClickListener {

        }

    }

    override fun onStop() {
        super.onStop()
        mHandler.removeCallbacksAndMessages(null)
        fragmentManager!!.beginTransaction().remove(mSpinnerFragment).commit()
    }

    private fun setErrorContent() {
        imageDrawable = resources.getDrawable(R.drawable.lb_ic_sad_cloud, null)
        message = resources.getString(R.string.error_fragment_message)
        setDefaultBackground(TRANSLUCENT)
        buttonText = resources.getString(R.string.retry)
        buttonClickListener = View.OnClickListener {
            errorFragmentInteraction.retryClicked()
            activity?.supportFragmentManager
                    ?.beginTransaction()?.remove(this@BrowseErrorFragment)?.commit()
            activity?.supportFragmentManager?.popBackStack()
        }
    }

    class SpinnerFragment : Fragment() {
        override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                  savedInstanceState: Bundle?): View? {
            val progressBar = ProgressBar(container!!.context)
            if (container is FrameLayout) {
                val res = resources
                val width = res.getDimensionPixelSize(R.dimen.spinner_width)
                val height = res.getDimensionPixelSize(R.dimen.spinner_height)
                val layoutParams = FrameLayout.LayoutParams(width, height, Gravity.CENTER)
                progressBar.layoutParams = layoutParams
            }
            return progressBar
        }
    }

    fun setFragmentInteractionListener(errorFragmentInteraction: ErrorFragmentInteraction) {
        this.errorFragmentInteraction = errorFragmentInteraction
    }

    interface ErrorFragmentInteraction {
        fun retryClicked()
    }

    companion object {
        private val TRANSLUCENT = true
        private val TIMER_DELAY = 1000

        fun newInstance(errorFragmentInteraction: ErrorFragmentInteraction): BrowseErrorFragment {

            val browseErrorFragment = BrowseErrorFragment()
            browseErrorFragment.setFragmentInteractionListener(errorFragmentInteraction)
            return browseErrorFragment
        }
    }
}
