package tv.airtel.sampleleanback.activity

import android.os.Bundle
import android.support.v4.app.FragmentActivity
import tv.airtel.sampleleanback.R
import tv.airtel.sampleleanback.fragment.SearchFragment
import tv.airtel.sampleleanback.util.inTransaction

/**
 * Created by VipulKumar on 30/05/18.
 */
class SearchActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)
        supportFragmentManager.inTransaction {
            replace(R.id.fragment_container, SearchFragment.newInstance())
        }
    }
}
