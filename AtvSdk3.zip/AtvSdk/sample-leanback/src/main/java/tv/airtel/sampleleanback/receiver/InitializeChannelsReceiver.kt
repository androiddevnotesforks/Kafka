package tv.airtel.sampleleanback.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

import tv.airtel.sampleleanback.util.TvRecommadationUtil

/** Initializes channels and programs at installation time.  */
class InitializeChannelsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        Log.i(TAG, "onReceive(): $intent  " + TvRecommadationUtil.getNumberOfChannels(context))
    }

    companion object {
        private val TAG = "InitializeChannelsRcvr"
    }
}
