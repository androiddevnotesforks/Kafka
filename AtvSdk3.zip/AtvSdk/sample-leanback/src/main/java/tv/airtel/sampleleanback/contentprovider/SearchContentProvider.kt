package tv.airtel.sampleleanback.contentprovider

import android.app.SearchManager
import android.content.ContentProvider
import android.content.ContentValues
import android.content.UriMatcher
import android.database.Cursor
import android.database.MatrixCursor
import android.media.Rating
import android.net.Uri
import android.provider.BaseColumns
import android.util.Log
import com.airtel.vision.AtvSdk
import tv.airtel.data.model.content.Content

/**
 *
 * Created by Satya on 15/05/18.
 */
class SearchContentProvider : ContentProvider() {
    private val vision = AtvSdk.getInstance()

    private val TAG = "SearchContentProvider"

    private val AUTHORITY = "tv.airtel.sampleleanback"

    // UriMatcher constant for search suggestions
    private val SEARCH_SUGGEST = 1

    private lateinit var mUriMatcher: UriMatcher

    override fun onCreate(): Boolean {

        mUriMatcher = buildUriMatcher()
        return true
    }

    private val queryProjection = arrayOf(
            BaseColumns._ID,
            SearchManager.SUGGEST_COLUMN_TEXT_1,
            SearchManager.SUGGEST_COLUMN_TEXT_2,
            SearchManager.SUGGEST_COLUMN_RESULT_CARD_IMAGE,
            SearchManager.SUGGEST_COLUMN_CONTENT_TYPE,
            SearchManager.SUGGEST_COLUMN_IS_LIVE,
            SearchManager.SUGGEST_COLUMN_VIDEO_WIDTH,
            SearchManager.SUGGEST_COLUMN_VIDEO_HEIGHT,
            SearchManager.SUGGEST_COLUMN_AUDIO_CHANNEL_CONFIG,
            SearchManager.SUGGEST_COLUMN_PURCHASE_PRICE,
            SearchManager.SUGGEST_COLUMN_RENTAL_PRICE,
            SearchManager.SUGGEST_COLUMN_RATING_STYLE,
            SearchManager.SUGGEST_COLUMN_RATING_SCORE,
            SearchManager.SUGGEST_COLUMN_PRODUCTION_YEAR,
            SearchManager.SUGGEST_COLUMN_DURATION,
            SearchManager.SUGGEST_COLUMN_INTENT_ACTION,
            SearchManager.SUGGEST_COLUMN_INTENT_DATA_ID)


    override fun query(uri: Uri?, p1: Array<out String>?, p2: String?, p3: Array<out String>?, p4: String?): Cursor {
        if (uri != null && mUriMatcher.match(uri) == SEARCH_SUGGEST) {
            Log.d(TAG, "Search suggestions requested.")
            return search(uri.lastPathSegment)

        } else {
            Log.d(TAG, "Unknown uri to query: $uri")
            throw IllegalArgumentException("Unknown Uri: $uri")
        }
    }

    override fun insert(p0: Uri?, p1: ContentValues?): Uri {
        throw UnsupportedOperationException("Insert not implemented")
    }

    override fun update(p0: Uri?, p1: ContentValues?, p2: String?, p3: Array<out String>?): Int {
        throw UnsupportedOperationException("update not implemented")
    }

    override fun delete(p0: Uri?, p1: String?, p2: Array<out String>?): Int {
        throw UnsupportedOperationException("Delete not implemented")
    }

    override fun getType(p0: Uri?): String? {
        return null
    }


    private fun buildUriMatcher(): UriMatcher {
        val uriMatcher = UriMatcher(UriMatcher.NO_MATCH)
        uriMatcher.addURI(
                AUTHORITY, "/search/" + SearchManager.SUGGEST_URI_PATH_QUERY, SEARCH_SUGGEST)
        uriMatcher.addURI(
                AUTHORITY,
                "/search/" + SearchManager.SUGGEST_URI_PATH_QUERY + "/*",
                SEARCH_SUGGEST)
        return uriMatcher
    }

    private fun search(query: String): Cursor {
        val matrixCursor = MatrixCursor(queryProjection)
        if (query.isNotEmpty() && !query.equals("dummy", true)) {
            val resultLocal = vision.searchContentForAssist(query)
            if (resultLocal != null && resultLocal.isNotEmpty()) {
                resultLocal.forEachIndexed { index, content -> matrixCursor.addRow(convertLocalResultIntoRow(content, index)) }

            } else {
                val resultsNetwork = vision.searchContentForAssistFromNetwork(query)

                resultsNetwork?.searchContentEntity?.results?.forEachIndexed { index, content -> matrixCursor.addRow(convertLocalResultIntoRow(content, index)) }
            }
        }
        return matrixCursor
    }



    private fun convertLocalResultIntoRow(it: Content, index: Int): Array<Any?> {
        return arrayOf(
                it.id,
                it.title,
                it.description,
                it.images?.getPortraitImage(),
                "video/mp4",
                false,
                1280,
                720,
                "2.0",
                "$12.99",
                "$1.99",
                Rating.RATING_5_STARS,
                2.75f,
                it.releaseYear,
                it.duration ?: 0 * 1000,
                it.programType,
                it.id)
    }
}