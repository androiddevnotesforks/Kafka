package tv.airtel.sampleleanback.activity

import android.os.Bundle
import android.support.v4.app.FragmentActivity
import tv.airtel.sampleleanback.R
import tv.airtel.sampleleanback.fragment.ContentDetailFragment
import tv.airtel.sampleleanback.fragment.SeasonListFragment

/**
 * Created by b0203949 on 08/06/18.
 */

class SeasonListActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

//        val imageView = (itemViewHolder.view as ImageCardView).mainImageView
//                imageView.main_image.transitionName = ContentDetailFragment.TRANSITION_NAME
//                activity?.supportFragmentManager?.inTransaction {
//
//                    addSharedElement(imageView.main_image, ContentDetailFragment.TRANSITION_NAME)
//                    add(R.id.fragment_container, ContentDetailFragment.newInstance(item.id))
//                    addToBackStack("")

        supportFragmentManager.beginTransaction()
                .replace(R.id.frameLayout_detail,
                        SeasonListFragment.newInstance(intent.getSerializableExtra("contentDetail")))
                .commit()
    }
}