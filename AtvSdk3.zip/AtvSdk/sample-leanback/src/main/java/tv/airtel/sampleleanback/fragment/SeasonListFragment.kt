package tv.airtel.sampleleanback.fragment

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.content.Intent
import android.os.Bundle
import android.support.v17.leanback.app.BrowseSupportFragment
import android.support.v17.leanback.widget.*
import android.support.v4.app.ActivityOptionsCompat
import android.util.Log
import android.view.View
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.model.content.ContentDetail
import tv.airtel.data.model.content.detail.Episode
import tv.airtel.data.model.content.detail.EpisodeDetail
import tv.airtel.data.model.content.detail.SeasonDetail
import tv.airtel.sampleleanback.R
import tv.airtel.sampleleanback.activity.DetailActivity
import tv.airtel.sampleleanback.page.CustomTitleView
import tv.airtel.sampleleanback.presenter.list.EpisodeCardPresenterSelector
import tv.airtel.sampleleanback.viewmodel.ContentViewModel
import java.io.Serializable
import android.util.TypedValue
import android.widget.FrameLayout
import android.view.ViewGroup
import android.view.LayoutInflater



/**
 * Created by b0203949 on 08/06/18.
 */
class SeasonListFragment : BrowseSupportFragment() {
    //    private val pageRowFragmentFactory = PageRowFragmentFactory()
    private var contentViewModel: ContentViewModel? = null

    private var mRowsAdapter: ArrayObjectAdapter? = null
    private var seasonDetail: SeasonDetail? = null
    private var episodeDetailMap: HashMap<String?, EpisodeDetail?>? = null


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        setupRowAdapter()
        initViewModels()
        setupUi()
        setupEventListeners()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = super.onCreateView(inflater, container, savedInstanceState)
        val containerDock = view!!.findViewById<View>(R.id.browse_container_dock) as FrameLayout
        val params = containerDock.layoutParams as FrameLayout.LayoutParams
        val resources = inflater.context.resources
        val newHeaderMargin = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 30f, resources.displayMetrics).toInt()
        val offsetToZero = -resources.getDimensionPixelSize(R.dimen.lb_browse_rows_margin_top)
        params.topMargin = offsetToZero + newHeaderMargin
        containerDock.layoutParams = params
        return view
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            prepareEntranceTransition()
        }
//        mainFragmentRegistry.registerFragment(PageRow::class.java,
//                pageRowFragmentFactory)
    }

    private fun setupRowAdapter() {
        mRowsAdapter = ArrayObjectAdapter(ListRowPresenter())
    }

    private class PageRowFragmentFactory internal constructor() : BrowseSupportFragment.FragmentFactory<android.support.v4.app.Fragment>() {
        override fun createFragment(rowObj: Any?): android.support.v4.app.Fragment {
            // val row = rowObj as Row
            // if (row.id == 1L) {
            return ContentListRowsFragment.newInstance()
            // }
            // return ContentListRowsFragment.newInstance()
        }
    }

    private fun setupUi() {
        (titleView as CustomTitleView).setTitleVisibility(true)
        (titleView as CustomTitleView).setTabVisibility(false)
        (titleView as CustomTitleView).setSubTitleVisibility(true)

        seasonDetail = arguments?.getSerializable("contentDetail") as ContentDetail? as SeasonDetail
        if (seasonDetail != null) {
            title = seasonDetail?.title
            (titleView as CustomTitleView).setSubTitleText(getSubtitle(seasonDetail?.seriesTvSeasons?.size))
            headersState = BrowseSupportFragment.HEADERS_DISABLED
            isHeadersTransitionOnBackEnabled = false
            brandColor = resources.getColor(R.color.colorAccent)
            titleView?.visibility = View.VISIBLE
            if (seasonDetail?.seriesTvSeasons != null) {
                createRows()
            }
        }
    }

    private fun getSubtitle(size: Int?): CharSequence? {
        return if (size != null && size > 0) seasonDetail?.seriesTvSeasons?.size.toString() + (if (size > 1) " Seasons" else "Season") else ""
    }


    private fun initViewModels() {
        contentViewModel = ViewModelProviders.of(this)
                .get(ContentViewModel::class.java)

        contentViewModel?.contentSeasonDetail?.observe(this, Observer {
            onSeasonDetailResponse(it)
        })

        contentViewModel?.contentEpisodeDetail?.observe(this, Observer {
            onEpisodeDetailResponse(it)
        })
    }

    private fun onEpisodeDetailResponse(it: Resource<EpisodeDetail>?) {
        if (it?.status == Status.SUCCESS && it?.data != null) {
            if (episodeDetailMap == null) {
                episodeDetailMap = HashMap(seasonDetail?.seriesTvSeasons?.size ?: 0)
            }
            episodeDetailMap?.put(it.data?.id, it.data)
            if (episodeDetailMap?.size ?: 0 >= seasonDetail?.seriesTvSeasons?.size ?: 0) {
                mRowsAdapter?.clear()
                seasonDetail?.seriesTvSeasons?.forEach { entry -> mRowsAdapter?.add(createCardRow(episodeDetailMap?.get(entry.seasonId))) }
                mRowsAdapter?.notifyItemRangeChanged(0, episodeDetailMap?.size ?: 0)
                startEntranceTransition()
            } else if (count < (seasonDetail?.seriesTvSeasons?.size ?: 0) - 1) {
                fetchNextEpisode()
            }
        }
    }

    private fun onSeasonDetailResponse(it: Resource<SeasonDetail>?) {
        //   TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }


    private fun setupEventListeners() {
        onItemViewClickedListener = ItemViewClickedListener()
        onItemViewSelectedListener = ItemViewSelectedListener()
    }

    private inner class ItemViewSelectedListener : OnItemViewSelectedListener {

        override fun onItemSelected(itemViewHolder: Presenter.ViewHolder?, item: Any?,
                                    rowViewHolder: RowPresenter.ViewHolder?, row: Row?) {
            Log.d("Listener", "" + item?.toString())
        }
    }


    private inner class ItemViewClickedListener : OnItemViewClickedListener {

        override fun onItemClicked(itemViewHolder: Presenter.ViewHolder, item: Any,
                                   rowViewHolder: RowPresenter.ViewHolder, row: Row) {
            if (item is Episode) {
                val imageView = (itemViewHolder.view as ImageCardView).mainImageView

                val bundle = ActivityOptionsCompat.makeSceneTransitionAnimation(activity!!,
                        imageView, ContentDetailFragment.TRANSITION_NAME).toBundle()
                val intent = Intent(activity?.baseContext,
                        DetailActivity::class.java)
                intent.putExtra(ContentDetailFragment.KEY_CONTENT_ID, item.refId)
                intent.putExtra(ContentDetailFragment.KEY_CONTENT_TYPE, "EPISODE")
                startActivity(intent, bundle)
            }
        }
    }

    private var count: Int = -1

    private fun createRows() {
        mRowsAdapter?.clear()
        Log.e("Adapter", "" + mRowsAdapter?.size())
        adapter = mRowsAdapter
        fetchNextEpisode()
        startEntranceTransition()
    }

    @Synchronized
    private fun fetchNextEpisode() {
        if (count < ((seasonDetail?.seriesTvSeasons?.size ?: 0) - 1)) {
            try {
                contentViewModel?.fetchEpisodeDetail(seasonDetail?.seriesTvSeasons?.get(++count)?.seasonId
                        ?: "")
            } catch (e: IndexOutOfBoundsException) {
                e.printStackTrace()
            }

        }
    }

    private fun createCardRow(episodeDetail: EpisodeDetail?): ListRow {
        val presenterSelector = EpisodeCardPresenterSelector(context!!, seasonDetail?.images?.getLandscapeImage())
        val listRowAdapter = ArrayObjectAdapter(presenterSelector)
        episodeDetail?.episodes?.forEach {
            listRowAdapter.add(it)
        }
        val desc = getDesc(episodeDetail?.episodes?.size ?: 0)
        var headerItem = HeaderItem(episodeDetail?.title)

        headerItem.description = desc
        headerItem.contentDescription = desc
        return ListRow(headerItem, listRowAdapter)
    }

    private fun getDesc(size: Int): CharSequence? {
        return if (size > 1) {
            size.toString() + " Episodes"
        } else {
            size.toString() + " Episode"
        }

    }

    companion object {
        private const val TAG = "ContentListDebug"
        fun newInstance(content: Serializable): SeasonListFragment {
            var seasonListFragment = SeasonListFragment()
            var args = Bundle()
            args.putSerializable("contentDetail", content)
            seasonListFragment.arguments = args
            return seasonListFragment
        }
    }
}