package tv.airtel.sampleleanback.presenter.search

import android.content.Context
import android.support.v17.leanback.widget.Presenter
import android.support.v17.leanback.widget.PresenterSelector
import tv.airtel.sampleleanback.R

/**
 * This PresenterSelector will decide what Presenter to use depending on a given card's type.
 */
class SearchContentCardPresenterSelector(private val mContext: Context) : PresenterSelector() {

    private var presenter: ImageSearchContentCardViewPresenter? = null

    override fun getPresenter(item: Any): Presenter {
        val themeResId = R.style.MovieCardBadgeStyle
        if (presenter == null) {
            presenter = ImageSearchContentCardViewPresenter(mContext, themeResId)
        }
        return  presenter!!
    }
}
