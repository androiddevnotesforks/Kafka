package tv.airtel.sampleleanback.fragment

import android.os.Bundle
import android.app.Fragment
import android.support.v17.leanback.app.PlaybackFragment
import android.support.v17.leanback.media.MediaPlayerAdapter
import android.support.v17.leanback.media.PlaybackTransportControlGlue
import android.support.v17.leanback.widget.*


/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [PlaybackControls.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [PlaybackControls.newInstance] factory method to
 * create an instance of this fragment.
 *
 */
class PlaybackControls : PlaybackFragment() {

    private lateinit var mRowsAdapter: ArrayObjectAdapter
    private lateinit var mPlayPauseAction: PlaybackControlsRow.PlayPauseAction
    private lateinit var mFastForwardAction: PlaybackControlsRow.FastForwardAction
    private lateinit var mRewindAction: PlaybackControlsRow.RewindAction
    private lateinit var presenterSelector: ControlButtonPresenterSelector
    private lateinit var mPlaybackControlsRowPresenter: PlaybackControlsRowPresenter

    private lateinit var mPlaybackTransportControlGlue: PlaybackTransportControlGlue<MediaPlayerAdapter>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

//        mPlaybackTransportControlGlue = PlaybackTransportControlGlue(activity,MediaPlayerAdapter(activity))
//        mPlaybackTransportControlGlue.host = PlaybackFragmentGlueHost(this)
//        mPlaybackTransportControlGlue.subtitle = "Prince Midha"
//        mPlaybackTransportControlGlue.title = "GradSlam"

//        mPlayPauseAction = PlaybackControlsRow.PlayPauseAction(activity);
//        mFastForwardAction = PlaybackControlsRow.FastForwardAction(activity);
//        mRewindAction = PlaybackControlsRow.RewindAction(activity);
//        var row = PlaybackControlsRow()
//        mObjectAdapter = ArrayObjectAdapter()
//        mObjectAdapter.add(mPlayPauseAction)
//        mObjectAdapter.add(mFastForwardAction)
//        mObjectAdapter.add(mRewindAction)
//        row.primaryActionsAdapter = mObjectAdapter
        setUpRows()
    }

    fun setUpRows() {
        val ps = ClassPresenterSelector()
        mPlaybackControlsRowPresenter = PlaybackControlsRowPresenter()
        mPlaybackControlsRowPresenter.setOnActionClickedListener {
            activity
        }
        ps.addClassPresenter(PlaybackControlsRow::class.java, mPlaybackControlsRowPresenter)
        mRowsAdapter = ArrayObjectAdapter(ps)
        addPlaybackControlsRow()
        adapter = mRowsAdapter;
    }

    private lateinit var mPlaybackControlsRow: PlaybackControlsRow

    fun addPlaybackControlsRow() {
        mPlaybackControlsRow = PlaybackControlsRow()
        mRowsAdapter.add(mPlaybackControlsRow);
        presenterSelector = ControlButtonPresenterSelector()
        var mPrimaryActionsAdapter = ArrayObjectAdapter(presenterSelector)
        mPlaybackControlsRow.setPrimaryActionsAdapter(mPrimaryActionsAdapter);
        mPlayPauseAction = PlaybackControlsRow.PlayPauseAction(activity)
        mFastForwardAction = PlaybackControlsRow.FastForwardAction(activity)
        mRewindAction = PlaybackControlsRow.RewindAction(activity)

        mPrimaryActionsAdapter.add(mRewindAction)
        mPrimaryActionsAdapter.add(mPlayPauseAction)
        mPrimaryActionsAdapter.add(mFastForwardAction)
    }

    fun getRewindActionId(): Long {
        return mRewindAction.id
    }

    fun getPlayPauseActionId(): Long {
        return mPlayPauseAction.id
    }

    fun getFastForwardActionId(): Long {
        return mFastForwardAction.id
    }
}
