package tv.airtel.visionsample.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.airtel.vision.AtvSdk
import kotlinx.android.synthetic.main.fragment_home.*
import tv.airtel.data.di.Injectable
import tv.airtel.data.model.user.Page
import tv.airtel.visionsample.R
import tv.airtel.visionsample.R.id.bottom_bar
import tv.airtel.visionsample.R.id.view_pager
import tv.airtel.visionsample.adapter.HomePagerAdapter
import tv.airtel.visionsample.databinding.FragmentHomeBinding
import tv.airtel.visionsample.util.AutoClearedValue
import tv.airtel.visionsample.util.ext.inflateWithDataBinding

/**
 * Created by VipulKumar on 2/22/18.
 *
 */
class HomeFragment : BaseFragment(), Injectable {
    private lateinit var binding: AutoClearedValue<FragmentHomeBinding>

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val dataBinding = container?.inflateWithDataBinding(R.layout.fragment_home) as FragmentHomeBinding
        binding = AutoClearedValue(this, dataBinding)
        return dataBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initUi()
    }

    private fun initUi() {
        val pageIds = AtvSdk.getInstance().getAppConfig()?.pages//Page.values().toList()
        // disable scrolling on viewPager to simulate proper BottomBar behaviour
        view_pager.isPagingEnabled = false
        view_pager.adapter = HomePagerAdapter(childFragmentManager, pageIds as ArrayList<Page>)
        view_pager.offscreenPageLimit = 5
        initBottomBarNavigation()
    }

    private fun launchHomeFragment(position: Int) {
        view_pager.setCurrentItem(position, false)
    }

    private fun initBottomBarNavigation() {
        bottom_bar.setOnTabSelectListener { itemId ->
            when (itemId) {
                R.id.action_featured -> launchHomeFragment(0)
                R.id.action_tv_show -> launchHomeFragment(1)
                R.id.action_movies -> launchHomeFragment(2)
                R.id.action_explore -> launchHomeFragment(3)
                R.id.action_profile -> launchHomeFragment(4)
            }
        }
    }

    companion object {
        fun newInstance(): HomeFragment {
            val args = Bundle()
            val fragment = HomeFragment()
            fragment.arguments = args
            return fragment
        }
    }
}
