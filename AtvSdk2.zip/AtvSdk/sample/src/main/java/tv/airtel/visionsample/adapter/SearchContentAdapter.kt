package tv.airtel.visionsample.adapter

import com.airbnb.epoxy.TypedEpoxyController
import timber.log.Timber
import tv.airtel.data.model.content.Content
import tv.airtel.visionsample.ItemSearchCardPortraitBindingModel_
import java.lang.RuntimeException

/**
 * Epoxy controller for building and adding models to recyclerView in related content list on detail page.
 */
class SearchContentAdapter constructor(val itemClickListener: ItemClickListener)
    : TypedEpoxyController<List<Content>>() {
    override fun buildModels(list: List<Content>?) {
        val relatedModels = arrayListOf<ItemSearchCardPortraitBindingModel_>()

        if (list != null && list.isNotEmpty()) {
            list.forEach {
                ItemSearchCardPortraitBindingModel_()
                        .id(it.id!!)
                        .itemClickListener { model, parentView, clickedView, position ->
                            itemClickListener.onContentItemClicked(model.content())
                        }
                        .content(it)
                        .addTo(this)
            }
        }

//        VerticalGridCarouselModel_()
//                .id("id2")
//                .models(relatedModels)
//                .paddingDp(4)
//                .addTo(this)
    }

    interface ItemClickListener {
        fun onContentItemClicked(content: Content)
    }

    override fun onExceptionSwallowed(exception: RuntimeException) {
        // we swallow exceptions related to duplicate IDs for now
        Timber.e(exception.cause)
    }
}