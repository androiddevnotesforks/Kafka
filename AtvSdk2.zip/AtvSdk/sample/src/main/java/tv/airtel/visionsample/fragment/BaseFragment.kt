package tv.airtel.visionsample.fragment

import android.support.v4.app.Fragment

/**
 * Created by VipulKumar on 1/16/18.
 * Top-level base fragment.
 */

abstract class BaseFragment : Fragment() {
}
