package tv.airtel.visionsample.activity

import android.arch.lifecycle.Observer
import android.os.Bundle
import android.util.Log
import com.airtel.vision.AtvSdk
import tv.airtel.data.api.model.Status
import tv.airtel.data.di.Injectable
import tv.airtel.data.utilmodule.FeedbackUtil
import tv.airtel.visionsample.R

class LoginActivity : BaseActivity(), Injectable {

    val vision = AtvSdk.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(0, 0)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        initUi()
    }

    private fun initUi() {
        btn_send_otp.setOnClickListener {
            vision.generateOtp(et_mobile_no.text.toString()).observe(this, Observer {
                if (it != null && it.status == Status.SUCCESS) {
                    FeedbackUtil.showMessage(this, "OTP Sent")
                }
            })
        }

        btn_login.setOnClickListener {
            vision.verifyOtp(et_mobile_no.text.toString(), et_otp.text.toString())?.observe(this, Observer {
                if (it != null) {
                    when (it.status) {
                        Status.SUCCESS -> {
                            if (it.data != null && it.data?.msisdnDetected!!) {
                                finish()
                            } else {
                                FeedbackUtil.showMessage(this, "Wrong OTP")
                            }
                        }
                        Status.ERROR -> {
                            Log.e("Login", it.error?.errorUserMessage)
                        }
                        else -> {
                        }
                    }
                }
            })
        }
    }
}
