package tv.airtel.visionsample.util

import android.animation.Animator
import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.view.View
import android.view.ViewAnimationUtils
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.AnimationUtils

/**
 * Created by VipulKumar on 3/3/18.
 *
 */

object AnimationUtil {
    @SuppressLint("NewApi")
    fun revealView(view: View?, hide: Boolean, animatorListener: Animator.AnimatorListener) {
        if (DeviceUtil.isPostLollipop) {
            view?.let {
                if (hide) {
                    val cx = (view.left + view.right) / 2
                    val cy = (view.top + view.bottom) / 2

                    // get the final radius for the clipping circle
                    val finalRadius = Math.max(view.width, view.height)
                    // i just swapped from radius, to radius arguments
                    val animator = ViewAnimationUtils.createCircularReveal(view, cx, cy, finalRadius.toFloat(), 0f)
                    animator.addListener(animatorListener)
                    animator.interpolator = AccelerateDecelerateInterpolator()
                    animator.duration = 350
                    animator.start()
                }
            }
        }
    }

    fun animationIn(view: View?, animation: Int, delayTime: Int, context: Context) {
        val handler = Handler()
        handler.postDelayed({
            val inAnimation = AnimationUtils.loadAnimation(
                    context.applicationContext, animation)
            view?.animation = inAnimation
            view?.visibility = View.VISIBLE
        }, delayTime.toLong())
    }

    fun animationOut(view: View?, animation: Int, delayTime: Int,
                     isViewGone: Boolean, context: Context) {
        view?.visibility = View.VISIBLE
        val handler = Handler()
        handler.postDelayed({
            val outAnimation = AnimationUtils.loadAnimation(
                    context.applicationContext, animation)
            view?.animation = outAnimation
            if (isViewGone)
                view?.visibility = View.GONE
            else
                view?.visibility = View.INVISIBLE
        }, delayTime.toLong())
    }
}
