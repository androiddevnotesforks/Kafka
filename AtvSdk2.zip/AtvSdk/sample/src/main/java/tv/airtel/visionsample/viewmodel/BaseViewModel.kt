package tv.airtel.visionsample.viewmodel

import android.arch.lifecycle.ViewModel

/**
 * Created by VipulKumar on 2/22/18.
 * A ViewModel to inherit from.
 */
open class BaseViewModel : ViewModel()