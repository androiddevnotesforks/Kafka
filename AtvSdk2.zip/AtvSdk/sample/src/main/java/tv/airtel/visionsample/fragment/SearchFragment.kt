package tv.airtel.visionsample.fragment

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.GridLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.airtel.vision.di.Injectable
import kotlinx.android.synthetic.main.fragment_search.*
import tv.airtel.data.api.model.Resource
import tv.airtel.data.model.content.Content
import tv.airtel.data.model.search.SearchResponse
import tv.airtel.visionsample.R
import tv.airtel.visionsample.adapter.SearchContentAdapter
import tv.airtel.visionsample.databinding.FragmentSearchBinding
import tv.airtel.visionsample.util.AutoClearedValue
import tv.airtel.visionsample.util.ext.inflateWithDataBinding
import tv.airtel.visionsample.viewmodel.SampleContentViewModel

/**
 * Created by VipulKumar on 01/05/18.
 */
class SearchFragment : Fragment(), Injectable {
    private lateinit var binding: AutoClearedValue<FragmentSearchBinding>
    private lateinit var sampleContentViewModel: SampleContentViewModel
    private lateinit var searchContentAdapter: SearchContentAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val dataBinding = container
                ?.inflateWithDataBinding(R.layout.fragment_search) as FragmentSearchBinding
        binding = AutoClearedValue(this, dataBinding)
        return dataBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViewModels()
        initUi()
    }

    private fun initUi() {
        searchContentAdapter = SearchContentAdapter(object: SearchContentAdapter.ItemClickListener {
            override fun onContentItemClicked(content: Content) {

            }
        })

        recycler_view_search.layoutManager = GridLayoutManager(context, 3)
        recycler_view_search.adapter = searchContentAdapter.adapter
    }

    private fun initViewModels() {
        sampleContentViewModel = ViewModelProviders.of(this)
                .get(SampleContentViewModel::class.java)
        //  observe the changes on content
        sampleContentViewModel.searchResults?.observe(this, Observer {
            onSearchResponse(it)
        })
    }

    fun setSearchText(keyword: String) {
        sampleContentViewModel.searchContent(keyword)
    }

    private fun onSearchResponse(it: Resource<SearchResponse>?) {
        binding.get()?.resource = it
        if (it?.data != null) {
            searchContentAdapter.setData(it.data?.searchContentEntity?.results)
        }
    }

    companion object {
        fun newInstance(): SearchFragment {
            val args = Bundle()
            val fragment = SearchFragment()
            fragment.arguments = args
            return fragment
        }
    }
}
