package tv.airtel.visionsample.util

/**
 * Generic interface for retry buttons.
 */
interface RetryCallback {
    fun retry()
}
