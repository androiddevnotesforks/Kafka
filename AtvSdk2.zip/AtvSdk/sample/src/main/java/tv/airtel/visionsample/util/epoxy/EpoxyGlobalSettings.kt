package tv.airtel.visionsample.util.epoxy

import com.airbnb.epoxy.Carousel

/**
 * Created by VipulKumar on 2/16/18.
 */

object EpoxyGlobalSettings {
    fun setSnapHelper() {
        Carousel.setDefaultGlobalSnapHelperFactory(null)
    }
}
