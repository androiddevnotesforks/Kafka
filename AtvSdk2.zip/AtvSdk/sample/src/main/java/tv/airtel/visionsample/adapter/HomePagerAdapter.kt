package tv.airtel.visionsample.adapter

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import tv.airtel.data.model.user.Page
import tv.airtel.visionsample.fragment.ContentListFragment
import tv.airtel.visionsample.fragment.ProfileFragment

internal
class HomePagerAdapter(fragmentManager: FragmentManager,
                       private val pages: ArrayList<Page>) : FragmentPagerAdapter(fragmentManager) {

    override fun getItem(position: Int): Fragment {
        if (position == 4) {
            return ProfileFragment.newInstance()
        }
        return ContentListFragment.newInstance(pages[position].id)
    }

    override fun getCount(): Int {
        return pages.size
    }
}
