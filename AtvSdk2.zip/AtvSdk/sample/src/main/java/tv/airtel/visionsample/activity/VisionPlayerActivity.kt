package tv.airtel.visionsample.activity

import analytics.Event
import analytics.PlayerEventListener
import android.arch.lifecycle.Observer
import android.graphics.Point
import android.os.Bundle
import android.os.Handler
import android.support.constraint.ConstraintLayout
import android.support.v7.app.AlertDialog
import android.support.v7.widget.AppCompatSeekBar
import android.util.DisplayMetrics
import android.view.Display
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import com.airtel.vision.AtvSdk
import helper.ATVPlayer
import helper.PlayerAuthentication
import helper.PlayerView
import model.ContentType
import model.DeviceType
import model.Environment
import model.PlayerContentDetail
import model.PlayerDimension
import model.PlayerState
import model.SeekType
import timber.log.Timber
import tv.airtel.data.model.content.ContentDetail
import tv.airtel.visionsample.R
import tv.airtel.visionsample.fragment.SettingsDialog
import tv.airtel.wynk.analytics.Analytics
import tv.airtel.wynk.analytics.AnalyticsHashMap


/**
 *
 * Created by VipulKumar on 27/06/18.
 */
class VisionPlayerActivity : BaseActivity(), PlayerEventListener {
    private lateinit var content: ContentDetail
    private lateinit var playerView: PlayerView
    private lateinit var retryButton: View
    private lateinit var progressBar: ProgressBar
    private var toggleableControls = false

    lateinit var controls: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.activity_vision_player)
        playerView = findViewById(R.id.playerView)
        retryButton = findViewById(R.id.retryButton)
        playerView.setEventListener(this)
        retryButton.visibility = View.GONE
        progressBar = findViewById(R.id.progress_bar)
        content = intent?.getSerializableExtra("content") as ContentDetail


        val builder = PlayerAuthentication.Builder()
        if (AtvSdk.getInstance().isUserLoggedIn()) {
            builder.uid(AtvSdk.getInstance().getCurrentUser()?.uid)
                    .token(AtvSdk.getInstance().getCurrentUser()?.token)
                    .userProperties(AtvSdk.getInstance().getCurrentUser()?.userProperties)
                    .customerType(AtvSdk.getInstance().getCurrentUser()?.customerType)
                    .userLanguage(AtvSdk.getInstance().getCurrentUser()?.userContentProperties?.get("ln"))
        }
        builder.deviceType(DeviceType.DEVICE_PHONE)
                .environment(Environment.devEnvironment)

        ATVPlayer.init(applicationContext, builder.build())

        assignControls()
//        playerView.load(transformToPlayerContentDetailList(), false, 0)

//        playerView.load(transformToPlayerContentDetail(content), false, 0)
//        playerView.load(listOf(transformToLivePlayerContentDetail()))
        playerView.load(listOf(transformToPlayerContentDetail(content)))
//        playerView.load(listOf(transformToPlayerContentDetail(content), transformToLivePlayerContentDetail()))
//        playerView.postDelayed({
//            playerView.load(listOf(/*transformToPlayerContentDetail(content),*/ transformToLivePlayerContentDetail()))
//            playerView.load(transformToLivePlayerContentDetail(), true, -1)
//        }, 10 * 1000)


//        calculateDeviceMetrics()
    }

    private fun calculateDeviceMetrics() {
        val windowManager = windowManager
        val display = windowManager.defaultDisplay
        val realSize = Point()
        Display::class.java.getMethod("getRealSize", Point::class.java).invoke(display, realSize)
        val mWidthPixels = realSize.x * 1.0
        val mHeightPixels = realSize.y * 1.0

        Timber.d("in pixels: width = $mWidthPixels, height = $mHeightPixels")

        val dm = DisplayMetrics()
        getWindowManager().defaultDisplay.getMetrics(dm)

        val widthInInches = mWidthPixels / dm.xdpi
        val heightInInches = mHeightPixels / dm.ydpi

        val x = Math.pow(widthInInches, 2.0)
        val y = Math.pow(heightInInches, 2.0)
        val screenInches = Math.sqrt(x + y)
        Timber.d("in inches: width = $widthInInches, height = $heightInInches")
        Timber.d("Screen inches : $screenInches")

        val ppi = (mWidthPixels * mHeightPixels) / (widthInInches * heightInInches)
        Timber.d("in inches: width = $widthInInches, height = $heightInInches")
        Timber.d("Screen inches : $screenInches")
    }

    private fun assignControls() {
        controls = layoutInflater.inflate(R.layout.view_controls, null)
        playerView.addView(controls)

        val root = controls.findViewById<ConstraintLayout>(R.id.root)
        val play = controls.findViewById<ImageView>(R.id.play)
        val forward = controls.findViewById<ImageView>(R.id.forward)
        val replay = controls.findViewById<ImageView>(R.id.replay)
        val seekBar = controls.findViewById<AppCompatSeekBar>(R.id.seek_bar)
        val videoQualitySelector = controls.findViewById<TextView>(R.id.select_quality)

        retryButton.setOnClickListener {
            playerView.retry()
        }

        controls.visibility = View.GONE

        playerView.getPlayerStateObservable().observe(this, Observer {
            //            Toast.makeText(this, it?.name, Toast.LENGTH_LONG).show()
            when (it) {
                is PlayerState.Buffering -> {

                    Handler().postDelayed({
                        if (playerView.getPlayerStateObservable().value is PlayerState.Buffering) {
                            progressBar.visibility = View.VISIBLE
                        }
                    }, 1000)
                    retryButton.visibility = View.GONE
                }

                is PlayerState.Idle -> {
                    retryButton.visibility = View.GONE
                    playerView.getPlayerDimension().observe(this, Observer {
                        Timber.d("$it")
                    })
                    play.setImageResource(R.drawable.ic_pause_black_24dp)
//                    progressBar.visibility = View.VISIBLE
                    playerView.play()
                    toggleableControls = true
                }
                is PlayerState.Playing -> {
                    play.setImageResource(R.drawable.ic_pause_black_24dp)
                    progressBar.visibility = View.GONE
                    retryButton.visibility = View.GONE
                }
                is PlayerState.Paused -> {

                    play.setImageResource(R.drawable.ic_play_arrow_black_24dp)
                    progressBar.visibility = View.GONE
                    retryButton.visibility = View.GONE
                }
                is PlayerState.Stopped -> {
                    retryButton.visibility = View.GONE
                }
                is PlayerState.Finished -> {
//                    playerView.load(listOf(/*transformToPlayerContentDetail(content),*/ transformToLivePlayerContentDetail()))
                    retryButton.visibility = View.GONE
                }
                is PlayerState.Error -> {

                    retryButton.visibility = View.VISIBLE
                }
                else -> {
                }
            }
        })

        playerView.getPlayerSubtitleObservable().observe(this, Observer<String> {
            it?.let {
                util.Logger.d(it)
            }
        })

        playerView.getFristFrameRenderTimeObservable().observe(this, Observer {
            it?.let {
                util.Logger.d("$it")
            }
        })

        forward.setOnClickListener {
            playerView.setSubtitle(getSubtitleList()!![1])
            var settingsDialog = SettingsDialog()
            var bundle = Bundle()
            bundle.putStringArrayList("data",getSubtitleList())
            settingsDialog.arguments = bundle

            settingsDialog.show(supportFragmentManager?.beginTransaction(),"SETTINGS_DIALOG")
            //            playerView.seekTo(30 * 1000, SeekType.RELATIVE)
        }

        replay.setOnClickListener {
            playerView.setSubtitle(getSubtitleList()!![0])
            playerView.seekTo(-30 * 1000, SeekType.RELATIVE)
        }
        root.setOnClickListener {
            if (controls.visibility == View.VISIBLE) {
                controls.visibility = View.GONE
            } else {
                controls.visibility = View.VISIBLE
            }

        }
        playerView.setOnClickListener {
            if (controls.visibility == View.VISIBLE) {
                controls.visibility = View.GONE
            } else {
                controls.visibility = View.VISIBLE
            }

        }
        play.setOnClickListener {
            val state = playerView.getPlayerStateObservable().value
            if (state === PlayerState.Playing) {
                play.setImageResource(R.drawable.ic_pause_black_24dp)
                playerView.pause()
            } else if (state === PlayerState.Paused || state === PlayerState.Idle) {
                play.setImageResource(R.drawable.ic_play_arrow_black_24dp)
                playerView.play()
            }
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    playerView.seekTo((progress * 1000).toLong(), SeekType.ABSOLUTE)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }
        })

        playerView.getSeekInfoObservable().observe(this, Observer {
//            getSubtitleList()
            seekBar.progress = ((it?.currentPosition ?: 0) / 1000).toInt()
            seekBar.max = ((it?.duration ?: 0) / 1000).toInt()
        })

        videoQualitySelector.setOnClickListener {
            showQualitySelectionDialog()
        }

        controls.visibility = View.GONE
    }

    private fun showQualitySelectionDialog() {
        val adb = AlertDialog.Builder(this)
        val items = ArrayList<CharSequence>()
        val currentBitrate = playerView.getCurrentBitrate()
        var selectedIndex = 0
//        items.add("Auto")

        playerView.getAvailableFormats().forEachIndexed { index, bitrate ->
            items.add("$bitrate")
            if (bitrate.bitrate == currentBitrate) {
                selectedIndex = index
            }
        }
        adb.setSingleChoiceItems(items.toTypedArray(), selectedIndex) { dialog, which ->
            playerView.setBitrate(playerView.getAvailableFormats()[which].bitrate)
            dialog.dismiss()
        }
        adb.setNegativeButton("Cancel", null)
        adb.setTitle("Select Quality")
        adb.show()
    }

    private fun transformToPlayerContentDetail(detail: ContentDetail): PlayerContentDetail {
        val playerContentDetail = PlayerContentDetail()
        playerContentDetail.id = detail.id
        playerContentDetail.cpId = detail.cpId
//        playerContentDetail.lastWatchedPosition = detail.lastWatchedPosition
        playerContentDetail.programType = detail.programType
        playerContentDetail.skpCr = detail.skpCr
        playerContentDetail.skpIn = detail.skpIn
        return playerContentDetail
    }


    private fun transformToPlayerContentDetailList(): List<PlayerContentDetail> {
        val item1 = PlayerContentDetail()
        item1.id = item1.id
        item1.playUrl = item1.playUrl
        item1.contentType = ContentType.URL

//        val item2 = PlayerContentDetail()
//        item2.id = "ALTBALAJI_MOVIE_1185"
//        item2.cpId = "ALTBALAJI"

        val mutableList = listOf(item1)

//        val mutableList = playerView.getPlaylist() as MutableList<PlayerContentDetail>
//        mutableList.add(0, item1)


        return mutableList
    }

//    private fun transformToLivePlayerContentDetail(): PlayerContentDetail {
//        val playerContentDetail = PlayerContentDetail()
//
//        playerContentDetail.id = "MWTV_LIVETVCHANNEL_818"
//        playerContentDetail.cpId = "MWTV"
//        playerContentDetail.contentType = ContentType.LIVE
//
////        playerContentDetail.id = "EROSNOW_MOVIE_6830600"
////        playerContentDetail.cpId = "EROSNOW"
//
////        playerContentDetail.id = "YOUTUBE_OTHER_efxQli1L7T4"
////        playerContentDetail.cpId = "YOUTUBE"
//
////        playerContentDetail.id = "DUMMY"
////        playerContentDetail.playUrl = "http://qthttp.apple.com.edgesuite.net/1010qwoeiuryfg/sl.m3u8"
////        playerContentDetail.contentType = ContentType.URL
//
//        playerContentDetail.lastWatchedPosition = 0
//        playerContentDetail.defaultPlayerDimension = PlayerDimension.DIMENSION_AUTO
//        playerContentDetail.programType = ""
//        return playerContentDetail
//    }


    override fun logEvent(event: Event, eventProperties: HashMap<String, String>) {

        val analyticsHashMap = AnalyticsHashMap()
        analyticsHashMap.putAll(eventProperties)
        Analytics.instance?.trackEvent(event.name, event.isCritical, analyticsHashMap)
    }

    private fun getSubtitleList() : ArrayList<String>? {
        var subtitleList  = playerView.getSubtitleList()
        subtitleList?.add(0,"Disable")
        return subtitleList
    }
}
