package tv.airtel.visionsample.adapter

import com.airbnb.epoxy.TypedEpoxyController
import timber.log.Timber
import tv.airtel.data.model.content.Content
import tv.airtel.visionsample.ItemHomeCardHeaderBindingModel_
import tv.airtel.visionsample.ItemHomeCardPortraitBindingModel_
import tv.airtel.visionsample.ItemHomeCardSeparatorBindingModel_
import tv.airtel.visionsample.util.epoxy.VerticalGridCarouselModel_
import java.lang.RuntimeException

/**
 * Epoxy controller for building and adding models to recyclerView in related content list on detail page.
 */
class RelatedContentAdapter constructor(val itemClickListener: ItemClickListener)
    : TypedEpoxyController<List<Content>>() {
    override fun buildModels(list: List<Content>?) {
        val relatedModels = arrayListOf<ItemHomeCardPortraitBindingModel_>()

        if (list != null && list.isNotEmpty()) {
            ItemHomeCardSeparatorBindingModel_()
                    .id("id_sep")
                    .addTo(this)

            list.mapTo(relatedModels) {
                ItemHomeCardPortraitBindingModel_()
                        .id(it.id!!)
                        .itemClickListener { model, parentView, clickedView, position ->
                            itemClickListener.onContentItemClicked(model.content())
                        }
                        .content(it)
            }
        }

        ItemHomeCardHeaderBindingModel_()
                .id("id1")
                .text("You may also like")
                .addTo(this)

        VerticalGridCarouselModel_()
                .id("id2")
                .models(relatedModels)
                .paddingDp(4)
                .addTo(this)
    }

    interface ItemClickListener {
        fun onContentItemClicked(content: Content)
    }

    override fun onExceptionSwallowed(exception: RuntimeException) {
        // we swallow exceptions related to duplicate IDs for now
        Timber.e(exception.cause)
    }
}