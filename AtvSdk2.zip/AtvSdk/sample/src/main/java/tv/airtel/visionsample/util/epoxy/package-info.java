@EpoxyDataBindingLayouts({
        R.layout.item_home_card_banner, R.layout.item_home_heading,
        R.layout.item_home_card_header, R.layout.item_home_footer, R.layout.item_home_card_portrait,
        R.layout.item_home_search, R.layout.item_home_card_separator, R.layout.item_home_card_landscape,
        R.layout.item_home_card_logo, R.layout.item_episode, R.layout.item_season_header,
        R.layout.item_home_card_continue_watching, R.layout.item_search_card_portrait, R.layout.item_artist_profile})
package tv.airtel.visionsample.util.epoxy;

import com.airbnb.epoxy.EpoxyDataBindingLayouts;

import tv.airtel.visionsample.R;