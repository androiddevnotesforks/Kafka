package tv.airtel.visionsample.di.modules

import dagger.Module
import dagger.android.ContributesAndroidInjector
import tv.airtel.visionsample.activity.LoginActivity
import tv.airtel.visionsample.activity.MainActivity
import tv.airtel.visionsample.activity.SplashActivity

/**
 * Created by VipulKumar on 04/04/18.
 */
@Module
abstract class ActivityModule {
    @ContributesAndroidInjector(modules = [(FragmentBuildersModule::class)])
    internal abstract fun contributeMainActivity(): MainActivity

    @ContributesAndroidInjector(modules = [(FragmentBuildersModule::class)])
    internal abstract fun contributeSplashActivity(): SplashActivity

    @ContributesAndroidInjector(modules = [(FragmentBuildersModule::class)])
    internal abstract fun contributeLoginActivity(): LoginActivity
}
