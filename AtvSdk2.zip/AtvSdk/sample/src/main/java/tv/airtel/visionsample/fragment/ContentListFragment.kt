package tv.airtel.visionsample.fragment

import android.arch.lifecycle.LifecycleOwner
import android.arch.lifecycle.LiveData
import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.airtel.vision.AtvSdk
import tv.airtel.data.api.model.Resource
import tv.airtel.data.di.Injectable
import tv.airtel.data.model.content.BaseRow
import tv.airtel.data.model.content.Content
import tv.airtel.data.model.content.ContentResult
import tv.airtel.data.utilmodule.FeedbackUtil
import tv.airtel.visionsample.R
import tv.airtel.visionsample.activity.MainActivity
import tv.airtel.visionsample.adapter.ContentListAdapter
import tv.airtel.visionsample.databinding.FragmentContentListBinding
import tv.airtel.visionsample.util.AutoClearedValue
import tv.airtel.visionsample.util.RetryCallback
import tv.airtel.visionsample.util.ext.inflateWithDataBinding
import tv.airtel.visionsample.viewmodel.SampleContentViewModel

/**
 * Created by VipulKumar on 2/22/18.
 *
 */
class ContentListFragment : BaseFragment(), Injectable {
    private lateinit var binding: AutoClearedValue<FragmentContentListBinding>
    private lateinit var sampleContentViewModel: SampleContentViewModel
    private lateinit var contentListController: ContentListAdapter
    private var pageId: String? = null
    private var recentlyWatched: BaseRow? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val dataBinding =
                container?.inflateWithDataBinding(R.layout.fragment_content_list)
                as FragmentContentListBinding
        binding = AutoClearedValue(this, dataBinding)
        return dataBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        pageId = arguments?.getString("pageId")
        initUi()
        initViewModels()
        fetchContent()
    }

    private fun initUi() {
        contentListController = ContentListAdapter(object : ContentListAdapter.ItemClickListener {
            override fun onContentItemClicked(content: Content) {
                (activity as MainActivity)
                        .launchContentDetailFragment(content.id, content.programType!!)
            }
        })
        recycler_view.adapter = contentListController.adapter
        binding.get()?.retryCallback = object : RetryCallback {
            override fun retry() {
                sampleContentViewModel.retryContentList()
            }
        }
    }

    private fun initViewModels() {
        sampleContentViewModel = ViewModelProviders.of(this)
                .get(SampleContentViewModel::class.java)
        //  observe the changes on content
        sampleContentViewModel.contentList?.observeK(this) {
            FeedbackUtil.showMessage(context!!, it?.status.toString())
            onContentResponse(it)
        }

        if (pageId == AtvSdk.getInstance().getAppConfig()?.pages!![0].id) {
//            AtvSdk.getInstance().getRecentlyWatched().observe(this, Observer {
////                if (it?.data?.contents != null) {
////                    recentlyWatched = it.data!!
////                }
//            })
        }
    }

    private fun fetchContent() {
        sampleContentViewModel.fetchContentList(pageId!!)
        if (pageId == AtvSdk.getInstance().getAppConfig()?.pages!![0].id) {
            AtvSdk.getInstance().getRecentlyWatched()
        }
    }

    private fun onContentResponse(resource: Resource<ContentResult>?) {
        // Data binding will switch states based on resource.status and provide data to views
        Log.d("Featured Fragment", "Response $pageId ${resource?.status} ${resource?.data}")
        binding.get()?.resource = resource
        if (resource?.data?.baseRows != null) {
            val list = resource.data?.baseRows as MutableList
            if (recentlyWatched != null && !list.map { it.id }.contains(recentlyWatched?.id)) {
                list.add(2, recentlyWatched!!)
            }
            contentListController.setData(list, pageId)
        }
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        if (isVisibleToUser) {
            if (::sampleContentViewModel.isInitialized) {
                fetchContent()
            }
        }
        super.setUserVisibleHint(isVisibleToUser)
    }

    companion object {
        fun newInstance(pageId: String): ContentListFragment {
            val args = Bundle()
            val fragment = ContentListFragment()
            args.putString("pageId", pageId)
            fragment.arguments = args
            return fragment
        }
    }
}

inline fun <T> LiveData<T>.observeK(owner: LifecycleOwner,
                                    crossinline observer: (T?) -> Unit) {
    this.observe(owner, Observer { observer(it) })
}
