package tv.airtel.visionsample.util.widget;

import android.content.Context;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.widget.ProgressBar;

/**
 * Authored by vipulkumar on 16/11/17.
 */

public class WynkProgressBar extends ProgressBar {
    /**
     * Create a new progress bar with range 0...100 and initial progress of 0.
     *
     * @param context the application environment
     */
    public WynkProgressBar(Context context) {
        super(context);
        init(context);
    }

    public WynkProgressBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public WynkProgressBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public WynkProgressBar(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    private void init(Context context) {
    }
}
