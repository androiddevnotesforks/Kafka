package tv.airtel.visionsample.viewmodel

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.Transformations
import com.airtel.vision.AtvSdk
import tv.airtel.data.api.model.Resource
import tv.airtel.data.livedata.AbsentLiveData
import javax.inject.Inject

/**
 * Created by VipulKumar on 14/06/18.
 */
class SampleUserViewModel @Inject
constructor() : BaseViewModel() {
    private val vision = AtvSdk.getInstance()
    private var airtelOnlyContentMutableLiveData = MutableLiveData<String?>()
    val airtelOnlyResponse: LiveData<Resource<Boolean>>?

    init {
        airtelOnlyResponse = Transformations.switchMap(airtelOnlyContentMutableLiveData) {
            if (it != null) {
                vision.checkForAirtelOnly(it)
            } else {
                // create an empty LiveData to prevent being null
                AbsentLiveData.create<Resource<Boolean>>()
            }
        }
    }

    fun checkForAirtelOnly(contentId: String?) {
        airtelOnlyContentMutableLiveData.value = contentId
    }
}