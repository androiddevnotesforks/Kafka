package tv.airtel.sampleleanback.presenter.list

import android.content.Context
import android.support.v17.leanback.widget.ImageCardView
import android.view.ContextThemeWrapper
import com.bumptech.glide.Glide
import tv.airtel.data.model.content.detail.Episode
import tv.airtel.sampleleanback.R

/**
 *
 * Created by Satya on 08/06/18.
 */
class EpisodeCardViewPresenter @JvmOverloads
constructor(context: Context, cardThemeResId: Int = R.style.LandscapeEpisodeCard, private val image: String?)
    : AbstractEpisodeCardPresenter<ImageCardView>(ContextThemeWrapper(context, cardThemeResId)) {

    override fun onCreateView(): ImageCardView {
        return ImageCardView(ContextThemeWrapper(context, R.style.LandscapeEpisodeCardTheme))
    }

    override fun onBindViewHolder(card: Episode, cardView: ImageCardView) {
        cardView.tag = card
        cardView.titleText = card.name
        cardView.contentText = "Episode"+card.episodeNumber

        Glide.with(context)
                .asBitmap()
                .load(image)
                .into(cardView.mainImageView)
    }
}