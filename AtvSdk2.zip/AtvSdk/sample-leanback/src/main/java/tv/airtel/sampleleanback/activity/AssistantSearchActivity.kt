/*
 * Copyright (c) 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package tv.airtel.sampleleanback.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.support.v4.content.IntentCompat.EXTRA_START_PLAYBACK

/**
 * Created by Satya on 15/05/18.
 * Handles the intent from a global search.
 *
 */
class AssistantSearchActivity : Activity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "Search data " + intent.data!!)

        if (intent != null && intent.data != null) {
            val uri = intent.data
            val id = uri!!.lastPathSegment

            val startPlayback = intent.getBooleanExtra(EXTRA_START_PLAYBACK, false)

            var startIntent = Intent(this, SplashActivity::class.java)
            startIntent.putExtra(KEY_CONTENT_ID, id)
            startIntent.putExtra(KEY_PROGRAM_TYPE, intent.action)
            startIntent.putExtra(KEY_IS_START_PLAYBACK, startPlayback)
            startIntent.putExtra(FROM, FROM_SEARCHABLE_ACTIVITY)
            startActivity(startIntent)

        }
        finish()
    }

    companion object {

        private val TAG = "AssistantSearchActivity"
        const val KEY_CONTENT_ID = "key_content_id"
        const val KEY_IS_START_PLAYBACK = "key_is_start_playback"
        const val KEY_PROGRAM_TYPE = "key_program_type"
        const val FROM = "form"
        const val FROM_SEARCHABLE_ACTIVITY = 1001
    }
}
