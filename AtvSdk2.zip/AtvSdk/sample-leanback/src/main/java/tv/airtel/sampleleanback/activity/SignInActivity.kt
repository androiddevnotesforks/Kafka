package tv.airtel.sampleleanback.activity

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v7.app.AppCompatActivity

import tv.airtel.sampleleanback.R
import tv.airtel.sampleleanback.fragment.SignInFragment

class SignInActivity : FragmentActivity() {
    private var mFragment: Fragment? = null
    private var number: String? = null

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.signin_layout)
        mFragment = SignInFragment.newInstance()
        if (intent.extras != null) {
            mFragment?.arguments = intent.extras
        }
        addFragment()
    }

    private fun addFragment() {
        supportFragmentManager.beginTransaction().replace(R.id.signin_container, mFragment)
                .commit()
    }


}
