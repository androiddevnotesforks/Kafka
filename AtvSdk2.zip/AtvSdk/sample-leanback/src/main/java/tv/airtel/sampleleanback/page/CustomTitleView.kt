package tv.airtel.sampleleanback.page

import android.content.Context
import android.graphics.drawable.Drawable
import android.support.v17.leanback.widget.TitleViewAdapter
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.TextView
import kotlinx.android.synthetic.main.view_title_content.view.*
import tv.airtel.sampleleanback.R
import tv.airtel.sampleleanback.util.tabs.SmartTabLayout

/**
 * Custom title view to be used in [android.support.v17.leanback.app.BrowseFragment].
 */
class CustomTitleView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyle: Int = 0) : RelativeLayout(context, attrs, defStyle), TitleViewAdapter.Provider {
    private var mSearchOrbView: View? = null
    private var viewPager: ViewPager? = null
    private var smartTabLayout: SmartTabLayout? = null
    private var titleTextView: TextView? = null
    private var subTitleTextView: TextView? = null

    private val mTitleViewAdapter = object : TitleViewAdapter() {
        override fun getSearchAffordanceView(): View? {

            return mSearchOrbView

        }

        override fun setTitle(titleText: CharSequence?) {
            titleTextView?.text = titleText
        }

        override fun setBadgeDrawable(drawable: Drawable?) {
            //CustomTitleView.this.setBadgeDrawable(drawable);
        }

        override fun setOnSearchClickedListener(listener: View.OnClickListener) {
            mSearchOrbView?.setOnClickListener(listener)
        }

        override fun updateComponentsVisibility(flags: Int) {
            val visibility = if (flags and TitleViewAdapter.SEARCH_VIEW_VISIBLE == TitleViewAdapter.SEARCH_VIEW_VISIBLE)
                View.VISIBLE
            else
                View.INVISIBLE
            mSearchOrbView?.visibility = visibility
        }
    }

    init {
        val root = LayoutInflater.from(context).inflate(R.layout.view_title_content, this)
        mSearchOrbView = root.findViewById(R.id.search_orb)
        smartTabLayout = root.findViewById(R.id.smart_tab_layout)
        viewPager = root.findViewById(R.id.view_pager)
        titleTextView = root.findViewById(R.id.title_textView)
        subTitleTextView = root.findViewById(R.id.subTitle_textView)
        setTitleVisibility(false)
        setSubTitleVisibility(false)
        setTabVisibility(true)

        setupTabs()
    }


    private fun setupTabs() {
        viewPager?.adapter = HomePagerAdapter()
        smartTabLayout?.setViewPager(viewPager)
        tabs.setupWithViewPager(viewPager)

        tabs.requestFocus()
    }

    override fun getTitleViewAdapter(): TitleViewAdapter {
        return mTitleViewAdapter
    }

    fun getViewPager(): ViewPager? {
        return viewPager
    }

    fun setTabVisibility(isVisible: Boolean) {
        smartTabLayout?.visibility = if (isVisible) {
            View.VISIBLE
        } else {
            View.GONE
        }
    }


    fun setTitleVisibility(isVisible: Boolean) {
        titleTextView?.visibility = if (isVisible) {
            View.VISIBLE
        } else {
            View.GONE
        }
    }


    fun setSubTitleVisibility(isVisible: Boolean) {
        subTitleTextView?.visibility = if (isVisible) {
            View.VISIBLE
        } else {
            View.GONE
        }
    }

    fun setSubTitleText(subTitle: CharSequence?){
        subTitleTextView?.text = subTitle
    }

    class HomePagerAdapter : PagerAdapter() {
        private val titles = arrayListOf("Featured", "Movies", "TV Shows")

        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            return View.inflate(container.context!!, R.layout.view_dummy, container)
        }

        override fun isViewFromObject(view: View, `object`: Any): Boolean {
            return view == `object`
        }

        override fun getPageTitle(position: Int): CharSequence? {
            return titles[position]
        }

        override fun getCount(): Int {
            return 3
        }

        override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
            (container as ViewPager).removeView(`object` as View)
        }
    }
}
