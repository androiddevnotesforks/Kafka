package tv.airtel.sampleleanback.fragment

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.v17.leanback.app.VerticalGridSupportFragment
import android.support.v17.leanback.widget.*
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.model.content.Content
import tv.airtel.data.model.search.SearchResponse
import tv.airtel.sampleleanback.activity.DetailActivity
import tv.airtel.sampleleanback.activity.SearchActivity
import tv.airtel.sampleleanback.presenter.search.SearchContentCardPresenterSelector
import tv.airtel.sampleleanback.viewmodel.ContentViewModel

/*
 * ContentMoreFragment shows a grid of videos that can be scrolled vertically.
 */
class ContentMoreFragment : VerticalGridSupportFragment() {
    private var listItemAdapter: ArrayObjectAdapter? = null
    private var contentViewModel: ContentViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Search"
        if (savedInstanceState == null) {
            prepareEntranceTransition()
        }
        setupFragment()
    }

    private fun setupFragment() {
        val gridPresenter = VerticalGridPresenter()
        gridPresenter.numberOfColumns = NUM_COLUMNS
        setGridPresenter(gridPresenter)
        val cardPresenterSelector = SearchContentCardPresenterSelector(activity!!)
        listItemAdapter = ArrayObjectAdapter(cardPresenterSelector)
        adapter = listItemAdapter
        contentViewModel = ViewModelProviders.of(this).get(ContentViewModel::class.java)
        contentViewModel!!.searchResults!!.observe(this, Observer {
            onSearchResponse(it)
        })

        contentViewModel?.searchContent("the")

        // After 500ms, start the animation to transition the cards into view.
        Handler().postDelayed({ startEntranceTransition() }, 500)

        setOnSearchClickedListener {
            val intent = Intent(activity, SearchActivity::class.java)
            startActivity(intent)
        }

        onItemViewClickedListener = ItemViewClickedListener()
    }

    private inner class ItemViewClickedListener : OnItemViewClickedListener {
        override fun onItemClicked(itemViewHolder: Presenter.ViewHolder, item: Any,
                                   rowViewHolder: RowPresenter.ViewHolder, row: Row) {
            if (item is Content) {
                val intent = Intent(activity?.baseContext,
                        DetailActivity::class.java)
                intent.putExtra("contentId", item.id)
                startActivity(intent)
            }

        }
    }


    private fun onSearchResponse(it: Resource<SearchResponse>?) {
        if (it?.status == Status.SUCCESS) {
            listItemAdapter?.clear()
            listItemAdapter?.addAll(0, it.data?.searchContentEntity?.results)
            var i = 0
            if (it.data?.searchContentEntity?.results?.size != null) {
                i = it.data?.searchContentEntity?.results?.size!!
            }
            listItemAdapter?.notifyArrayItemRangeChanged(0, i)

        }
    }

    companion object {
        private val PACKAGE_NAME = "package_name"
        private val NUM_COLUMNS = 5
        private val ALL_VIDEOS_LOADER = 1
        fun newInstance(): ContentMoreFragment {
            return ContentMoreFragment()
        }
    }


}
