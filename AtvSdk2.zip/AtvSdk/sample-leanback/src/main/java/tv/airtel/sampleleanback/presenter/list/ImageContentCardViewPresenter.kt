package tv.airtel.sampleleanback.presenter.list

import android.content.Context
import android.support.v17.leanback.widget.ImageCardView
import android.view.ContextThemeWrapper
import com.bumptech.glide.Glide
import tv.airtel.data.model.content.Content
import tv.airtel.sampleleanback.R

/**
 * A very basic [ImageCardView] [android.support.v17.leanback.widget.Presenter].You can
 * pass a custom style for the ImageCardView in the constructor. Use the default constructor to
 * create a Presenter with a default ImageCardView style.
 */
class ImageContentCardViewPresenter @JvmOverloads
constructor(context: Context, cardThemeResId: Int = R.style.PortraitContentCard)
    : AbstractContentCardPresenter<ImageCardView>(ContextThemeWrapper(context, cardThemeResId)) {

    override fun onCreateView(): ImageCardView {
        return ImageCardView(ContextThemeWrapper(context, R.style.PortraitContentCardTheme))
    }

    override fun onBindViewHolder(card: Content, cardView: ImageCardView) {
        cardView.tag = card
        cardView.titleText = card.title
        cardView.contentText = card.description

        Glide.with(context)
                .asBitmap()
                .load(card.images!!.getPortraitImage())
                .into(cardView.mainImageView)
    }
}
