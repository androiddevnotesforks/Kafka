package tv.airtel.sampleleanback.fragment

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.support.v17.leanback.app.DetailsSupportFragment
import android.support.v17.leanback.app.DetailsSupportFragmentBackgroundController
import android.support.v17.leanback.widget.*
import android.support.v17.leanback.widget.ListRow
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.model.content.ContentDetail
import tv.airtel.data.model.content.detail.SeasonDetail
import tv.airtel.data.model.content.related.RelatedContent
import tv.airtel.data.model.layout.BackendType
import tv.airtel.data.model.player.DetailViewModel
import tv.airtel.sampleleanback.R
//import tv.airtel.sampleleanback.activity.PlayerActivity
import tv.airtel.sampleleanback.activity.SeasonListActivity
import tv.airtel.sampleleanback.presenter.detail.CreditCardPresenterSelector
import tv.airtel.sampleleanback.presenter.detail.DetailsDescriptionPresenter
import tv.airtel.sampleleanback.presenter.list.CardPresenterSelector
import tv.airtel.sampleleanback.viewmodel.ContentViewModel


class ContentDetailFragment : DetailsSupportFragment(), OnItemViewClickedListener {
    private val ACTION_PLAY: Long = 1
    private val ACTION_WISHLIST: Long = 2
    private val ACTION_RELATED: Long = 3
    private val ACTION_WATCH_SEASON: Long = 4
    private var detailFetched = false
    private var contentId: String = ""
    private var contentType: String = ""

    private var contentViewModel: ContentViewModel? = null
    private val mDetailsBackground = DetailsSupportFragmentBackgroundController(this)
    private var contentDetails: ContentDetail? = null

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        contentId = arguments?.getString(KEY_CONTENT_ID) ?: ""
        contentType = arguments?.getString(KEY_CONTENT_TYPE) ?: ""

        initViewModels()
        setupUi()
    }

    private fun initViewModels() {
        contentViewModel = ViewModelProviders.of(this).get(ContentViewModel::class.java)

        contentViewModel?.contentDetail?.observe(this, Observer {
            onContentResponse(it)
        })

        contentViewModel?.contentRelatedList?.observe(this, Observer {
            onContentRelatedResponse(it)
        })

        contentViewModel?.contentSeasonDetail?.observe(this, Observer {
            onSeasonDetailResponse(it)
        })
        fetchContentDetail()
    }

    private fun fetchContentDetail() {
        when (contentType) {
            "TVSHOW", "LIVETVSHOW" -> contentViewModel?.fetchSeasonDetail(contentId)
            else -> contentViewModel?.fetchContentDetail(contentId)
        }
    }

    private fun onSeasonDetailResponse(it: Resource<SeasonDetail>?) {
        if (it?.data != null && it.status == Status.SUCCESS) {
            if (!detailFetched) {
                detailFetched = true
                setData(it.data!!)
                contentViewModel?.fetchRelatedContent(contentId)
            }
        }
    }

    private fun onContentRelatedResponse(it: Resource<RelatedContent>?) {
        if (it?.data != null && it.status == Status.SUCCESS) {
            // Setup recommended row.
            val listRowAdapter = ArrayObjectAdapter(CardPresenterSelector(context!!))
            for (card in it.data?.relatedContentDetailsEntity?.results
                    ?: arrayListOf()) listRowAdapter.add(card)
            val header = HeaderItem(1, getString(R.string.header_recommended))
            mRowsAdapter?.add(ListRow(header, listRowAdapter))
        }
    }

    private fun onContentResponse(it: Resource<ContentDetail>?) {
        if (it?.data != null && it.status == Status.SUCCESS) {
            if (!detailFetched) {
                detailFetched = true
                setData(it.data!!)
                contentViewModel?.fetchRelatedContent(contentId)
            }
        }
    }

    private var mRowsAdapter: ArrayObjectAdapter? = null

    private fun setupUi() {
        titleView?.visibility = View.GONE

        val rowPresenter = object : FullWidthDetailsOverviewRowPresenter(
                DetailsDescriptionPresenter(context!!)) {

            override fun createRowViewHolder(parent: ViewGroup): RowPresenter.ViewHolder {
                // Customize Actionbar and Content by using custom colors.
                val viewHolder = super.createRowViewHolder(parent)

                val actionsView = viewHolder.view.findViewById<View>(R.id.details_overview_actions_background)
                actionsView.setBackgroundColor(resources.getColor(R.color.color_dark_200))

                val detailsView = viewHolder.view.findViewById<View>(R.id.details_frame)
                detailsView.setBackgroundColor(resources.getColor(R.color.color_dark))
                return viewHolder
            }
        }

        val mHelper = FullWidthDetailsOverviewSharedElementHelper()
        mHelper.setSharedElementEnterTransition(activity, TRANSITION_NAME, 5000)
        prepareEntranceTransition()
        rowPresenter.setListener(mHelper)
        rowPresenter.isParticipatingEntranceTransition = true

        rowPresenter.onActionClickedListener = OnActionClickedListener { action ->
            if (action.id == ACTION_PLAY) {
//                val intent = Intent(context!!, PlayerActivity::class.java)
//                intent.putExtra("Player", contentDetails)
//                startActivity(intent)
            } else if (action.id == ACTION_WATCH_SEASON) {
                val intent = Intent(context!!, SeasonListActivity::class.java)
                intent.putExtra("contentDetail", contentDetails)
                startActivity(intent)
            }
        }


        val shadowDisabledRowPresenter = ListRowPresenter()
        shadowDisabledRowPresenter.shadowEnabled = false

        // Setup PresenterSelector to distinguish between the different rows.
        val rowPresenterSelector = ClassPresenterSelector()
        rowPresenterSelector.addClassPresenter(DetailsOverviewRow::class.java, rowPresenter)
//        rowPresenterSelector.addClassPresenter(CardListRow::class.java, shadowDisabledRowPresenter)
        rowPresenterSelector.addClassPresenter(ListRow::class.java, ListRowPresenter())
        mRowsAdapter = ArrayObjectAdapter(rowPresenterSelector)

        adapter = mRowsAdapter

        Handler().postDelayed({
            startEntranceTransition()
        }, 500)
    }


    private fun setData(detail: ContentDetail) {
        contentDetails = detail
        val detailsOverview = DetailsOverviewRow(detail)

        Glide.with(context!!)
                .asBitmap().listener(object : RequestListener<Bitmap> {
                    override fun onLoadFailed(e: GlideException?, model: Any?, target: Target<Bitmap>?,
                                              isFirstResource: Boolean): Boolean {
                        return true
                    }

                    override fun onResourceReady(resource: Bitmap?, model: Any?, target: Target<Bitmap>?,
                                                 dataSource: DataSource?, isFirstResource: Boolean): Boolean {
                        detailsOverview.setImageBitmap(context!!, resource)
                        return true
                    }

                }).load(detail.images?.getPortraitImage()).apply(RequestOptions().placeholder(R.drawable.img_bg_1)).submit()

        detailsOverview.isImageScaleUpAllowed = true
        val actionAdapter = ArrayObjectAdapter()
        var mActionBuy = Action(ACTION_PLAY, "Play")
        if (contentType.equals("TVSHOW") || contentType.equals("LIVETVSHOW")) {
            mActionBuy = Action(ACTION_WATCH_SEASON, "Watch Seasons")
        }
        val mActionWishList = Action(ACTION_WISHLIST, getString(R.string.action_wishlist))
        val mActionRelated = Action(ACTION_RELATED, getString(R.string.action_related))

        actionAdapter.add(mActionBuy)
        actionAdapter.add(mActionWishList)
        actionAdapter.add(mActionRelated)
        detailsOverview.actionsAdapter = actionAdapter
        mRowsAdapter?.add(detailsOverview)

        // Setup related row.
        val listRowAdapter = ArrayObjectAdapter(
                CreditCardPresenterSelector(context!!))
        for (characterCard in detail.credits ?: arrayListOf()) listRowAdapter.add(characterCard)
        if (listRowAdapter.size() > 0) {
            val header = HeaderItem(0, getString(R.string.header_related))
            mRowsAdapter?.add(ListRow(header, listRowAdapter))
        }

        initializeBackground(detail)
    }

    override fun onItemClicked(itemViewHolder: Presenter.ViewHolder, item: Any,
                               rowViewHolder: RowPresenter.ViewHolder, row: Row) {
        if (item !is Action) return

        if (item.id == ACTION_PLAY) {
            setSelectedPosition(1) // play

        }
//        val intent = Intent(c
// ontext!!, PlayerActivity::class.java)
//        intent.putExtra("Player", contentViewModel?.contentDetail?.value?.data)
//        startActivity(intent)

    }

    fun transformToDetailViewModel(contentDetail: ContentDetail): DetailViewModel {
        val detailViewModel = DetailViewModel()
        detailViewModel.id = contentDetail.id
        detailViewModel.images = contentDetail.images
        detailViewModel.title = contentDetail.title
        detailViewModel.description = contentDetail.description
        detailViewModel.cpId = contentDetail.cpId
        detailViewModel.contentType = contentDetail.programType
        detailViewModel.releaseYear = contentDetail.releaseYear
        detailViewModel.backendType = BackendType.BE
        return detailViewModel
    }

    private fun initializeBackground(data: ContentDetail) {
        mDetailsBackground.enableParallax()
        mDetailsBackground.coverBitmap = BitmapFactory.decodeResource(resources, R.drawable.img_bg_1)
        Glide.with(context!!)
                .asBitmap().listener(object : RequestListener<Bitmap> {
                    override fun onLoadFailed(e: GlideException?, model: Any?, target: Target<Bitmap>?,
                                              isFirstResource: Boolean): Boolean {
                        return true
                    }

                    override fun onResourceReady(resource: Bitmap?, model: Any?, target: Target<Bitmap>?,
                                                 dataSource: DataSource?, isFirstResource: Boolean): Boolean {
                        mDetailsBackground.coverBitmap = resource
                        return true
                    }

                }).load(data.images?.getLandscapeImage()).submit()
    }

    companion object {
        val TRANSITION_NAME = "t_for_transition"

        const val KEY_CONTENT_ID = "contentId"
        const val KEY_CONTENT_TYPE = "contentType"
        fun newInstance(contentId: String?, contentType: String?): ContentDetailFragment {
            val fragment = ContentDetailFragment()
            val args = Bundle()
            args.putString(KEY_CONTENT_ID, contentId)
            args.putString(KEY_CONTENT_TYPE, contentType)
            fragment.arguments = args
            return fragment
        }
    }
}
