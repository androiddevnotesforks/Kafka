package tv.airtel.sampleleanback.presenter.detail

import android.content.Context
import android.support.v17.leanback.widget.ImageCardView
import android.view.ContextThemeWrapper
import tv.airtel.data.model.content.Credit
import tv.airtel.sampleleanback.R

/**
 * A very basic [ImageCardView] [android.support.v17.leanback.widget.Presenter].You can
 * pass a custom style for the ImageCardView in the constructor. Use the default constructor to
 * create a Presenter with a default ImageCardView style.
 */
class ImageCreditCardViewPresenter @JvmOverloads
constructor(context: Context, cardThemeResId: Int = R.style.PortraitCreditCard)
    : AbstractCreditCardPresenter<ImageCardView>(ContextThemeWrapper(context, cardThemeResId)) {

    override fun onCreateView(): ImageCardView {
        return ImageCardView(ContextThemeWrapper(context, R.style.PortraitCreditCardTheme))
    }

    override fun onBindViewHolder(card: Credit, cardView: ImageCardView) {
        cardView.tag = card
        cardView.titleText = card.displayTitle
        cardView.contentText = card.roleType
        cardView.mainImageView.setImageResource(R.drawable.ic_person_black_24dp)
//        Glide.with(context)
//                .asBitmap()
//                .load(R.drawable.ic_person_black_24dp)
//                .into(cardView.mainImageView)
    }
}
