package tv.airtel.sampleleanback.activity

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.FragmentActivity
import com.airtel.vision.AtvSdk
import tv.airtel.sampleleanback.R
import tv.airtel.sampleleanback.fragment.ContentDetailFragment
import tv.airtel.sampleleanback.fragment.ContentListFragment
import tv.airtel.sampleleanback.util.inTransaction

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (intent.hasExtra(SplashActivity.KEY_SEARCHABLE_BUNDLE)) {
            val mainIntent = Intent(this,
                    DetailActivity::class.java)
            mainIntent.putExtra(ContentDetailFragment.KEY_CONTENT_ID, (intent.extras[SplashActivity.KEY_SEARCHABLE_BUNDLE] as Bundle)[AssistantSearchActivity.KEY_CONTENT_ID] as String)
            mainIntent.putExtra(ContentDetailFragment.KEY_CONTENT_TYPE, (intent.extras[SplashActivity.KEY_SEARCHABLE_BUNDLE] as Bundle)[AssistantSearchActivity.KEY_PROGRAM_TYPE] as String)
            startActivity(mainIntent)
        }
        supportFragmentManager?.inTransaction {
            replace(R.id.fragment_container, ContentListFragment.newInstance())
        }
    }

    override fun onResume() {
        super.onResume()
    }
}
