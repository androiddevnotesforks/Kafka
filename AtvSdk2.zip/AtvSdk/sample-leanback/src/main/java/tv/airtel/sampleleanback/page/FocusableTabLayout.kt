package tv.airtel.sampleleanback.page

import android.content.Context
import android.graphics.Rect
import android.support.design.widget.TabLayout
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout

class FocusableTabLayout(context: Context, attributeSet: AttributeSet): TabLayout(context, attributeSet) {
    override fun focusSearch(focused: View?, direction: Int): View? {
        val view = super.focusSearch(focused, direction)
        if (hasFocus() && view != null) {
            if (direction == View.FOCUS_LEFT) {
                if (selectedTabPosition > 0) {
                    getTabAt(selectedTabPosition - 1)?.select()
                }
            } else if (direction == View.FOCUS_RIGHT) {
                if (selectedTabPosition < tabCount) {
                    getTabAt(selectedTabPosition + 1)?.select()
                }
            }
        }
        return view
    }

    override fun requestFocus(direction: Int, previouslyFocusedRect: Rect?): Boolean {
        val tabStrip = getChildAt(0) as LinearLayout
        tabStrip.getChildAt(selectedTabPosition).requestFocus()
        return true
    }
}