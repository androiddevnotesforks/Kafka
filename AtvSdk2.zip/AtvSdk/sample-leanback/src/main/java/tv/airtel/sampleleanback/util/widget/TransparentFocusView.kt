package tv.airtel.sampleleanback.util.widget

import android.content.Context
import android.graphics.Color
import android.support.v7.widget.CardView
import android.util.AttributeSet
import tv.airtel.sampleleanback.util.dp
import tv.airtel.sampleleanback.util.scaleDown
import tv.airtel.sampleleanback.util.scaleUp

/**
 * Created by Akash on 18/05/18.
 */
class TransparentFocusView @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0)
    : CardView(context, attrs, defStyleAttr) {
    init {
        initViews()
    }

    private fun initViews() {
        preventCornerOverlap = false
        setBackgroundColor(Color.parseColor("#66000000"))
        setOnFocusChangeListener { _, hasFocus ->
            radius = if (hasFocus) {
//                elevate(2, 8)
                scaleUp()
//                background = ContextCompat.getDrawable(context, R.drawable.bg_blur_fill_stroked)
                setBackgroundColor(Color.parseColor("#66000000"))
                dp(6)
            } else {
//                elevate(8, 2)
                scaleDown()
                setBackgroundColor(Color.parseColor("#66000000"))
                dp(6)
            }
        }
    }
}
