package tv.airtel.sampleleanback.presenter.detail

import android.content.Context
import android.support.v17.leanback.widget.Presenter
import android.support.v17.leanback.widget.PresenterSelector

import tv.airtel.sampleleanback.R

/**
 * This PresenterSelector will decide what Presenter to use depending on a given card's type.
 */
class CreditCardPresenterSelector(private val mContext: Context) : PresenterSelector() {

    private var presenter: ImageCreditCardViewPresenter? = null

    override fun getPresenter(item: Any): Presenter {
        val themeResId = R.style.MovieCardBadgeStyle
        if (presenter == null) {
            presenter = ImageCreditCardViewPresenter(mContext, themeResId)
        }
        return  presenter!!
    }
}
