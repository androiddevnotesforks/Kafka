package tv.airtel.sampleleanback.fragment

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.support.media.tv.TvContractCompat
import android.support.v17.leanback.app.BackgroundManager
import android.support.v17.leanback.app.BrowseSupportFragment
import android.support.v17.leanback.widget.*
import android.support.v17.leanback.widget.BrowseFrameLayout
import android.support.v4.app.ActivityOptionsCompat
import android.support.v4.content.ContextCompat
import android.support.v4.view.ViewPager
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.ViewGroup
import com.airtel.vision.AtvSdk
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import timber.log.Timber
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.model.content.BaseRow
import tv.airtel.data.model.content.Content
import tv.airtel.data.model.content.ContentResult
import tv.airtel.data.util.isNotNullOrEmpty
import tv.airtel.sampleleanback.R
import tv.airtel.sampleleanback.activity.DetailActivity
import tv.airtel.sampleleanback.activity.SearchActivity
import tv.airtel.sampleleanback.page.CustomTitleView
import tv.airtel.sampleleanback.presenter.list.CardPresenterSelector
import tv.airtel.sampleleanback.util.FeedbackUtil
import tv.airtel.sampleleanback.util.TvRecommadationUtil
import tv.airtel.sampleleanback.viewmodel.ContentViewModel

class ContentListFragment : BrowseSupportFragment(), BrowseErrorFragment.ErrorFragmentInteraction {

    private val BACKGROUND_UPDATE_DELAY = 300
    private var contentViewModel: ContentViewModel? = null
    private var mRowsAdapter: ArrayObjectAdapter? = null
    private val pageRowFragmentFactory = PageRowFragmentFactory()

    private var channelId: Long? = null

    private val mHandler = Handler()
    private var mMetrics: DisplayMetrics? = null
    private var mBackgroundURI: String? = null
    private var mBackgroundManager: BackgroundManager? = null
    private var mBackgroundUpdateRunnable: Runnable? = null

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        setupUi()
        initViewModels()
        setupRowAdapter()
        setupEventListeners()

        prepareBackgroundManager()
        mBackgroundUpdateRunnable = Runnable {
            if (mBackgroundURI != null) {
                updateBackgroundImage(mBackgroundURI.toString())
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            prepareEntranceTransition()
        }

        mainFragmentRegistry.registerFragment(PageRow::class.java,
                pageRowFragmentFactory)
    }

    private fun setupRowAdapter() {
        mRowsAdapter = ArrayObjectAdapter(ListRowPresenter())
    }

    private fun initViewModels() {
        contentViewModel = ViewModelProviders.of(this).get(ContentViewModel::class.java)

        contentViewModel?.contentList?.observe(this, Observer {
            onContentResponse(it)
        })

        contentViewModel?.fetchContentList(AtvSdk.getInstance().getAppConfig()?.pages!![0].id)
    }

    private fun onContentResponse(it: Resource<ContentResult>?) {

        Log.i(TAG, "content response result is " + it?.status + " data size " + it?.data?.baseRows?.size)
        if (it?.data?.baseRows.isNotNullOrEmpty()) {
            progressBarManager.hide()
            createRows(it?.data?.baseRows!!)
            //TODO remove this when recommendation logic is finalized
            if (createChannel()) {
                for (baseRow in it.data?.baseRows!!) {
                    if (baseRow.contents?.content != null) {
                        addPrograms(baseRow)
                        break
                    }
                }
            }
        }

        if (it?.status == Status.ERROR) {
            progressBarManager.hide()
            FeedbackUtil.showMessage(context!!, it.error?.errorUserMessage ?: "")
            Log.i(TAG, "error data is " + it.data)
            if (it.data == null) {
                loadErrorFragment()
            }
        }
    }

    private fun loadErrorFragment() {
        activity?.supportFragmentManager?.beginTransaction()
                ?.add(R.id.fragment_container, BrowseErrorFragment.newInstance(this))
                ?.commit()
    }

    private fun createRows(data: List<BaseRow>) {

        mRowsAdapter?.clear()
        data.forEach {
            if (it.contents?.content?.isNotNullOrEmpty() == true) {
                mRowsAdapter?.add(createCardRow(it))
            }
        }
        adapter = mRowsAdapter
        startEntranceTransition()
    }

    private fun createCardRow(baseRow: BaseRow): ListRow {
        val presenterSelector = CardPresenterSelector(context!!)
        val listRowAdapter = ArrayObjectAdapter(presenterSelector)
        baseRow.contents?.content?.forEach {
            listRowAdapter.add(it)
        }
        return ListRow(HeaderItem(baseRow.title), listRowAdapter)
    }

    private fun setupUi() {
        title = getString(R.string.browse_title)
        headersState = BrowseSupportFragment.HEADERS_ENABLED
        isHeadersTransitionOnBackEnabled = false
        brandColor = ContextCompat.getColor(context!!, R.color.colorAccent)
        titleView?.visibility = View.VISIBLE

        setOnSearchClickedListener {
            startActivity(Intent(context, SearchActivity::class.java))
        }
        trackSelectedPage()

        setupTabFocus()
    }

    private fun setupTabFocus() {
        initFocusManagement()
    }

    private val maxHookIntoFocusTries = 5
    private var hookIntoFocusTries = 0

    private fun initFocusManagement() {
        val view = view
        val handler = Handler()
        if (view == null) {
            //Wait for the view to be added
            val runnable = Runnable { initFocusManagement() }
            handler.postDelayed(runnable, 250)
        }
        if (view is ViewGroup) {
            val found = hookIntoFocusSearch(view)
            if (found) {
                Timber.d("Successfully fixed focus")   //This is just a log
            } else if (hookIntoFocusTries < maxHookIntoFocusTries) {
                //Allow multiple attempts to hook into the focus system
                //I want to say this was needed for when the browse fragment was
                //created but the child content hadn't been populated yet.
                //Been a while since I've messed with this code though
                hookIntoFocusTries++
                handler.postDelayed({ initFocusManagement() }, 250)
            }
        }
    }

    private fun hookIntoFocusSearch(vg: ViewGroup): Boolean {
        var found = false
        for (i in 0 until vg.childCount) {
            val view = vg.getChildAt(i)
            if (view is BrowseFrameLayout) {
                view.onFocusSearchListener = BrowseFrameLayout.OnFocusSearchListener { focused, direction ->
                    if (direction == View.FOCUS_UP) {
                        titleView
                    } else {
                        null
                    }
                }
                found = true
                break
            } else if (view is ViewGroup) {
                val foundInRecurse = hookIntoFocusSearch(view)
                if (foundInRecurse) {
                    found = true
                    break
                }
            }
        }
        return found
    }

    private fun trackSelectedPage() {
        (titleView as CustomTitleView).getViewPager()
                ?.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
                    override fun onPageScrollStateChanged(state: Int) {

                    }

                    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                    }

                    override fun onPageSelected(position: Int) {
                        this@ContentListFragment.onPageSelected(position)
                    }

                })
    }

    private fun onPageSelected(position: Int) {
        mRowsAdapter?.clear()
        progressBarManager.show()
        when (position) {
            0 -> contentViewModel?.fetchContentList(AtvSdk.getInstance().getAppConfig()?.pages!![0].id)
            1 -> contentViewModel?.fetchContentList(AtvSdk.getInstance().getAppConfig()?.pages!![1].id)
            2 -> contentViewModel?.fetchContentList(AtvSdk.getInstance().getAppConfig()?.pages!![2].id)
        }
    }

    private fun createChannel(): Boolean {
        val totalChannels = TvRecommadationUtil.getNumberOfChannels(context!!)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            channelId = TvRecommadationUtil.createChannel(context!!, BaseRow())
            if (totalChannels < 1) {
                TvContractCompat.requestChannelBrowsable(context, channelId!!)
                return true
            }
        } else {
            TvRecommadationUtil.recommedationBuilder(context!!)
        }
        return false
    }

    private fun addPrograms(baseRow: BaseRow) {

        TvRecommadationUtil.addPrograms(context!!, channelId!!, baseRow)
        TvRecommadationUtil.addToWatchNext(context!!, baseRow)
    }

    private fun setupEventListeners() {
        onItemViewClickedListener = ItemViewClickedListener()
        onItemViewSelectedListener = ItemViewSelectedListener()
    }

    private inner class ItemViewClickedListener : OnItemViewClickedListener {

        override fun onItemClicked(itemViewHolder: Presenter.ViewHolder, item: Any,
                                   rowViewHolder: RowPresenter.ViewHolder, row: Row) {
            if (item is Content) {
                val imageView = (itemViewHolder.view as ImageCardView).mainImageView

                val bundle = ActivityOptionsCompat.makeSceneTransitionAnimation(activity!!,
                        imageView, ContentDetailFragment.TRANSITION_NAME).toBundle()
                val intent = Intent(activity?.baseContext,
                        DetailActivity::class.java)
                intent.putExtra(ContentDetailFragment.KEY_CONTENT_ID, item.id)
                intent.putExtra(ContentDetailFragment.KEY_CONTENT_TYPE, item.programType)
                startActivity(intent, bundle)
            }
        }
    }

    private inner class ItemViewSelectedListener : OnItemViewSelectedListener {

        override fun onItemSelected(itemViewHolder: Presenter.ViewHolder?, item: Any?,
                                    rowViewHolder: RowPresenter.ViewHolder?, row: Row?) {

            if (item is Content) {
                mBackgroundURI = item.images?.getLandscapeImage()
                startBackgroundTimer()
            } else {
                /**
                 * make sure the background of other items are removed so the setting icon can be
                 * seen clearly
                 */
                mHandler.removeCallbacks(mBackgroundUpdateRunnable)
                mBackgroundManager?.drawable = null
            }
        }
    }

    private fun prepareBackgroundManager() {
        mBackgroundManager = BackgroundManager.getInstance(activity)
        mBackgroundManager?.attach(activity?.window)
        mMetrics = DisplayMetrics()
        activity?.windowManager?.defaultDisplay?.getMetrics(mMetrics)
    }

    private fun updateBackgroundImage(uri: String) {
        if (mMetrics != null) {
            val width = mMetrics!!.widthPixels
            val height = mMetrics!!.heightPixels
            Glide.with(context!!)
                    .load(uri)
                    .into(object : SimpleTarget<Drawable>(width, height) {
                        override fun onResourceReady(resource: Drawable,
                                                     glideAnimation: Transition<in Drawable>?) {
                            mBackgroundManager?.drawable = resource
                        }

                        override fun onLoadFailed(errorDrawable: Drawable?) {
                            super.onLoadFailed(errorDrawable)
                        }
                    })
        }
        mHandler.removeCallbacks(mBackgroundUpdateRunnable)
    }

    private fun startBackgroundTimer() {
        mHandler.removeCallbacks(mBackgroundUpdateRunnable)
        mHandler.postDelayed(mBackgroundUpdateRunnable, BACKGROUND_UPDATE_DELAY.toLong())
    }

    private class PageRowFragmentFactory internal constructor() :
            BrowseSupportFragment.FragmentFactory<android.support.v4.app.Fragment>() {
        override fun createFragment(rowObj: Any?): android.support.v4.app.Fragment {
            // val row = rowObj as Row
            // if (row.id == 1L) {
            return ContentListRowsFragment.newInstance()
            // }
            // return ContentListRowsFragment.newInstance()
        }
    }

    override fun retryClicked() {
        val position = (titleView as CustomTitleView).getViewPager()?.currentItem
        onPageSelected(position ?: 0)
    }

    override fun onDestroy() {
        super.onDestroy()
        mHandler.removeCallbacks(mBackgroundUpdateRunnable)
    }

    companion object {
        private const val TAG = "ContentListDebug"
        fun newInstance(): ContentListFragment {
            return ContentListFragment()
        }
    }
}
