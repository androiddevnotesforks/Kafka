package tv.airtel.util.util;

/**
 * Created by Accedo India on 15-03-2016.
 */
public class QualityBitrate {

    private String qualityId;

    private String name;

    private String live_tv_name;
    private String bitRateEROSNOW;
    private String bitRateFASTFILMZ;
    private String bitRateTVPROMO;

    private String bitRateHOOQ;

    private String liveTvBitrate;

    public String getQualityId() {
        return qualityId;
    }

    public String getBitRateEROSNOW() {
        return bitRateEROSNOW;
    }

    public String getBitRateHOOQ() {
        return bitRateHOOQ;
    }

    public String getBitRateDTH() {
        return liveTvBitrate;
    }

    public String getBitRateFASTFILMZ() {
        return bitRateFASTFILMZ;
    }

    public String getName() {
        return name;
    }

    public String getDthName() {
        return live_tv_name;
    }

    public String getBitRateTVPROMO() {
        return bitRateTVPROMO;
    }
}
