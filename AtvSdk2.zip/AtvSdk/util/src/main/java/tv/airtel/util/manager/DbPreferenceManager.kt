package tv.airtel.util.manager

import android.app.Application
import android.content.Context
import tv.airtel.util.util.SingletonHolder
import javax.inject.Inject

/**
 * Created by Harsh Jain on 18/02/19.
 */

class DbPreferenceManager @Inject constructor(context: Application) : SharedPreferenceManager(context) {

    private val dbPreferenceName = "db_pref"

    init {
        pref = context.getSharedPreferences(dbPreferenceName, Context.MODE_PRIVATE)
    }

    companion object : SingletonHolder<DbPreferenceManager, Application>(::DbPreferenceManager) {
        const val TABLE_USER_CONFIG = "table_user_config"
        const val TABLE_LOGIN_ENTITY = "table_login_entity"
    }
}