package tv.airtel.util.manager

import android.app.Application
import android.content.Context
import tv.airtel.util.util.SingletonHolder
import javax.inject.Inject

/**
 * Created by Aditya Mehta on 26/03/18.
 *
 */
class AppPreferenceManager @Inject constructor(context: Application) : SharedPreferenceManager(context) {

    //named default to make it compatible with older versions of airtel tv
    private val appPreferenceName = "app_pref"

    init {
        pref = context.getSharedPreferences(appPreferenceName, Context.MODE_PRIVATE)
    }

    companion object : SingletonHolder<AppPreferenceManager, Application>(::AppPreferenceManager) {
        const val KEY_FIRST_RUN = "first_run"
    }
}