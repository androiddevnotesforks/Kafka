package tv.airtel.util.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.text.TextUtils
import android.widget.ImageView

import com.bumptech.glide.Glide

/**
 * Authored by vipulkumar on 27/09/17.
 */

object ImageLoader {
    fun loadImage(context: Context, url: String, imageView: ImageView) {
        if (!TextUtils.isEmpty(url)) {
            Glide.with(context)
                    .load(url)
                    .into(imageView)
        }
    }
}
