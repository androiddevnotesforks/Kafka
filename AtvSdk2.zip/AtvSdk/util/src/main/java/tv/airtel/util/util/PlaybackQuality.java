package tv.airtel.util.util;

import java.io.Serializable;
import java.util.LinkedHashMap;

/**
 * Created by Accedo India on 09-03-2016.
 */
public class PlaybackQuality implements Serializable {


    private static final long serialVersionUID = 5391401342665475372L;

    private static final int DEFAULT_BITRATE = 0;


    private String qualityId;
    private String qualityName;
    private String dthQualityName;
    private LinkedHashMap<String, String> contentProviderQualityMap;

    private String selectedNameAsPerCp;

    public PlaybackQuality(final String qualityId, final String qualityName, String dthQualityName, final LinkedHashMap<String, String> cpQualityMap){
        this.qualityId = qualityId;
        this.contentProviderQualityMap = cpQualityMap;
        this.qualityName = qualityName;
        this.dthQualityName = dthQualityName;
        this.selectedNameAsPerCp = qualityName;
    }

    public int getBitrate(final String contentProvider){
        if(contentProviderQualityMap != null){
            if (contentProviderQualityMap.containsKey(contentProvider)){
                return Integer.valueOf(contentProviderQualityMap.get(contentProvider));
            }
        }
        return DEFAULT_BITRATE;
    }

    public String getId() {
        return qualityId;
    }

    public String getQualityName(){
        return qualityName;
    }
    public String getDthQualityName(){
        return dthQualityName;
    }

//    @Override
//    public String toString() {
//        return "PLAYBACK QUALITY " + "QUALITY ID : " + qualityId + " QUALITY NAME : " + qualityName + " dthQUALITY NAME : " + dthQualityName + " content provider quality name: " + contentProviderQualityMap!= null? contentProviderQualityMap.toString():"contentProviderQualityMap is null";
//    }

    public String getSelectedNameAsPerCp() {
        return selectedNameAsPerCp;
    }

    public void setSelectedNameAsPerCp(String selectedNameAsPerCp) {
        this.selectedNameAsPerCp = selectedNameAsPerCp;
    }
}
