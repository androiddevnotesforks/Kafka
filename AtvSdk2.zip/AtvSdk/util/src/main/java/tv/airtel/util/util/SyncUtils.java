package tv.airtel.util.util;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.ContentResolver;
import android.content.Context;
import android.os.Bundle;

/**
 * Utility class for managing sync adapter
 */
public class SyncUtils {
    private static final String LOG_TAG = "SYNC_UTILS";
    //TODO: Change Environment
//    private static final String AUTHORITY = Environment.authority;
    private static final String AUTHORITY = "com.tv.test";
//    private static final String ACCOUNT_TYPE = Environment.accountType;
    private static final String ACCOUNT_TYPE = "com.tv.test.airtel";
    private static final String ACCOUNT = "airteltv";
    private Account mAccount;
    private static SyncUtils sInstance;
//    private static final long SYNC_INTERVAL = 5 * 60;
    private static final long SYNC_INTERVAL = 10;

    private SyncUtils() {

    }

    public synchronized static SyncUtils getInstance() {
        if (sInstance == null) {
            sInstance = new SyncUtils();
        }
        return sInstance;
    }

    public void init(Context context) {
        mAccount = getSyncAccount(context);
        if (mAccount != null) {
            ContentResolver.setSyncAutomatically(mAccount, AUTHORITY, true);
            addPeriodicSync();
        }
    }

    private static Account getSyncAccount(Context context) {
        try {
            // Get an instance of the Android account manager
            AccountManager accountManager = AccountManager.get(context);

            Account account = new Account(ACCOUNT, ACCOUNT_TYPE);
            /*
             * Add the account and account type, no password or user data If successful,
             * return the Account object, otherwise report an error.
             */
            if (accountManager.addAccountExplicitly(account, null, null)) {
                ContentResolver.setIsSyncable(account, AUTHORITY, 1);
                ContentResolver.setMasterSyncAutomatically(true);
                ContentResolver.setSyncAutomatically(account, AUTHORITY, true);
            }
            return account;
        } catch (Exception ex) {
            LogUtil.INSTANCE.e(LOG_TAG, "Failed to initialise sync adapter", ex);
        }
        return null;
    }

    /**
     * Helper method to trigger an immediate sync ("refresh").
     *
     * <p>This should only be used when we need to preempt the normal sync schedule. Typically, this
     * means the user has pressed the "refresh" button.
     *
     * Note that SYNC_EXTRAS_MANUAL will cause an immediate sync, without any optimization to
     * preserve battery life. If you know new data is available (perhaps via a GCM notification),
     * but the user is not actively waiting for that data, you should omit this flag; this will give
     * the OS additional freedom in scheduling your sync request.
     */
    public  void TriggerRefresh() {
        Bundle b = new Bundle();
        // Disable sync backoff and ignore sync preferences. In other words...perform sync NOW!
        b.putBoolean(ContentResolver.SYNC_EXTRAS_MANUAL, true);
        b.putBoolean(ContentResolver.SYNC_EXTRAS_EXPEDITED, true);
        ContentResolver.requestSync(
                mAccount, // Sync account
                AUTHORITY,                 // Content authority
                b);                                             // Extras
    }

    public void addPeriodicSync() {
        try {
            ContentResolver.addPeriodicSync(mAccount, AUTHORITY, new Bundle(), SYNC_INTERVAL);
        } catch (Exception ex) {
            LogUtil.INSTANCE.e(LOG_TAG, "Failed to add sync period " + ex);
        }
    }

    public void removePeriodicSync() {
        try {
            ContentResolver.removePeriodicSync(mAccount, AUTHORITY, new Bundle());
        } catch (Exception ex) {
            LogUtil.INSTANCE.e(LOG_TAG, "Failed to remove sync period");
        }
    }
}
