package tv.airtel.util.util

import android.text.TextUtils
import com.google.gson.Gson
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import tv.airtel.util.config.ConfigurationManager
import java.util.ArrayList
import javax.inject.Inject
import javax.inject.Singleton


/**
 * Created by AkashGupta on 05/04/18.
 *
 */
@Singleton
class JSONParserUtil @Inject
internal constructor(){

    @Inject
    internal lateinit var configurationManager: ConfigurationManager

//    companion object {

        private var jsonObject: JSONObject? = null
        @Throws(JSONException::class)
        fun getString(Key: String, rawObject: JSONObject): String {
            return rawObject.optString(Key)
        }

        @Throws(JSONException::class)
        fun getBoolean(Key: String, rawObject: JSONObject): Boolean {
            return rawObject.optBoolean(Key)
        }

        @Throws(JSONException::class)
        fun getJSONtitle(jsonTitle: String, key: String): String? {
            var mJsonTitle = jsonTitle
            var result: String? = null
            mJsonTitle = convertStandardJSONString(mJsonTitle)
            try {
                jsonObject = JSONObject(mJsonTitle)
                result = jsonObject!!.getString(key)
            } catch (e: JSONException) {
                e.printStackTrace()
            }

            return result
        }

        fun convertStandardJSONString(data_json: String): String {
            var data_json = data_json
            data_json = data_json.replace("\"{", "{")
            data_json = data_json.replace("}\",", "},")
            data_json = data_json.replace("}\"", "}")
            return data_json
        }

        fun isJSONValid(jsonInString: String): Boolean {
            try {
                Gson().fromJson(jsonInString, Any::class.java)
                return true
            } catch (ex: com.google.gson.JsonSyntaxException) {
                return false
            }

        }

        fun isJSONValid(`object`: Any): Boolean {
            try {
                val jsonInString = `object` as String
                Gson().fromJson(jsonInString, Any::class.java)
                return true
            } catch (ex: Exception) {
                return false
            }

        }

        fun parseJsonToStringList(jsonArray: JSONArray): List<String> {
            val list = ArrayList<String>()
            try {
                for (i in 0 until jsonArray.length()) {
                    list.add(jsonArray.optJSONObject(i).optString(configurationManager.getSelectedLanguage()))
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }

            return list
        }

        fun parseJsonToStringArray(jsonArray: JSONArray?): Array<String?>? {
            val list = jsonArray?.length()?.let { length -> arrayOfNulls<String>(length) }
            try {
                if(jsonArray?.length() != null)
                for (i in 0 until jsonArray.length()) {
                    list?.set(i, jsonArray.optJSONObject(i).optString(configurationManager.getSelectedLanguage()))
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }

            return list
        }

        fun parseFiltersJson(filterJson: String, categoriesValue: String): JSONObject? {
            try {
//                filterJson = configUtils.getString(Keys.FILTERS)
                val jsonObject = JSONObject(filterJson)

                val keysStr = jsonObject.keys()

                while (keysStr.hasNext()) {
                    val key = keysStr.next()
                    for (i in 0 until jsonObject.optJSONArray(key).length()) {
                        var label = jsonObject.optJSONArray(key).optJSONObject(i).optString("label")
                        label = label.replace("\\s+".toRegex(), "")
//                        val categoriesValue = configUtils.getJsonString(Constants.FILTER_CATEGORIES_PREFIX + key.toLowerCase() + label.toLowerCase())
                        if (!TextUtils.isEmpty(categoriesValue)) {
                            val catTempArray = JSONArray(categoriesValue)
                            jsonObject.optJSONArray(key).optJSONObject(i).put("category", catTempArray)
                        }
                    }
                }
                LogUtil.d("TRANSFORMED JSON ", jsonObject.toString())
                LogUtil.d("TRANSFORMED JSON ", jsonObject.toString())
                return getTransformedFilterJson(jsonObject)
            } catch (e: Exception) {
                e.printStackTrace()
            }

            return null
        }

        private fun getTransformedFilterJson(jsonObject: JSONObject): JSONObject {
            try {

                val jsonNew = JSONObject()
                val keysStr = jsonObject.keys()
                while (keysStr.hasNext()) {
                    val key = keysStr.next()
                    val dummyArray = JSONArray()
                    for (i in 0 until jsonObject.optJSONArray(key).length()) {

                        val objCatgeory = jsonObject.optJSONArray(key).optJSONObject(i)
                        if (!TextUtils.isEmpty(objCatgeory.optString("category")) && !objCatgeory.optString("category").equals("null", ignoreCase = true)) {
                            dummyArray.put(objCatgeory)
                        }
                    }
                    jsonNew.put(key, dummyArray)
                }
                LogUtil.d("TANSFORMED ", jsonNew.toString())
                return jsonNew
            } catch (e: Exception) {
                e.printStackTrace()
            }

            return jsonObject
        }
//    }
}