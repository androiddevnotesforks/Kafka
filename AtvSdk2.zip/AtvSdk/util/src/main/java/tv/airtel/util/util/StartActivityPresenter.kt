package tv.airtel.util.util

/**
 * Created by a1wew4g3 on 04/01/18.
 * onActivity result is used for custom view and fragment and for adapters as well
 */
interface StartActivityPresenter {
    /**
     * Method that control the lifecycle of the view. It should be called in the view's
     * (Activity or Fragment) onResume() method.
     */
    fun resume()

    /**
     * Method that control the lifecycle of the view. It should be called in the view's
     * (Activity or Fragment) onPause() method.
     */
    fun pause()

    /**
     * Method that control the lifecycle of the view. It should be called in the view's
     * (Activity or Fragment) onDestroy() method.
     */
    fun destroy()

    /**
     * on activity result that contains result code , request code , and returning intent
     */
    fun onActivityResult(result: ActivityResult)
}