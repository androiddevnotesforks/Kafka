package tv.airtel.data.model.content.detail

import android.arch.persistence.room.Entity
import tv.airtel.data.model.content.ContentDetail

/**
 * Created by Aditya Mehta on 29/08/18.
 */
@Entity
open class EpisodeDetailCache : ContentDetail()