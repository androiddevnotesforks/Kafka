package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class RechargeBenefit(
        @SerializedName("imgUrl") @Expose val imageUrl: String,
        @SerializedName("text") @Expose val text: String
)