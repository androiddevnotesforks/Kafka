package tv.airtel.data.model

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.model.content.ImagesApiModel

@Entity
data class PeopleProfile(
        @PrimaryKey
        @SerializedName("id")
        @Expose
        var id: String = "",
        @SerializedName("normalizedTitle")
        @Expose
        var normalizedTitle: String? = null,
        @SerializedName("displayTitle")
        @Expose
        var displayTitle: String? = null,
        @SerializedName("images")
        @Expose
        var images: ImagesApiModel? = null,
        @SerializedName("type")
        @Expose
        var type: String? = null,
        @SerializedName("isNew")
        @Expose
        @ColumnInfo(name = "isNew")
        var new: String? = null,
        @SerializedName("tmdbId")
        @Expose
        var tmdbId: String? = null,
        @SerializedName("description")
        @Expose
        var description: String? = null,
        @SerializedName("imdbId")
        @Expose
        var imdbId: String? = null,
        @SerializedName("gender")
        @Expose
        var gender: String? = null,
        @SerializedName("placeOfBirth")
        @Expose
        var placeOfBirth: String? = null,
        @SerializedName("tags")
        @Expose
        var tags: List<String>? = null,
        @SerializedName("birthday")
        @Expose
        var birthday: Long? = null,
        @SerializedName("adult")
        @Expose
        var adult: Boolean? = null,
        @SerializedName("popularity")
        @Expose
        var popularity: Double? = null,
        @SerializedName("lastIngestionTime")
        @Expose
        var lastIngestionTime: Long? = null,
        @SerializedName("portraitImage")
        @Expose
        var portraitImage: String? = null)
