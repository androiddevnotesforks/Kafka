package tv.airtel.data.utilmodule.util

/**
 * Created by VipulKumar on 19/03/18.
 *
 */

object StringUtil {
    fun capitalize(s: String?): String {
        if (s == null || s.isEmpty()) {
            return ""
        }
        val first = s[0]
        return if (Character.isUpperCase(first)) {
            s
        } else {
            Character.toUpperCase(first) + s.substring(1)
        }
    }
}
