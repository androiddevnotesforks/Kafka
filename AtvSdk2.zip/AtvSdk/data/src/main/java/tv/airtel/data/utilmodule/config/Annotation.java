package tv.airtel.data.utilmodule.config;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by a1wew4g3 on 15/09/17.
 *
 */
public class Annotation {
    @Retention(RetentionPolicy.RUNTIME)
    public @interface FirebaseConfig {
    }
    @Retention(RetentionPolicy.RUNTIME)
    public @interface ConstantConfig {
    }

    public enum AnnotationType {
        Firebase, Constants
    }
}
