package tv.airtel.data.model

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.SerializedName

/**
 * Author : Akash Gupta
 * Created On : 05/05/19
 *
 */
data class AppUpdateRequestInfo(
        @SerializedName("methodName")
        var methodName: String? = null,

        @SerializedName("headers")
        var headers: HashMap<String, String>? = null
) : Parcelable {
    constructor(parcel: Parcel) : this(
            parcel.readString(), parcel.readSerializable() as HashMap<String, String>) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(methodName)
        parcel.writeSerializable(headers)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<AppUpdateRequestInfo> {
        override fun createFromParcel(parcel: Parcel): AppUpdateRequestInfo {
            return AppUpdateRequestInfo(parcel)
        }

        override fun newArray(size: Int): Array<AppUpdateRequestInfo?> {
            return arrayOfNulls(size)
        }
    }
}