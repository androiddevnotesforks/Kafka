package tv.airtel.data.model.user

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

@Entity
data class OtpSuccessEntity (
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0,
    @SerializedName("success")
    @Expose
    var success: Boolean? = null
)