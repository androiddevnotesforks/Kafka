package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class UserInfo (
    @SerializedName("uid")
    @Expose
    var uid: String? = null,
    @SerializedName("name")
    @Expose
    var name: String? = null,
    @SerializedName("lang")
    @Expose
    var lang: List<String>? = null,
    @SerializedName("gender")
    @Expose
    var gender: String? = null,
    @SerializedName("email")
    @Expose
    var email: String? = null,
    @SerializedName("dob")
    @Expose
    var dob: Long? = 0,
    @SerializedName("msisdn")
    @Expose
    var phoneNumber: String? = null,
    @SerializedName("huaweiNamespace")
    @Expose
    var huaweiNamespace: String? = null
)
