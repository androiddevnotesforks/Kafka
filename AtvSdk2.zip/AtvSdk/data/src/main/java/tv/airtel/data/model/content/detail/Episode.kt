package tv.airtel.data.model.content.detail

import android.arch.persistence.room.Entity
import android.arch.persistence.room.ForeignKey
import android.arch.persistence.room.ForeignKey.CASCADE
import android.arch.persistence.room.PrimaryKey
import android.arch.persistence.room.Relation
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.model.content.ImagesApiModel
import tv.airtel.data.model.content.recentfavorite.RecentFavoriteEntity

@Entity
data class Episode(

    @SerializedName("refId")
    @Expose
    @PrimaryKey
    var refId: String = "",

    @SerializedName("name")
    @Expose
    var name: String? = null,

    @SerializedName("description")
    @Expose
    var description: String? = null,

    @SerializedName("duration")
    @Expose
    var duration: Int = 0,

    @SerializedName("airDate")
    @Expose
    var airDate: Long = 0,

    @SerializedName("episodeNumber")
    @Expose
    var episodeNumber: Int = 0,

    @SerializedName("images")
    @Expose
    var images: ImagesApiModel? = null,

    @ForeignKey(entity = EpisodeDetailCache::class,
            parentColumns = arrayOf("id"),childColumns = arrayOf("refId"),onDelete = ForeignKey.CASCADE,
            onUpdate = ForeignKey.CASCADE
    )
    var seasonId:String = ""
)
