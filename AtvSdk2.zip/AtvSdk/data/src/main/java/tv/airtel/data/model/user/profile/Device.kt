package tv.airtel.data.model.user.profile

import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.SerializedName

data class Device(
        @field:SerializedName("notificationKey")
        val notificationKey: String?,

        @field:SerializedName("appVersion")
        val appVersion: String?,

        @field:SerializedName("os")
        val os: String?,

        @field:SerializedName("osVersion")
        val osVersion: String?,

        @field:SerializedName("deviceId")
        @PrimaryKey
        var deviceId: String = "",

        @field:SerializedName("lastActiveTime")
        var lastActiveTime: Long = 0L,

        @field:SerializedName("name")
        var deviceName: String? = null,

        @field:SerializedName("buildNumber")
        val buildNumber: String?,

        @field:SerializedName("deviceType")
        val deviceType: String?
)
