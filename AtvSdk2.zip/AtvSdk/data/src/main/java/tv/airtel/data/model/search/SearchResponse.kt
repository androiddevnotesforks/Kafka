package tv.airtel.data.model.search

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import android.arch.persistence.room.TypeConverters
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.db.MiddlewareTypeConverters

@Entity
data class SearchResponse (
    @PrimaryKey
    var id: String = "",
    @SerializedName("PLAYABLE_CONTENT")
    @Expose
    var searchContentEntity: SearchContentEntity? = null,
    @SerializedName("PEOPLE")
    @Expose
    var searchPeopleEntity: SearchPeopleEntity? = null
)