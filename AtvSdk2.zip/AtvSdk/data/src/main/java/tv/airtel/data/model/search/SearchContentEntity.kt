package tv.airtel.data.model.search

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.model.content.Content

data class SearchContentEntity (
    @SerializedName("type")
    @Expose
    var type: String? = null,
    @SerializedName("results")
    @Expose
    var results: List<Content>? = null,
    @SerializedName("totalRecord")
    @Expose
    var totalRecord: Int = 0

)