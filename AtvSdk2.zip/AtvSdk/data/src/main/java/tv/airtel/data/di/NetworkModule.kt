package tv.airtel.data.di

import android.app.Application
import dagger.Module
import dagger.Provides
import tv.airtel.data.api.MiddlewareAPi
import tv.airtel.data.api.RetrofitProvider
import tv.airtel.data.db.AppDao
import tv.airtel.data.db.ContentDao
import tv.airtel.data.db.ContentDetailDao
import tv.airtel.data.db.LayoutDao
import tv.airtel.data.db.MiddlewareDb
import tv.airtel.data.db.ProfileDao
import tv.airtel.data.db.RecentFavoriteDao
import tv.airtel.data.db.SearchDao
import tv.airtel.data.db.UserDao
import javax.inject.Singleton


/**
 * Created by Aditya Mehta on 16/04/18.
 */
@Module
class NetworkModule {

    @Singleton
    @Provides
    internal fun provideRetrofitService12(application: Application, debuggable: Boolean): MiddlewareAPi {
        return RetrofitProvider
                .provideDefaultRetrofit(application, debuggable)
                .create(MiddlewareAPi::class.java)
    }

    @Singleton
    @Provides
    internal fun provideDb(app: Application): MiddlewareDb {
        return MiddlewareDb.getInstance(app)
    }

    @Singleton
    @Provides
    internal fun provideContentDao(db: MiddlewareDb): ContentDao {
        return db.contentDao()
    }

    @Singleton
    @Provides
    internal fun provideContentDetailDao(db: MiddlewareDb): ContentDetailDao {
        return db.contentDetailDao()
    }

    @Singleton
    @Provides
    internal fun provideLayoutDao(db: MiddlewareDb): LayoutDao {
        return db.layoutDao()
    }

    @Singleton
    @Provides
    internal fun provideUserDao(db: MiddlewareDb): UserDao {
        return db.userDao()
    }

    @Singleton
    @Provides
    internal fun provideSearchDao(db: MiddlewareDb): SearchDao {
        return db.searchDao()
    }

    @Singleton
    @Provides
    internal fun provideProfileDao(db: MiddlewareDb): ProfileDao {
        return db.profileDao()
    }

    @Singleton
    @Provides
    internal fun provideRecentFavoriteDao(db: MiddlewareDb): RecentFavoriteDao {
        return db.recentFavoriteDao()
    }


    @Singleton
    @Provides
    internal fun provideAppDao(db: MiddlewareDb): AppDao {
        return db.appDao()
    }
}
