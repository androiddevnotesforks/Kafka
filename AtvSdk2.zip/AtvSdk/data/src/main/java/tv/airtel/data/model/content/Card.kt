package tv.airtel.data.model.content

import tv.airtel.data.model.layout.Meta

data class Card (
    var programType: String? = null,
    var seriesId: String? = null,
    var programId: String? = null,
    var footerIconUrl: String? = null,
    var cardImageUrl: String? = null,
    var thumborImageUrl: String? = null,
    var longDescription: Array<String>? = null,
    var cardDescription: String? = null,
    var longTitle: String? = null,
    var meta: Meta? = null,
    var contentProgramId: String? = null
) : BaseRow()
