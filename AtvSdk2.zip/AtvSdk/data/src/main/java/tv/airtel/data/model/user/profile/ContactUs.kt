package tv.airtel.data.model.user.profile

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class ContactUs (

    @SerializedName("help_desk")
    @Expose
    var helpDeskNumber: String? = null,

    @SerializedName("feedback")
    @Expose
    var feedbackUrl: String? = null
)