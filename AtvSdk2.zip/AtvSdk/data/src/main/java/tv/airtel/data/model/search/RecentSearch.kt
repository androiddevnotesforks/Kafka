
package tv.airtel.data.model.search

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import android.support.annotation.NonNull

/**
 *
 * Created by Satya on 14/05/18.
 */
@Entity
data class RecentSearch(
    @PrimaryKey
    @NonNull
    var searchKey: String,

    @NonNull
    var timeStamp: Long,

    var searchConsumed: Boolean = false

)