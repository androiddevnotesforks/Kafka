package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class VideoRail(
    @SerializedName("rail_title")
    @Expose
    val railTitle: String,
    @SerializedName("video_count")
    @Expose
    val videoCount: Int,
    @SerializedName("videos")
    @Expose
    val videos: List<Video>,
    @SerializedName("rail_id")
    @Expose
    val railId: String
)