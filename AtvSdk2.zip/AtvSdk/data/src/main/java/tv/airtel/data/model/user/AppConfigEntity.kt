package tv.airtel.data.model.user

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Author : Akash Gupta
 * Created On : 15/06/18
 *
 */
@Entity
data class AppConfigEntity(

        @PrimaryKey
        @Expose
        var id:Int = 1001,

        @SerializedName("configs")
        @Expose
        var configs: AppConfig? = null
)