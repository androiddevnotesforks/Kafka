package tv.airtel.data.model.layout

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class Action (

    @SerializedName("color")
    @Expose
    var color: String? = null,
    @SerializedName("t")
    @Expose
    var t: String? = null,
    @SerializedName("st")
    @Expose
    var st: String? = null,
    @SerializedName("meta")
    @Expose
    var meta: Meta? = null,
    @SerializedName("pageId")
    @Expose
    var pageId: String? = null,
    @SerializedName("source")
    @Expose
    var source: String? = null,
    @SerializedName("packageId")
    @Expose
    var packageId: String? = null,
    @SerializedName("listingType")
    @Expose
    var listingType: String? = null,
    @SerializedName("channelId")
    @Expose
    var channelId: String? = null,
    @SerializedName("seriesId")
    @Expose
    var seriesId: String? = null,
    @SerializedName("episodeId")
    @Expose
    var episodeId: String? = null,
    @SerializedName("type")
    @Expose
    var ty: String? = null

)
