package tv.airtel.data.model.content.related

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

import tv.airtel.data.model.content.Content

data class SportsRelatedContentDetailsEntity (
    @SerializedName("type")
    @Expose
    var type: String? = null,

    @SerializedName("bymatch")
    @Expose
    var bymatch: List<Content>? = null,

    @SerializedName("byTournament")
    @Expose
    var byTournament: List<Content>? = null,

    @SerializedName("byGenre")
    @Expose
    var byGenre: List<Content>? = null,

    @SerializedName("totalRecord")
    @Expose
    var totalRecord: Int = 0
)