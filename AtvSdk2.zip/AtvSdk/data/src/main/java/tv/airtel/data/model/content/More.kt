package tv.airtel.data.model.content

import java.io.Serializable

import tv.airtel.data.model.layout.BackendType

data class More(
    var meta: Meta? = null,
    var title: String? = null,
    var cta: String? = null,
    var color: String? = null,
    var pageId: String? = null,
    var source: BackendType? = null,
    var packageId: String? = null,
    var contentId: String? = null,
    var channelId: String? = null,
    var seriesId: String? = null,
    var ty: String? = null) : Serializable
