package tv.airtel.data.model.search

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.model.content.ImagesApiModel

data class SearchPeopleModel (
    @SerializedName("creditRef")
    @Expose
    var creditRef: String? = null,

    @SerializedName("characterName")
    @Expose
    var characterName: String? = null,
    @SerializedName("roleType")
    @Expose
    var roleType: String? = null,

    @SerializedName("images")
    @Expose
    var images: ImagesApiModel? = null,
    @SerializedName("displayTitle")
    @Expose
    var displayTitle: String? = null
)