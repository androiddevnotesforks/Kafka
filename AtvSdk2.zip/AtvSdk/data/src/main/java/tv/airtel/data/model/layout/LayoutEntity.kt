package tv.airtel.data.model.layout

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import android.arch.persistence.room.TypeConverters
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.db.MiddlewareTypeConverters

@Entity
data class LayoutEntity (
    @SerializedName("id")
    @Expose
    @PrimaryKey
    var id: String = "",
    @SerializedName("contents")
    @Expose
    var contents: List<LayoutContent>? = null,
    @SerializedName("name")
    @Expose
    var name: String? = null,
    @SerializedName("contentState")
    @Expose
    var contentState: String? = null,
    @SerializedName("format")
    @Expose
    var layoutFormat: LayoutFormat? = null,
    @Expose
    var pageId: String? = null
)
