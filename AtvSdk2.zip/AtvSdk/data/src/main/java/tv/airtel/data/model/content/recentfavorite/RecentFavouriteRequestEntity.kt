package tv.airtel.data.model.content.recentfavorite

import com.google.gson.annotations.SerializedName
import tv.airtel.data.model.Recents

/**
 * Author : Akash Gupta
 * Created On : 09/08/18
 *
 */
data class RecentFavouriteRequestEntity(
        @field:SerializedName("favourites")
        var favorites: Favorites? = null,

        @field:SerializedName("recents")
        var recents: Recents? = null
)