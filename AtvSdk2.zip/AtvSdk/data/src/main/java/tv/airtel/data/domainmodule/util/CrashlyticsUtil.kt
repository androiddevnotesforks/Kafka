@file:Suppress("unused")

package tv.airtel.data.domainmodule.util

import android.content.Context
import android.text.TextUtils
import com.crashlytics.android.Crashlytics
import com.crashlytics.android.answers.Answers
import io.fabric.sdk.android.Fabric
import tv.airtel.data.utilmodule.util.Constants
import tv.airtel.data.utilmodule.DeviceIdentifier

object CrashlyticsUtil {
    //The keys which can be stored in Crashlytics
    const val CRASHLYTICS_EVENT_KEY_CONTENT_ID = "Content Id"
    const val CRASHLYTICS_EVENT_KEY_CONTENT_NAME = "Content Name"
    const val CRASHLYTICS_EVENT_KEY_USER_ACTION = "User Action"
    const val CRASHLYTICS_EVENT_KEY_CONTENT_PROVIDER_NAME = "Content Provider Name"
    const val CRASHLYTICS_EVENT_KEY_PAGE_NAME = "Page Name"
    const val CRASHLYTICS_EVENT_KEY_USER_STATE = "User State"
    const val CRASHLYTICS_EVENT_KEY_DOWNLOAD_ID = "Download Content Id"
    const val CRASHLYTICS_EVENT_KEY_DOWNLOAD_STATUS = "Download Status"
    const val CRASHLYTICS_EVENT_KEY_APPLICATION_STATUS = "Application Status"
    const val CRASHLYTICS_EVENT_KEY_NAVIGATION_ACTION = "Navigation Action ID"
    const val CRASHLYTICS_EVENT_KEY_VSTB_LIB_STATE = "VSTB State"
    const val CRASHLYTICS_EVENT_KEY_VSTB_LIB_VERSION = "VSTB Version"
    const val CRASHLYTICS_EVENT_KEY_VSTB_LIB_ERR_CODE = "VSTB Error Code"


    //The values which can be stored in Crashlytics
    const val CRASHLYTICS_EVENT_VSTB_VSTB_LIB_STATE_NOT_INITIALIZED = "NotInitialized"
    const val CRASHLYTICS_EVENT_VALUE_USER_STATE_VISITOR = "Visitor"

    const val CRASHLYTICS_EVENT_VALUE_APPLICATION_STATE_START = "App Started"
    const val CRASHLYTICS_EVENT_VALUE_APPLICATION_STATE_STOP = "App Stopped"

    const val CRASHLYTICS_EVENT_VALUE_USER_ACTION_FAVORITE_ADD = "Add Favorite"
    const val CRASHLYTICS_EVENT_VALUE_USER_ACTION_FAVORITE_REMOVE = "Remove Favorite"

    const val CRASHLYTICS_EVENT_VALUE_USER_ACTION_PLAYBACK_PREPARE = "Playback Prepare"
    const val CRASHLYTICS_EVENT_VALUE_USER_ACTION_PLAYBACK_START = "Playback Start"
    const val CRASHLYTICS_EVENT_VALUE_USER_ACTION_PLAYBACK_STOP = "Playback Stop"
    const val CRASHLYTICS_EVENT_VALUE_USER_ACTION_PLAYBACK_PAUSE = "Playback Pause"
    const val CRASHLYTICS_EVENT_VALUE_USER_ACTION_PLAYBACK_RESUME = "Playback Resume"
    const val CRASHLYTICS_EVENT_VALUE_USER_ACTION_PLAYBACK_FAILED = "Playback Failed"

    const val CRASHLYTICS_EVENT_VALUE_USER_ACTION_DOWNLOAD_START = "Download Start"
    const val CRASHLYTICS_EVENT_VALUE_USER_ACTION_DOWNLOAD_STOP = "Download Stop"
    const val CRASHLYTICS_EVENT_VALUE_USER_ACTION_DOWNLOAD_PAUSE = "Download Pause"
    const val CRASHLYTICS_EVENT_VALUE_USER_ACTION_DOWNLOAD_RESUME = "Download Resume"
    const val CRASHLYTICS_EVENT_VALUE_USER_ACTION_DOWNLOAD_FAILED = "Download Failed"

    const val CRASHLYTICS_EVENT_VALUE_DOWNLOAD_STATUS_ACTIVE = "Download Active"
    const val CRASHLYTICS_EVENT_VALUE_DOWNLOAD_STATUS_INACTIVE = "Download Inactive"

    const val CRASHLYTICS_EVENT_VALUE_USER_ACTION_CONTENT_SHARE = "Content Share"

    //User Login Log Keys.


    const val CRASHLYTICS_EVENT_VALUE_BSB_LOGIN_START = "BSB Login Start"
    const val CRASHLYTICS_EVENT_VALUE_BSB_LOGIN_STATUS = "BSB Login Status"
    const val CRASHLYTICS_EVENT_VALUE_USER_AIRTEL_USER = "BSB User Operator"
    const val CRASHLYTICS_EVENT_VALUE_USER_AIRTEL_USER_TYPE = "BSB User Type"

    const val CRASHLYTICS_EVENT_VALUE_UID_FROM_PREFERNCE = "UID In Preference"
    const val CRASHLYTICS_EVENT_VALUE_TOKEN_FROM_PREFERNCE = "TOKEN In Preference"
    const val CRASHLYTICS_EVENT_VALUE_USER_AIRTEL_USER_TYPE_FROM_PREFERENCE = "User type In Preference"
    const val CRASHLYTICS_EVENT_VALUE_USER_AIRTEL_USER_FROM_PREFERENCE = "User Operator In preference"

    const val CRASHLYTICS_EVENT_VALUE_APPGRID_USER_FETCH = "Appgrid User fetch"
    const val CRASHLYTICS_EVENT_VALUE_APPGRID_USER_FETCH_STATUS = "Appgrid User fetch status"

    const val CRASHLYTICS_EVENT_VALUE_APPGRID_USER_UPDATE_START = "Appgrid User update start"
    const val CRASHLYTICS_EVENT_VALUE_APPGRID_USER_UPDATE_STATUS = "Appgrid User update status"

    const val CRASHLYTICS_EVENT_VALUE_BSB_REQUEST_OTP_START = "BSB OTP Request Start"
    const val CRASHLYTICS_EVENT_VALUE_BSB_REQUEST_OTP_STATUS = "BSB OTP Status"

    const val CRASHLYTICS_EVENT_VALUE_BSB_OTP_VERIFICATION_START = "BSB OTP Verification Start"
    const val CRASHLYTICS_EVENT_VALUE_BSB_OTP_VERIFICATION_STATUS = "BSB OTP Verification Status"

    const val CRASHLYTICS_EVENT_APP_START_AT = "Wynk Videos Start at"

    const val CRASHLYTICS_EVENT_ACCOUNT_START = "pack status fetch start"
    const val CRASHLYTICS_EVENT_ACCOUNT_STATUS = "packstatus fetching status"


    // Play back keys
    const val CRASHLYTICS_EVENT_PLAY_BACK_ASSET_TYPE = "Media Playing Asset"
    const val CRASHLYTICS_EVENT_PLAY_BACK_PROFILE_CALL = "Media Profile Call"
    const val CRASHLYTICS_EVENT_PLAYER_ERROR = "Player Error"


    fun logCrashlytics(e: Throwable) {
        //TODO need to get object of Crashlytics while initializing player object
        if (Fabric.isInitialized())
            Crashlytics.logException(e)
    }

    fun logCrashlyticsTag(priority: Int, tag: String, msg: String) {
        if (Fabric.isInitialized())
            Crashlytics.log(priority, tag, msg)
    }

    fun logKeyValue(key: String, value: String) {
        if (Fabric.isInitialized())
            Crashlytics.setString(key, value)
    }

    fun initCrashlytics(context: Context) {
        try {

            if (!Fabric.isInitialized()) {
                Fabric.with(context, Crashlytics(),Answers())
                Crashlytics.setString(Constants.CrashlyticsKeys.DEVICE_ID, DeviceIdentifier.getDeviceId(context))
            }

        } catch (ex: RuntimeException) {
            ex.printStackTrace()
        }
    }

    /**
     * This method should be called only after Crashlytics
     */
    fun setUserInfo(uid: String?, email: String?) {

        if (!TextUtils.isEmpty(uid)) {

            Crashlytics.setUserIdentifier(uid)
            if (!TextUtils.isEmpty(email)) {

                Crashlytics.setUserEmail(email)
            }
        }
    }
}
