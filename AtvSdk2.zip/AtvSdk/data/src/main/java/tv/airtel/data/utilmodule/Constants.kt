@file:Suppress("MayBeConstant", "unused")

package tv.airtel.data.utilmodule

import tv.airtel.util.R

@Suppress("MayBeConstant")
/**
 * Created by manishmalhotra on 18/09/17.
 *
 */
object Constants {


    const val EVENT_START = "START"
    const val SUCCESS = "SUCCESS"
    const val FAILURE = "FAILURE"
    //Constants for asset payment comparison
    const val FREE = "free"
    const val PREMIUM = "premium"
    const val NA = "NA"
    const val ENCODING_UTF8 = "UTF-8"
    const val CONTENT_TYPE_PLAIN_TEXT = "plain/text"
    const val CONTENT_TYPE_TEXT_PLAIN = "text/plain"
    const val CONTENT_TYPE_TEXT_HTML = "text/html"

    const val PLAYSTORE_BASE_URL = "https://play.google.com/store/apps/details?id="
    const val INTENT_ACTION_PHONE_STATE = "android.intent.action.PHONE_STATE"

    //Constants related to CPs
    const val DAILYMOTION = "DAILYMOTION"
    const val SONYLIV = "SONYLIV"
    const val EROSNOW = "EROSNOW"
    //    String SINGTEL = "SINGTEL";
    const val YOUTUBE = "YOUTUBE"
    const val NOTSINGTEL = "NOTSINGTEL"
    const val HUAWEI = "HUAWEI"
    const val HOTSTAR = "HOTSTAR"
    const val TVPROMO = "TVPROMO"
    const val AMAZON = "AMAZON"
    const val FASTFILMZ = "FASTFILMZ"
    const val MWTV = "MWTV"
    const val UNKNOWN = "UNKNOWN"
    const val ALTBALAJI = "ALTBALAJI"

    //General messages
    const val MOVIES = "Movies"
    const val MOVIE = "movie"
    const val SPORTS = "SPORTS"
    const val VIDEO = "video"
    const val OTHER = "other"
    const val EPISODE = "episode"
    const val TVSHOW = "tvshow"
    const val SERIES = "series"
    const val LIVETVSHOW = "livetvshow"
    const val LIVETVMOVIE = "livetvmovie"

    const val DEFAULT_THEME = "default"
    const val kEY_THEME_COLOR = "themeColor"
    const val PAGE_TO_OPEN = "pageId"

    //User Preference Keys
    const val PREF_FIRST_LAUNCH = "firstLaunch"
    const val PREF_VALUE_FIRST_TIME = "first_time"
    const val PREF_FIRST_TIME_TOUR = "first_time_tour"
    const val PREF_FIRST_TIME_CHROMECAST = "first_time_chromecast"
    const val PREF_FIRST_TIME_HOME = "first_time_home"
    const val PREF_SHOW_CASE_MOVIE_DETAIL = "showcase_movie_detail"
    const val PREF_UNAME = "uName"
    const val PREF_NOTIFICATION = "notification"
    const val PREF_VIDEO_SELECTED_BTN = "video_selected_btn"
    const val PREF_AUTO_RENEWAL = "auto_renewal"
    const val UUID = "uuid"
    const val STOKEN = "stoken"
    const val UNAME = "uname"
    const val GENDER = "gender"
    const val DOB = "dob"
    const val TABLET = "tablet"
    const val PHONE = "phone"
    const val HLS_URL = "HLS_URL"
    const val ELEMENTAL = "ELEMENTAL"
    const val URL = "URL"

    const val PHONE_NO = "phone_no"
    const val PROFILE_TOKEN = "profile_token"
    const val PROFILE_UID = "profile_uid"
    const val MSISDN = "msisdn"
    const val REQUIRE_OTP = "requireOtp"
    const val MCC = "mcc"
    const val MNC = "mnc"
    const val USER_PROPERTIES = "user_properties"
    const val QUERY = "query"
    const val MAX_ITEM = 6
    const val SOURCE_NAME = "source_name"
    const val RAIL_TITLE = "rail_title"
    const val RAIL_ICON = "rail_icon"
    const val PLAYBILLID = "playbillid"
    const val PLAYTYPE = "playtype"
    const val RAIL_POSITION = "rail_position"

    const val CPID = "cp"
    const val FIRST_CONSENT = "firstConsent"
    const val SECOND_CONSENT = "secondConsent"
    const val TYPE = "type"


    //Extras
    const val EXTRA_PHONE_NUMBER = "phone_num"
    const val EXTRA_ASSET = "Asset"
    const val BUNDLE_ASSET_ID = "bundleAsset"
    const val EXTRA_DIRECTPLAY = "directplay"
    const val EXTRA_IS_APP_LIVE = "isApplive"
    const val EXTRA_ASSET_ID = "assetId"
    const val EXTRA_CP_TOKEN = "cpToken"
    const val EXTRA_PLAN_ID = "planId"
    const val EXTRA_SOURCE = "source"
    const val EXTRA_TITLE = "title"
    const val EXTRA_SEARCH_KEY = "searchkey"
    const val EXTRA_AVAILABLE_TEXT = "availableText"
    const val EXTRA_MEDU_ID = "menuID"
    const val EXTRA_PROGRAM_TYPE = "programType"
    const val EXTRA_GENRE = "genre"
    const val EXTRA_CHANNEL = "channel"
    const val EXTRA_LANGUAGE = "language"
    const val EXTRA_EMPTY_TEXT = "emptyText"
    const val EXTRA_URL = "url"
    const val EXTRA_SIGNATURE = "signature"
    const val EXTRA_ROW_ITEM_CONTENT = "extra_row_item_content"
    const val EXTRA_SOURCE_NAME = "extra_source_name"

    //Download constants
    const val DOWNLOAD_NOW = "downloadNow"
    const val DOWNLOAD_LATER = "downloadLater"
    const val DOWNLOADING = "DOWNLOADING"
    const val DOWNLOADED = "DOWNLOADED"
    const val DOWNLOAD_TITLE = "DOWNLOAD_TITLE"
    const val DOWNLOAD_SCHEDULE_MESSAGE = "Your download is being scheduled from %s to %s \n\n You can manage your content under downloads"
    const val ASSET_ID = "assetId"
    const val CP_TOKEN = "cpToken"
    const val KEY_CP_ID = "cpId"
    const val KEY_CONTENT_ID = "contentId"
    const val DOWNLOADED_DATE = "downloadedDate"
    const val KEY_TO_DOWNLOAD = "to_download"

    const val PORTRAIT = "portrait"
    const val LANDSCAPE = "landscape"
    const val SECRET = "123#abcyjsd"
    const val LAYOUT_TYPE_CUSTOM = "custom"

    const val BUNDLE_ID = "bundle"
    const val KEY_PRODUCT_ID = "productId"

    const val UID = "uid"
    const val PRODUCT_NAME = "productname"
    const val USER_TYPE = "usertype"
    const val OPERATOR_TYPE = "operatortype"
    const val AIRTEL_USER = "airteluser"
    const val NON_AIRTEL_USER = "nonairteluser"
    const val NONE = "none"
    const val EMAIL = "email"
    const val FEMALE = "female"
    const val MALE = "male"
    const val CHANGE_NO = "change_number"
    const val IS_DOWNLOADED = "isDownloaded"
    const val HOOQ = "HOOQ"
    const val TRACK_STATE = "TrackState"
    const val CONFIGURE = "configure"
    const val TRACK = "track"
    const val START = "start"
    const val COMPLETE = "complete"
    const val PACK_NAME = "packName"
    const val PACK_PRICE = "price"
    const val PACK_DESC = "product_description"
    const val SUBSCRIPTION_UNIT = "subscriptionUnit"
    const val HOME_PAGE = "home"
    const val ACCOUNT_PAGE = "My Account"
    const val SETTINGS_PAGE = "Settings"
    const val DOWNLOADS_PAGE = "Downloads"
    const val BUNDLE_FLAG = "bundleFlag"
    const val ALREADY_PLAYED_ASSET = "alreadyPlayedAsset"
    const val BUNDLE_LIMIT = "bundleLimit"
    const val BUNDLE_COUNT = "bundleCounter"
    const val DUMMY_UID = "preUid"
    const val AVAILABLE_CHANNELS = "available"
    const val NAV_TO_REG_PAGE = "navigationToRegPage"
    const val LOGIN_API = "loginApi"
    const val BUNDLE_LITE = "lite"
    const val BUNDLE_PRIME = "Prime"
    const val BUNDLE_PACK_SHOWED = "bundlePackShowed"
    const val BUNDLE_PACK_EXPECTED_SHOW = "bundlePackExpectedShowTime"
    const val BUNDLE_PACK_TYPE = "bundleType"
    const val USER_REGISTERED = "registered"
    const val USER_GUEST = "guest"
    const val USER_PREPAID = "PREPAID"
    const val RENEW_ON = "Renew on "
    const val VALID_TILL = "Valid till "
    const val APPNAME = "Airtel TV"

    // IMPORTANT : Don't use Error code 54321. Already used in pre-burn build
    const val GEO_BLOCKED = 50002
    const val FEED_ERROR_CODE = 50003
    const val HOOQ_USER_AUTH_FAILED = 50004
    const val STREAMING_PROFILE_API_FAILURE_ERRORCODE = 50005
    const val TEXT_STREAMING_PROFILE_API_FAILURE = "Error in fetching data on getting streaming profile API"
    const val BUNDLE_PACK_CODE = 50006
    const val ENTTLEMENT_CALL_FAILURE = 50007
    const val CHECK_AIRTEL_API = 50008
    const val USER_INFO_CODE = 50010
    const val ENTTLEMENT_PLAYBACK_NOT_ALLOWED = 50011
    const val DEFAULT_BITRATE = 0
    const val IMAGE_WIDTH_BUCKET_SIZE = 3

    const val ENTITLEMENT_NOT_ALLOWED_THE_PLAYBACK = "Entitlement not allowed the playback"
    const val VSTB_USER_AUTHENTICATION_MESSAGE = "vstb Authentication success"
    const val VSTB_USER_NOT_AUTHENTICATION_MESSAGE = "Authentication error"
    const val SUBSCRIPTION_STATUS_MAP = "subscriptionStatusMap"
    const val BUNDLE_STATUS_MAP = "bundleStatusMap"
    const val PERSONAL_MESSAGE_KEY = "messageKeys"
    const val GIFT = "gift"
    const val OPTIONAL_RAILS_KEY = "rails"
    const val OFFLINE_BUNDLE_ARRAY_KEY = "productsArray"
    const val OPTIONAL_RAILS_KEY_CONFIG = "railsConfig"
    const val NETWORK_NOT_AVAILABLE = "Network Not Available"
    const val PREF_NETWORK_USAGE = "network_usage"
    const val BAD_RESPONSE = "Bad Response"
    const val DEEPLINK_DATA = "deepLinkData"
    const val BUNDLE_MESSAGE_KEYS = "bundleMessageKeys"
    const val MIDDLEWARE_VERSION = "/v0.18/"
    const val IMAGE_SERVER_VERSION = "/v0.13/"
    const val USER_NOT_FOUND = 404
    const val NEW_USER_STATUS_KEY = "statusCode"
    const val ALL = "ALL"
    const val FIRST_TIME_TOUR = "first_time_tour"
    const val FIRST_TIME_CHROMECAST = "first_time_chromecast"
    const val FIRST_TIME_HOME = "first_time_home"
    const val RECENTLY_WATCHED = "recentlyWatched"
    const val FAVORITES = "favorites"
    const val TVSHOW_DETAIL_HEADING = "tvShowDtailHeading"

    const val DUMMY_TOKEN = "preToken"
    const val SELECTED_LANG_ITEM = "selected_item"
    const val SELECTED_LANG_STRING = "selected_string"
    const val SELECTED_LANG_KEY = "selected_lang"
    const val DEFAULT_MESSAGE = "No message configured"
    const val DEFAULT_MESSAGE_KEY = "en_US"
    const val HINDI_MESSAGE_KEY = "hi"
    const val ERRORCODE_HOOQ_SESSIONOUT = 21110
    const val APPGRID_GENERAL_INFO = 200
    const val APPGRID_ERROR_ERRORCODE = 400
    const val LIVE_TV_INJECTION = "PLTV/"
    const val CATCHUP_INJECTION = "TVOD/"

    //Layout type from appgrid

    const val LAYOUT_PORTRAIT = 0
    const val LAYOUT_LANDSCAPE = 1
    const val LAYOUT_BANNER = 2
    const val LAYOUT_CUSTOM = 3
    const val HIDE_GIFT_COUNTER = -1
    const val HIDE_COUNTER_ONLY = -2


    // TV Guide layout params
    const val DEFAULT_MARGIN_PHONE = 8 / 1920f
    const val COLUMN_CHANNEL_WIDTH_RATIO_PHONE = 200 / 1080f
    const val ROW_HEIGHT_RATIO_PHONE = 205 / 1080f
    const val ROW_TIMEBAR_HEIGHT_RATIO_PHONE = 85 / 1080f
    const val CELL_WIDTH_PER_HOUR_RATIO_PHONE = 801 / 1080f

    const val TRUE = "true"

    // EPG Guide dimension ratios - Tablet
    const val progScrollViewWidth_ratio = 1644 / 1920f // 1718

    const val DEFAULT_MARGIN_TABLET = 3 / 1920f
    const val COLUMN_CHANNEL_WIDTH_RATIO_TABLET = 240 / 1920f // 12.500%
    const val ROW_HEIGHT_RATIO_TABLET = 84 / 1920f // 4.375%
    const val ROW_TIMEBAR_HEIGHT_RATIO_TABLET = 44 / 1920f // ~2.292%
    const val CELL_WIDTH_PER_HOUR_RATIO_TABLET = 540 / 1920f // 28.125%
    //Appgrid logging
    const val CAST_ERROR = "Cast Error"
    const val ERROR_MESSAGE = "error message"
    const val STATUS_CODE = "status code"

    const val TITLE_SEARCH = "Search"
    const val ANDROID_OS = "Android"
    const val KEY_APP_VERSION = "appVersion"
    const val KEY_OS_VERSION = "osVersion"
    const val KEY_OS = "os"
    const val VALUE_DEVICE_KEY = "APADdd8231gg"
    const val KEY_DEVICE_KEY = "deviceKey"
    const val KEY_DEVICE_ID = "deviceId"
    const val KEY_DEVICE_TYPE = "deviceType"
    const val VALUE_RESOLUTION = "1920X1080"
    const val TEXT_FALSE = "false"
    const val TEXT_TRUE = "true"
    const val KEY_MESSAGE = "message"
    const val KEY_FILTER_ALL = "All"


    const val KEY_FAVORITE_SHOW = "favoriteShows"
    const val KEY_FAVORITE_MOVIE = "favoriteMovies"
    const val KEY_FAVORITE_CHANNEL = "favoriteChannels"
    const val KEY_LAST_WATCHED_EPISODES = "lastWatchedEpisodes"
    const val KEY_LAST_WATCHED_MOVIES = "lastWatchedMovies"
    const val KEY_LAST_WATCHED_POSITION = "lastWatchedPosition"

    const val NAV_FROM_ACTION_BAR = "NavigatingFromActionBar"

    const val TEXT_COUNT = "COUNT"
    const val TEXT_LIMIT = "limit"
    const val TEXT_REMAINING = "REMAINING"
    const val COUNTER_API_SUCCESS = "Counter Increment Api Success and message is : "

    const val POSITION = "position"
    const val TEXT_FIRST_RUN = "firstRun"
    const val TEXT_FREE_MEMORY = "free_mem"
    const val MB = "MB"

    const val TEXT_LOGGED_IN = "Loggedin"
    const val SONY = "sony"
    const val WATCH_NOW = "watchnow"

    const val OTP_TOKEN = "otptoken"

    const val DOUBLE_INFINITE_PACK = "double_infinity_message_new"
    const val MAJOR_PACK_VALUE = 2
    const val MINOR_PACK_VALUE = 1
    const val BUNDLE_PRODUCT_ID = "productId"
    const val REORDER_CP_KEY = "reordercp"

    const val DISCOVER_HEADER_SECTION = "Discovery"
    const val DISCOVER_HEADER_MYCOLLECTION = "My Collections"
    const val DISCOVER_HEADER_RESULTS = "Results"
    const val DISCOVER_HEADER_COLLECTION = "Collections"


    const val FILTER_BG_IMAGE = "backgroundimage"
    const val FILTER_ICON = "icon"
    const val FILTER_LABEL = "label"
    const val FILTER_TAG = "tag"
    const val FILTER_CATEGORY = "category"
    const val SORT_BY = "sort by"
    const val FILTER_LANG = "language"
    const val FILTER_SORT_BY_PREFRENCE = "sort_by_pref"
    const val STATUS = "status"
    const val FILTER_NAME = "filterName"
    const val FILTER_TYPE = "filterType"
    const val FILTER = "filter"
    const val FILTER_LANGUAGE = "languages"
    const val FILTER_SORTKEY = "sortKey"
    const val NO_MESSAGE_FOUND_ERROR_PLAYBACK = "No message found for Error Playback"
    const val DISCOVER_FILTER_MOVIE = "Movie"
    const val DISCOVER_FILTER_SHOWS = "series"
    const val EXTRA_USE_EMAIL = "useEmail"
    const val NETWORK_TYPE = "networkType"
    const val LOG_TAG_VSTB = "WYNK-VSTB"

    // Title extra constants
    const val EXTRA_FROM_CHANGE_NO_DIALOG = "extra_change_number_dialog"
    const val EXTRA_FROM_RESET_ACCOUNT = "extra_from_reset_account"

    //    String KEY_PREF_IS_AIRTEL_USER = "key_pref_is_airtel_user";
    const val AIRTEL = "airtel"
    const val OPERATOR = "operator"
    const val ACTION_ACTIVE = "active"

    const val PREF_NAME_VERSION = "pref_name_version"
    const val PREF_KEY_VERSION = "pref_key_version"
    const val MANUFACTURER_XIAOMI = "Xiaomi"
    const val HEADER_BSY_TKN = "x-bsy-utkn"
    const val HEADER_BSY_CID = "x-bsy-cid"
    const val HEADER_BSY_DID = "x-bsy-did"
    const val SALT_DEVICE_ID = "zo2W0qBjxUDpktqUAoaL4A=="
    const val HEADER_BSY_NET = "x-bsy-net"
    const val SCREEN_ID = "screen_id"
    const val CATEGORY = "category"
    const val OTP = "otp"
    const val KEY_APPCONFIG = "app_config"
    const val KEY_USERCONFIG = "user_config"
    const val HOOQ_CP_SUBSCRIPTION_AVAILABLE = "hooq_cp_subscription_available"
    const val PAGE_NO = "offset"
    const val PAGE_SIZE = "count"
    const val DEAFULT_PAGE_SIZE = "10"
    const val EXTRA_SERIES_ID = "seriesId"
    const val EXTRA_CHANNEL_ID = "channelId"
    const val CATCHUP = "catchup"
    const val LIVE = "live"
    const val LIVETVCHANNEL = "LIVETVCHANNEL"
    const val EXTRA_ASSET_NAME = "asset_name"
    const val EXTRA_ACTION_NAME = "action"
    const val VOD = "vod"
    const val NO_RAIL_POSITION = -1
    const val EPG_ORDER = "epg_channel_order"
    const val AIRTEL_DIGITAL_TV = "Airtel Digital Tv"


    const val emptyStr = " "

    const val FORMAT = "EEE, dd MMM"
    const val DATE_FORMAT = "MMM dd, yyyy"
    const val FORMAT_DEFAULT = "EEEE, MMM d"
    const val DEFAULT_DRAWABLE_RES_ID = -1

    interface ApiConstants {

        interface Network {
            companion object {

                const val NETWORK_NOT_CONNECTED = 0

                /* All TYPE_MOBILE* network types */
                const val NETWORK_TYPE_MOBILE = 1

                /* Could be Bluetooth, Ethernet, VPN, WiFi, WiMax */
                const val NETWORK_TYPE_OTHER = 2
            }
        }

        interface Analytics {
            companion object {
                const val META = "meta"
                const val DID = "did"
                const val UID = "uid"
                const val EVENTS = "events"
                const val EVENT_TYPE = "event_type"
                const val TIMESTAMP = "ts"
                const val LANG = "lang"
                const val ov = "ov"
                const val OS = "os"
                const val BN = "bn"
                const val NQ = "nq"
                const val NCT = "nct"
                const val LC = "lc"
                const val NT = "nt"
                const val AV = "av"
                const val DT = "dt"
            }

        }

        companion object {

            const val HEADER = "HRST"
            const val HEADER_ENCODING = "Content-Encoding"
            const val ENCODING_GZIP = "gzip"
        }

    }

    interface PanelNavigation {
        companion object {
            const val LISTING = "LISTING"
            const val LANDING = "LANDING"
            const val DETAILS = "DETAILPAGE"
            const val AUTO_PLAY = "AUTOPLAY"
            const val SUBSCRIPTION = "SUBSCRIPTION"
            const val POPUP_SUBSCRIBE = "POPUPSUBSCRIBE"
            const val LIVE_TV = "LIVETV"
            const val PLAY = "PLAY"
            const val CUSTOM_AMAZON = "CUSTOM_AMAZON"
        }
    }

    interface FilterLabels {
        companion object {
            const val LANGUAGE = "language"
            const val GENRES = "genres"
            const val RATING = "rating"
            const val CHANNEL = "channel"
            const val SORTBY = "sortby"
        }
    }

    const val FILTER_CATEGORIES_PREFIX = "filter_categories_"

    interface FilterTabs {
        companion object {
            const val MOVIE = "movie"
            const val SHORTS = "shorts"
            const val TVSHOWS = "tvshows"
        }
    }

    interface StreamingError {
        companion object {
            const val ATV201 = "ATV201"
            const val ATV202 = "ATV202"
            const val ATV203 = "ATV203"
            const val ATV204 = "ATV204"
            const val ATV205 = "ATV205"
        }
    }

    interface ReqCode {
        companion object {
            const val AIRTEL_SIGN_IN_ACTIVITY = 300
            const val ACTIVITY_UPDATE_PROFILE = 301
            const val FAV_AIRTEL_SIGN_IN_ACTIVITY = 302
            const val UNFAV_AIRTEL_SIGN_IN_ACTIVITY = 305
            const val REPORT_AIRTEL_SIGN_IN_ACTIVITY = 303
            const val OPEN_SUBSCRIPTION_PAGE = 15
            const val BUNDLE_LIMIT_REACHED = 16
            const val FETCH_LAST_WATCHDED_TIME = 304
            const val FETCH_HOTSTAR_CONTENT = 305
        }
    }

    interface ResCode {
        companion object {
            const val OPEN_SUBSCRIPTION_PAGE_RESULT = 1000
        }
    }

    interface CrashlyticsKeys {
        companion object {
            const val DEVICE_ID = "device_id"
            const val CONTENT_INFO = "content_info"
        }
    }

    interface PackageNames {
        companion object {
            const val AMAZON = "com.amazon.avod.thirdpartyclient"
        }
    }

    interface Layout {
        companion object {
            const val GRID_COLUMN_COUNT = 3
            const val GRID_COLUMN_COUNT_TAB = 6
        }
    }

    interface AltDrm {
        companion object {
            const val OK = "ok"
            const val STATUS = "status"
            const val ERROR = "error"
            const val LICENSE = "license"
            const val INVALID_LICENSE_CHALLENGE = "INVALID_LICENSE_CHALLENGE"
            const val CODE = "code"
            const val MESSAGE = "message"
            const val ERRORS = "errors"
            const val STATUS_MESSAGE = "status_message"
            const val SUPPORTED_TRACKS = "supported_tracks"
            const val CLIENT_INFO = "client_info"
            const val UNKNOWN_ERROR_CODE = 251
            const val INVALID_LICENSE_CHALLENGE_ERROR_CODE = 401
            const val DEFAULT_ERROR_MSG = "Unable to Download license for the content"
        }
    }

    object ContentType {
        const val CHANNEL = "channel"
        const val MOVIE = "movie"
        const val SEASON = "season"
        const val SHORT_MOVIE = "shortmovie"
        const val VIDEO = "video"
        const val EPISODE = "episode"
        const val SERIES = "series"
        const val SPORTS = "sports"
        const val TVSHOW = "tvshow"
        const val OTHER = "other"
        const val PEOPLE = "people"
        const val CATCHUP = "catchup"
        const val LIVETV = "livetv"
        const val LIVE = "live"
        const val LIVETVSHOW = "livetvshow"
        const val LIVETVCHANNEL = "livetvchannel"
        const val LIVETVMOVIE = "livetvmovie"
    }

    object AppIds {
        const val WYNK_MUSIC_PACKAGE_ID = "com.bsbportal.music"
        const val PRIME_TIME_PACKAGE_ID = "com.airtel.primetime"
        const val PRIME_TIME_SAMPLE_PACKAGE_ID = "com.airtel.sample"
        const val MITRA_APP_PACKAGE_ID = "com.airtel.agilelabs.retailerapp"
//        todo : Put actual package names here
        const val APP_SDK_ID = "com.airtel.primetime0"
        const val APP_XTREME_ID = "tv.airtel.smartstick"
        const val APP_MOBILITY_ID = "com.airtel.primetime2"
        const val APP_SAMPLE = "tv.airtel.visionsample"
    }





    /////

    const val FREE_CONTENT_PRICE_TYPE = "FREE"
    const val DIRECTOR = "director"
    const val ACTOR = "actor"

    const val contentId = "contentId"
    const val reportingAction = "action"
    const val isMax = "ismax"
    const val HEADER_DATA_SOURCE = "data_source"
    const val HEADER_FORCE_REFRESH = "force_refresh"
    const val LANG = "lang"
    const val SUB_CP = "sub_cp"
    const val LASTWATCHEDPOSITION = "lastWatchedPosition"
    const val PAGEID = "pageid"
    const val FORCEUPDATE = "forceupdate"
    const val CONTENTID = "contentid"
    const val ISMAX = "ismax"
    const val BASEROW = "baserow"
    const val CATCH_UP_DATA = "catchup_data"
    const val KEY_PAGE_SIZE = "pageSize"
    const val KEY_PAGE_NO = "offset"
    const val ASC = "title_asc"
    const val PRODUCTID = "productId"
    const val PACKID = "packId"
    const val TRANSACTIONEVENT = "transactionEvent"
    const val VALIDTILLDATE = "validTillDate"
    const val TRANSACTIONSTATUS = "transactionStatus"
    const val LIVE_TV_CONSTANT = "2"
    const val CATCHUP_TV_CONSTANT = "4"
}
