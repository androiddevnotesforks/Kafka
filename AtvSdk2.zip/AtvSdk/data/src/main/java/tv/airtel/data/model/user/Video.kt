package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class Video(

    @SerializedName("thumb_url")
    @Expose
    val thumbUrl: String,
    @SerializedName("video_title")
    @Expose
    val videoTitle: String,
    @SerializedName("playback_url")
    @Expose
    val playbackUrl: String,
    @SerializedName("video_id")
    @Expose
    val videoId: String
)