package tv.airtel.data.model.content

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.model.layout.RowSubType
import java.io.Serializable

data class Meta(
    @SerializedName("isDth")
    @Expose
    var isDth: Boolean = false,

    @SerializedName("cpId")
    @Expose
    var cpId: String? = null,

    @SerializedName("redirectType")
    @Expose
    var redirectType: String? = null,

    @SerializedName("railType")
    @Expose
    var railTypeString: String = "",

    @SerializedName("cardTitle")
    @Expose
    var cardTitle: String? = null,

    @SerializedName("cardIcon")
    @Expose
    var cardIcon: String? = null,

    @SerializedName("showPopup")
    @Expose
    var showPopup: Boolean = false,

    @SerializedName("longDescription")
    @Expose
    var longDescription: String? = null,

    @SerializedName("seperator")
    @Expose
    var seperator: String? = null,

    @SerializedName("packId")
    @Expose
    var packId: String? = null) : Serializable {

    fun getRailType() : RowSubType {
        return try {
            RowSubType.valueOf(railTypeString)
        } catch (e: Exception) {
            RowSubType.TVSHOW_LOGO_43
        }
    }
}
