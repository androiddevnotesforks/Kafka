package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.model.user.profile.ContactUs

/**
 * Author : Akash Gupta
 * Created On : 17/04/19
 *
 */
data class XstreamPlans(

        @SerializedName("title")
        @Expose
        var title: String? = "",

        @SerializedName("monthlyPrice")
        @Expose
        var monthlyPrice: String? = "",

        @SerializedName("annualPrice")
        @Expose
        var annualPrice: String? = "",

        @SerializedName("description")
        @Expose
        var description: String? = "",

        @SerializedName("cparray")
        @Expose
        var cparray: List<CpDetails>?
)