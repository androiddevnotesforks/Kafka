package tv.airtel.data.model.content.related

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

@Entity
data class RelatedContent (
    @PrimaryKey
    @SerializedName("id")
    @Expose
    var id: String = "",
    @SerializedName("PLAYABLE_CONTENT")
    @Expose
    var relatedContentDetailsEntity: RelatedContentDetailsEntity? = null
)