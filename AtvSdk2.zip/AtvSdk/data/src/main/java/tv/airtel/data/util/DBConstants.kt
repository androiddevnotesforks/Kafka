package tv.airtel.data.util

/**
 * Created by Harsh Jain on 14/02/19.
 */
object DBConstants {
    const val CURRENT_DB_VERSION = 16
    const val DB_NAME = "middleware.db"
}
