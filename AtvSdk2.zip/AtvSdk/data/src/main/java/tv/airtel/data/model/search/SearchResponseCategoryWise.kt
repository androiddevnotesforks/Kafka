package tv.airtel.data.model.search

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

@Entity
data class SearchResponseCategoryWise(
        @PrimaryKey
        var id: String = "",
        var keyword: String = "",
        var source: String = "",
        @SerializedName("totalResults") @Expose var totalResults: Int = 0,
        @SerializedName("categories") @Expose var searchCategories: List<SearchCategoryEntity>? = null
) {
    fun setSearchId(keyword: String, source: String) {
        id = "$keyword:$source"
        this.keyword = keyword
        this.source = source
    }
}
