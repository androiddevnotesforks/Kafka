package tv.airtel.data.manager

import android.support.v4.util.SimpleArrayMap

import java.util.HashMap

import tv.airtel.data.model.user.CpDetails
import tv.airtel.data.model.user.CurrentUser
import tv.airtel.data.model.user.Subscription
import tv.airtel.data.utilmodule.CommonConstants

import tv.airtel.data.model.user.CurrentUser.*

/**
 * Created by Ashwani Janghu on 29/09/17.
 */
object CPManager {

    private val cpConditions = HashMap<String, CPConditions>()
    private val cpStatus = HashMap<String, CPSubState>()

    interface CPType {
        companion object {
            val EXTERNAL = "EXTERNAL"
            val INTERNAL = "INTERNAL"
            val UNKNOWN = "UNLNOWN"
        }
    }

    //ADO may exist else where also in APP, so may be redundant constants we will figure this out later
    interface CP {
        companion object {
            val SONY_LIV_MOVIES = "SONY_LIV_MOVIES"
            val SONY_LIV_SHOWS = "SONY_LIV_SHOWS"
            val EROS_NOW = "EROSNOW"
            val YOUTUBE = "YOUTUBE"
            val HOOQ = "HOOQ"
            val AIRTEL = "AIRTEL"
            val HUAWEI = "HUAWEI"
            val AMAZON = "AMAZON"
            val SONYLIV = "SONYLIV"
            val HOTSTAR = "HOTSTAR"
            val FASTFILMZ = "FASTFILMZ"
            val MWTV = "MWTV"
            val ALTBALAJI = "ALTBALAJI"
        }
    }

    //Some dumb english by me, if the Writer in You is awake beautify it.
    interface CPStateMsg {
        companion object {
            val MSG_CP_UNKNOWN = "CP subscription is not available"
            val MSG_LOGIN_UNKNOWN = "No User Login found"
            val MSG_LOGIN_NO_EMAIL = "No Email found for this User"
            val MSG_WCF_EXPIRED_NO_EMAIL = "WCF validity is expired & No Email found for this User"
            val MSG_WCF_EXPIRED = "WCF validity is expired"
            val MSG_CP_EXPIRED_NO_EMAIL = "CP is expired & No Email found for this User"
            val MSG_CP_EXPIRED = "CP validity is expired"
            val MSG_CP_NOT_SUBSCRIBED = "CP is available to subscribe"
            val MSG_VALID = "CP is valid to access content"
        }
    }

    enum class CPSubState private constructor(id: String) {
        CP_UNKNOWN(CPStateMsg.MSG_CP_UNKNOWN),
        LOGIN_UNKNOWN(CPStateMsg.MSG_LOGIN_UNKNOWN),
        WCF_EXPIRED_NO_EMAIL(CPStateMsg.MSG_WCF_EXPIRED_NO_EMAIL),
        WCF_EXPIRED(CPStateMsg.MSG_WCF_EXPIRED),
        CP_EXPIRED_NO_EMAIL(CPStateMsg.MSG_CP_EXPIRED_NO_EMAIL),
        CP_EXPIRED(CPStateMsg.MSG_CP_EXPIRED),
        CP_NOT_SUBSCRIBED(CPStateMsg.MSG_CP_NOT_SUBSCRIBED),
        LOGIN_NO_EMAIL(CPStateMsg.MSG_LOGIN_NO_EMAIL),
        VALID(CPStateMsg.MSG_VALID);

        var msg: String
            internal set

        init {
            this.msg = id
        }
    }

    enum class ContentIconState {
        Rupee,
        Play
    }

    private class CPConditions internal constructor(internal var loginState: LOGIN_STATE,
                                                    internal var cpExpiryCheck: Boolean,
                                                    internal var wcfExpiryCheck: Boolean,
                                                    internal var defaultCpState: CPSubState,
                                                    internal var type: String,
                                                    internal var redirectUrl: String?)

    fun loadCPConditions(cpDetailsList: List<CpDetails>) {

        val iterator = cpDetailsList.iterator()

        while (iterator.hasNext()) {
            val cpDetails = iterator.next()
            cpConditions[cpDetails.title] =
                    CPConditions(cpDetails.loginState, cpDetails.cpExpiryCheck,
                            cpDetails.wcfExpiryCheck, cpDetails.state, cpDetails.type,
                            cpDetails.redirectionUrl)
        }
    }

    fun isCPTypeExternal(cpName: String): Boolean {
        cpConditions[cpName]?.let {
            return (it.type == CPType.EXTERNAL)
        }

        return false
    }

    fun getCPRedirectURL(cpName: String): String {
        cpConditions[cpName]?.redirectUrl?.let {
            return it
        }

        return ""
    }

    internal fun getSubscriptionMap(subscriptions: List<Subscription>): SimpleArrayMap<String, Subscription> {

        val subscriptionMap = SimpleArrayMap<String, Subscription>()
        for (subscription in subscriptions) {

            subscriptionMap.put(subscription.cp, subscription)
        }
        return subscriptionMap
    }

    /**
     * Method that updates CP Status every time whenever UserConfig is altered.
     * Order is Email -> WCF -> CP
     * WCF wcfExpiry is used to determine whether Play Icon or Rupee symbol
     *
     * @param currentUser
     */
    fun setCPSubscriptionData(currentUser: CurrentUser) {

        val iterator = cpConditions.entries.iterator()

        val subscriptionMap = if (currentUser.subscriptions != null)
            getSubscriptionMap(currentUser.subscriptions!!)
        else
            SimpleArrayMap()

        while (iterator.hasNext()) {
            val entry = iterator.next()
            val cp = entry.key
            val cpCon = entry.value
            var sub: Subscription? = null
            if (CP.SONY_LIV_MOVIES.equals(cp, ignoreCase = true) || CP.SONY_LIV_SHOWS.equals(cp, ignoreCase = true)) {
                sub = subscriptionMap.get(CP.SONYLIV)
            } else {
                sub = subscriptionMap.get(cp)
            }

            if (sub != null) {
                if (cpCon != null) {
                    if (cpCon.loginState.ordinal <= currentUser.getLoginState().ordinal) {
                        if (cpCon.wcfExpiryCheck) {
                            var currTime = System.currentTimeMillis()
                            if (sub.wcfExpiry - currTime > 0) {
                                if (cpCon.cpExpiryCheck) {
                                    currTime = System.currentTimeMillis()
                                    if (sub.cpExpiry - currTime > 0) {
                                        cpStatus[cp] = CPSubState.VALID
                                    } else {
                                        cpStatus[cp] = CPSubState.CP_EXPIRED
                                    }
                                } else {
                                    cpStatus[cp] = CPSubState.VALID
                                }
                            } else {
                                cpStatus[cp] = CPSubState.WCF_EXPIRED
                            }
                        } else {
                            if (cpCon.cpExpiryCheck) {
                                val currTime = System.currentTimeMillis()
                                if (sub.cpExpiry - currTime > 0) {
                                    cpStatus[cp] = CPSubState.VALID
                                } else {
                                    cpStatus[cp] = CPSubState.CP_EXPIRED
                                }
                            } else {
                                cpStatus[cp] = CPSubState.VALID
                            }
                        }
                    } else {
                        if (cpConditions[cp]?.loginState === CurrentUser.LOGIN_STATE.MOBILE_ONLY) {
                            cpStatus[cp] = CPSubState.LOGIN_UNKNOWN
                        } else {
                            if (cpCon.wcfExpiryCheck) {
                                var currTime = System.currentTimeMillis()
                                if (sub.wcfExpiry - currTime > 0) {
                                    if (cpCon.cpExpiryCheck) {
                                        currTime = System.currentTimeMillis()
                                        if (sub.cpExpiry - currTime > 0) {
                                            cpStatus[cp] = CPSubState.LOGIN_NO_EMAIL
                                        } else {
                                            cpStatus[cp] = CPSubState.CP_EXPIRED_NO_EMAIL
                                        }
                                    } else {
                                        cpStatus[cp] = CPSubState.LOGIN_NO_EMAIL
                                    }
                                } else {
                                    cpStatus[cp] = CPSubState.WCF_EXPIRED_NO_EMAIL
                                }
                            } else {
                                if (cpCon.cpExpiryCheck) {
                                    val currTime = System.currentTimeMillis()
                                    if (sub.cpExpiry - currTime > 0) {
                                        cpStatus[cp] = CPSubState.LOGIN_NO_EMAIL
                                    } else {
                                        cpStatus[cp] = CPSubState.CP_EXPIRED_NO_EMAIL
                                    }
                                } else {
                                    cpStatus[cp] = CPSubState.VALID
                                }
                            }
                        }
                    }
                } else {
                    println("$cp is not not configured in CP Manager")
                }
            } else {
                println("$cp has no Subscription info from Server")
                if (cpCon.defaultCpState == CPSubState.CP_NOT_SUBSCRIBED) {
                    if (cpCon.loginState.ordinal <= currentUser.getLoginState().ordinal) {
                        cpStatus[cp] = CPSubState.WCF_EXPIRED
                    } else {
                        if (currentUser.getLoginState().ordinal < LOGIN_STATE.MOBILE_ONLY.ordinal) {
                            cpStatus[cp] = CPSubState.LOGIN_UNKNOWN
                        } else if (cpConditions[cp]?.loginState === LOGIN_STATE.MOBILE_ONLY) {
                            cpStatus[cp] = CPSubState.WCF_EXPIRED
                        } else {
                            cpStatus[cp] = CPSubState.WCF_EXPIRED_NO_EMAIL
                        }
                    }
                } else {
                    cpStatus[cp] = cpCon.defaultCpState
                }

            }
        }
        println("CP Status map is : $cpStatus")
    }

    fun isPlaybackValid(cp: String, programType: String, isFreeContent: Boolean, loginState: LOGIN_STATE): Boolean {
        var cp = cp
        if (CP.SONYLIV.equals(cp, ignoreCase = true)) {
            when (programType.toLowerCase()) {
                CommonConstants.ContentType.SERIES, CommonConstants.ContentType.TVSHOW, CommonConstants.ContentType.EPISODE ->

                    cp = CP.SONY_LIV_SHOWS
                CommonConstants.ContentType.MOVIE -> cp = CP.SONY_LIV_MOVIES
            }
        }
        val retState = cpStatus[cp]
        if (isFreeContent) {
            val cpCon = cpConditions[cp]
            return if (cpCon != null) {
                if (cpCon.loginState.ordinal <= loginState.ordinal) {
                    if (retState == CPSubState.CP_EXPIRED || retState == CPSubState.CP_EXPIRED_NO_EMAIL
                            || retState == CPSubState.CP_NOT_SUBSCRIBED) {
                        false
                    } else true
                } else {
                    false
                }
            } else {
                false
            }
        }

        return retState == CPSubState.VALID
    }

    fun getCPState(cp: String, programType: String, isFreeContent: Boolean, loginState: LOGIN_STATE): CPSubState? {
        var cp = cp
        if (CP.SONYLIV.equals(cp, ignoreCase = true)) {
            when (programType.toLowerCase()) {
                CommonConstants.ContentType.SERIES, CommonConstants.ContentType.TVSHOW, CommonConstants.ContentType.EPISODE -> cp = CP.SONY_LIV_SHOWS
                CommonConstants.ContentType.MOVIE -> cp = CP.SONY_LIV_MOVIES
            }
        }
        if (cpStatus.size == 0) {
            return CPSubState.LOGIN_UNKNOWN
        } else if (cpStatus[cp] == null) {
            return CPSubState.CP_UNKNOWN
        }

        var retState = cpStatus[cp]

        if (isFreeContent) {
            val cpCon = cpConditions[cp]
            if (cpCon != null) {
                if (cpCon.loginState.ordinal <= loginState.ordinal) {
                    if (!(retState == CPSubState.CP_EXPIRED || retState == CPSubState.CP_EXPIRED_NO_EMAIL
                                    || retState == CPSubState.CP_NOT_SUBSCRIBED)) {
                        retState = CPSubState.VALID
                    }
                } else {
                    if (cpCon.loginState === LOGIN_STATE.MOBILE_ONLY) {
                        retState = CPSubState.LOGIN_UNKNOWN
                    } else {
                        retState = CPSubState.LOGIN_NO_EMAIL
                    }
                }
            } else {
                retState = CPSubState.LOGIN_UNKNOWN
            }
        }
        return retState
    }

    fun getIconState(cp: String, programType: String, isFreeContent: Boolean, loginState: LOGIN_STATE): ContentIconState {
        var iconState = ContentIconState.Play
        val cpSubState = getCPState(cp, programType, isFreeContent, loginState)
        when (cpSubState) {
            CPManager.CPSubState.CP_EXPIRED, CPManager.CPSubState.CP_EXPIRED_NO_EMAIL, CPManager.CPSubState.CP_NOT_SUBSCRIBED -> iconState = ContentIconState.Play
            CPManager.CPSubState.LOGIN_NO_EMAIL, CPManager.CPSubState.VALID -> iconState = ContentIconState.Play
            CPManager.CPSubState.CP_UNKNOWN, CPManager.CPSubState.LOGIN_UNKNOWN, CPManager.CPSubState.WCF_EXPIRED, CPManager.CPSubState.WCF_EXPIRED_NO_EMAIL -> if (isFreeContent) {
                iconState = ContentIconState.Play
            } else {
                iconState = ContentIconState.Rupee
            }
            else -> iconState = ContentIconState.Play
        }
        return iconState
    }

    fun resetCPStatus() {
        cpStatus.clear()
    }
}
