package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Author : Akash Gupta
 * Created On : 14/06/18
 *
 */
data class Page(
        @SerializedName("id")
        @Expose
        var id: String = "",
        @SerializedName("title")
        @Expose
        var title: String = "",
        @SerializedName("icon")
        @Expose
        var icon: String = "",
        @SerializedName("index")
        @Expose
        var index: Int = 0,
        @SerializedName("type")
        @Expose
        var type: String = ""
)
