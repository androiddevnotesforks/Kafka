package tv.airtel.data.model.content.recentfavorite

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Embedded
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.SerializedName

/**
 * Author : Akash Gupta
 * Created On : 08/08/18
 *
 */

@Entity
class RecentFavoriteEntity {

    @PrimaryKey(autoGenerate = false)
    var _id: String = ""
        get() =
            contentDetails?.id?:""

    @SerializedName("contentResponse")
    @Embedded
    var contentDetails: RecentContentDetails? = null

    @ColumnInfo(name = "last_watch_position")
    var lastWatchedPosition: Double = -1.0

    @ColumnInfo(name = "favorite")
    var fav: Boolean = false

    @ColumnInfo(name = "recent")
    var recent: Boolean = false

    @ColumnInfo(name = "last_updated_time_stamp")
    @SerializedName("lastUpdatedTimeStamp")
    var lastUpdatedTimeStamp: Long = 0

    @ColumnInfo(name = "is_favorite_synced")
    var isFavoriteSynced: Boolean = false

    @ColumnInfo(name = "is_recent_synced")
    var isRecentSynced: Boolean = false
}