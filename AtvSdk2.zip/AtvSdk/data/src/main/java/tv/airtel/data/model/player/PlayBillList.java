package tv.airtel.data.model.player;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by A1171IVZ on 9/1/2016.
 */

public class PlayBillList implements Serializable, Comparable<PlayBillList> {


    public String id;

    public String name;

    public String channelid;

    public String starttime;

    public String endtime;

    public int istvod;

    public String foreignSn;


    public Picture picture;

    public int episodeNumber;

    public String introduce;

    public String programType;

    public List<ExtensionInfo> extensionInfo = new ArrayList<>();
    private List<CastInfo> castInfo = new ArrayList<>();

    public String seriesID;

    public String genres;

    public String cpId;

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getChannelid() {
        return channelid;
    }

    public String getStarttime() {
        return starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public boolean isCatchupSupported() {
        return istvod == 1;
    }

    public Picture getPicture() {
        return picture;
    }

    public Integer getEpisodeNumber() {
        return episodeNumber;
    }

    public String getProgramType() {
        return programType;
    }

    public List<ExtensionInfo> getExtensionInfo() {
        return extensionInfo;
    }

    public String getSeriesID() {
        return seriesID;
    }

    public String getIntroduce() {
        return introduce;
    }

    public String getGenres() {
        return genres;
    }

    public String getForeignSn() {
        return foreignSn;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setChannelid(String channelid) {
        this.channelid = channelid;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public void setIstvod(int istvod) {
        this.istvod = istvod;
    }

    public void setForeignSn(String foreignSn) {
        this.foreignSn = foreignSn;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }

    public void setEpisodeNumber(int episodeNumber) {
        this.episodeNumber = episodeNumber;
    }

    public void setIntroduce(String introduce) {
        this.introduce = introduce;
    }

    public void setProgramType(String programType) {
        this.programType = programType;
    }

    public void setExtensionInfo(List<ExtensionInfo> extensionInfo) {
        this.extensionInfo = extensionInfo;
    }

    public void setSeriesID(String seriesID) {
        this.seriesID = seriesID;
    }

    public void setGenres(String genres) {
        this.genres = genres;
    }

    public void setCpId(String cpId) {
        this.cpId = cpId;
    }

    public List<CastInfo> getCastInfo() {
        return castInfo;
    }

    public void setCastInfo(List<CastInfo> castInfo) {
        this.castInfo = castInfo;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (o instanceof PlayBillList) {
            PlayBillList ob = (PlayBillList) o;
            return this.id.equalsIgnoreCase(ob.id);
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return this.episodeNumber + this.channelid.hashCode();
    }


    @Override
    public int compareTo(PlayBillList o) {
        if (this.episodeNumber > o.episodeNumber)
            return -1;
        else if (this.episodeNumber == o.episodeNumber)
            return 0;
        else
            return 1;
    }


    public PlayBillList() {
    }

}
