package tv.airtel.data.model.search

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class SearchCategoryWiseRequestModel(
        @SerializedName("keyword") @Expose var keyword: String = "",
        @SerializedName("subscribedOnly") @Expose var subscribedOnly: Boolean = false,
        @SerializedName("language") @Expose var language: String = "",
        @SerializedName("moreListing") @Expose var more: Boolean = false,
        @SerializedName("offset") @Expose var offset: Int = 0,
        @SerializedName("count") @Expose var count: Int = 0,
        @SerializedName("superType") @Expose var superType: String = "",
        @SerializedName("source") @Expose var source: String = ""
)