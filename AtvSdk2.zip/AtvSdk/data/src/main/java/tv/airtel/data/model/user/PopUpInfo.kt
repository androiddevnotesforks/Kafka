package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class PopUpInfo(

        @SerializedName("preTitle") @Expose var preTitle: String? = null,

        @SerializedName("title") @Expose var title: String? = null,

        @SerializedName("subtitle") @Expose var subtitle: String? = null,

        @SerializedName("content") @Expose var content: String? = null,

        @SerializedName("subSubTitle") @Expose var subSubTitle: String? = null,

        @SerializedName("dontShowAgainFeature") @Expose var dontShowAgainFeature: Boolean? = null,

        @SerializedName("dismissable") @Expose var dismissible: Boolean? = null,

        @SerializedName("iconUrl") @Expose var iconUrl: String? = null,

        @SerializedName("footerText") @Expose var footerText: String? = null,

        @SerializedName("footerImage") @Expose var footerImage: String? = null,

        @SerializedName("image") @Expose var bgImage: String? = null,

        @SerializedName("frequency") @Expose var frequency: Int = 0,

        @SerializedName("entityType") @Expose var entityType: String? = null,

        @SerializedName("body") @Expose var body: String? = null,

        @SerializedName("addUnit") @Expose var adUnit: Boolean = false,

        @SerializedName("cta") @Expose var cta: PopUpCtaInfo? = null,

        @SerializedName("popUpType") @Expose var popUpType: String? = null,

        @SerializedName("descriptionItemList") @Expose var rechBenefitDescList: List<RechargeBenefit>? = null
)