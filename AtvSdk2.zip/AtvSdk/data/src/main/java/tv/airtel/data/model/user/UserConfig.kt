package tv.airtel.data.model.user

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.model.user.plan.PlansEntity
import java.util.*

@Entity
data class UserConfig(
        @PrimaryKey
        var id: String = "",
        @SerializedName("subscriptions")
        @Expose
        var subscriptions: List<Subscription>? = null,
        @SerializedName("eligibleOffers")
        @Expose
        var eligibleOffers: List<EligibleOffer>? = null,
        @SerializedName("availablePlans")
        @Expose
        var plansEntity: List<PlansEntity>? = null,
        @SerializedName("userProperties")
        @Expose
        var userProperties: HashMap<String, String>? = null,
        @SerializedName("userContentProperties")
        @Expose
        var userContentProperties: HashMap<String, String>? = null,
        @SerializedName("userInfo")
        @Expose
        var userInfo: UserInfo? = null,
        @SerializedName("langInfo")
        @Expose
        var langInfo: List<String>? = null,
        @SerializedName("htoken")
        @Expose
        var htoken: String? = null,
        @SerializedName("customerType")
        @Expose
        var customerType: String? = null,
        @SerializedName("lastSyncTime")
        @Expose
        var lastSyncTime: Long? = -1,

        @SerializedName("appNotifications")
        @Expose
        var appNotificationsEntity: HashMap<String, PopUpInfo>? = null,

        @SerializedName("eligiblePopId")
        @Expose
        var eligiblePopId: List<String>? = null,

        @SerializedName("xclusivePlanURL")
        @Expose
        var xclusivePlanURL: String? = null

)