package tv.airtel.data.model.content.apps

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey

@Entity
data class AppEntity(
    @PrimaryKey
    @ColumnInfo(name = "packageId")
    var packageId: String,

    @ColumnInfo(name = "label")
    var label: String? = null,

    @ColumnInfo(name = "isSystemApp")
    var isSystemApp: Boolean,

    @ColumnInfo(name = "isFeaturedApp")
    var isFeaturedApp: Boolean,

    @ColumnInfo(name = "isGoogleApp")
    var isGoogleApp: Boolean,

    @ColumnInfo(name = "isGame")
    var isGame: Boolean = false,

    @ColumnInfo(name = "lastUsedTime")
    var lastUsedTime: Long = 0,

    @ColumnInfo(name = "versionName")
    var versionName: String? = null,

    @ColumnInfo(name = "versionCode")
    var versionCode: String? = null,

    @ColumnInfo(name = "iconUrl")
    var iconUrl: String? = null,

    @ColumnInfo(name = "bannerUrl")
    var bannerUrl: String? = null,

    @ColumnInfo(name = "order")
    var order: Int = 0
)
