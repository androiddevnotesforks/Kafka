package tv.airtel.data.model.layout

enum class RowType {
    CARD,
    BANNER,
    RAIL,
    UNKNOWN
}
