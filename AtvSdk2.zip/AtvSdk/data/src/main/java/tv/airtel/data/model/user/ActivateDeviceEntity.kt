package tv.airtel.data.model.user

import android.arch.persistence.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Author : Akash Gupta
 * Created On : 16/08/18
 *
 */
data class ActivateDeviceEntity(
        @SerializedName("txnId")
        @Expose
        var txnId: String? = "",
        @SerializedName("pin")
        @Expose
        var pin: String? = "",
        @SerializedName("uid")
        @Expose
        @PrimaryKey
        var uid: String = "",
        @SerializedName("token")
        @Expose
        var token: String? = "",
        @SerializedName("ttl")
        @Expose
        var ttl: Long = 900000,
        @SerializedName("fq")
        @Expose
        var fq: Long = 5)