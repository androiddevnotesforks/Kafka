package tv.airtel.data.model.content.detail

import android.arch.persistence.room.Entity
import android.arch.persistence.room.Relation
import android.arch.persistence.room.TypeConverters
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.db.MiddlewareTypeConverters

import tv.airtel.data.model.content.ContentDetail

/**
 * This class represents season detail
 * Naming is done in accordance to backend  api.
 */
data class EpisodeDetail(
    @SerializedName("episodeRefs")
    @Expose
//    @TypeConverters(MiddlewareTypeConverters.EpisodeListTypeConverters::class)
    @Relation(parentColumn = "id",entityColumn = "seasonId")
    var episodes: MutableList<Episode>? = null
) : EpisodeDetailCache()