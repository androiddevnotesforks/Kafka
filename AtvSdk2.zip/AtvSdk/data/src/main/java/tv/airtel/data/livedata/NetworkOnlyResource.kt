package tv.airtel.data.livedata

import android.arch.lifecycle.LiveData
import android.support.annotation.MainThread
import android.support.annotation.WorkerThread
import tv.airtel.data.api.model.ApiResponse
import tv.airtel.data.api.model.AppExecutors
import tv.airtel.data.api.model.Resource

/**
 * A generic class that can provide a resource backed by both the sqlite database and the network.
 *
 *
 * You can read more about it in the [Architecture
 * Guide](https://developer.android.com/arch).
 * @param <ResultType>
 * @param <RequestType>
</RequestType></ResultType> */
abstract class NetworkOnlyResource<ResultType> @MainThread
internal constructor(private val appExecutors: AppExecutors) : NetworkResource<ResultType, ResultType>(appExecutors) {

    init {
        setValue(Resource.loading(null))
        fetchFromNetwork()
    }

    private fun fetchFromNetwork() {
        val apiResponse = createCall()
        result.addSource(apiResponse) { response ->
            result.removeSource(apiResponse)

            if (response?.isSuccessful!!) {
                appExecutors.diskIO().execute {
                    saveCallResult(processResponse(response)!!)
                    appExecutors.mainThread().execute {
                        result.addSource(apiResponse) { newData -> setValue(Resource.success(newData?.body)) }
                    }
                }
            } else {
                onFetchFailed()
                result.addSource(apiResponse) { newData ->
                    //                    setValue(Resource.error(Error.build(Error.ErrorValue.ERROR_NETWORK_ERROR,
//                            response.code, response.errorMessage), newData?.body))
                    setValue(Resource.error(response.atvError, newData?.body))
                }
            }
        }
    }

    @WorkerThread
    protected fun processResponse(response: ApiResponse<ResultType>?): ResultType? {
        return response?.body
    }

    @WorkerThread
    open fun saveCallResult(entity: ResultType) {

    }

    @MainThread
    protected abstract fun createCall(): LiveData<ApiResponse<ResultType>>
}
