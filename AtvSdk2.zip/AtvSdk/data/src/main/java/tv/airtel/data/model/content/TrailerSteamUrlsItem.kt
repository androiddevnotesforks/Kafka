package tv.airtel.data.model.content

import com.google.gson.annotations.SerializedName

data class TrailerSteamUrlsItem(
    @SerializedName("type")
    var type: String? = null,
    @SerializedName("url")
    var url: String? = null
)
