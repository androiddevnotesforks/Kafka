package tv.airtel.data.model.content

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class TrailerSteamUrl (

    @SerializedName("url")
    @Expose
    var url: String? = null,

    @SerializedName("type")
    @Expose
    var type: String? = null): Serializable
