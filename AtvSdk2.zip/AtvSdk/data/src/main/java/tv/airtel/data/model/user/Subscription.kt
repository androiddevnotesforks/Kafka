package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class Subscription (
    @SerializedName("productId")
    @Expose
    var productId: String? = null,
    @SerializedName("expiry")
    @Expose
    var wcfExpiry: Long = 0,
    @SerializedName("cpExpiry")
    @Expose
    var cpExpiry: Long = 0,
    @SerializedName("cp")
    @Expose
    var cp: String? = null,
    @SerializedName("meta")
    @Expose
    var meta: Meta? = null,
    @SerializedName("partnerProductId")
    @Expose
    var partnerProductId: String? = null,
    @SerializedName("subState")
    @Expose
    var subState: String? = null,
    var isDTH: Boolean = false
)