package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Created by Ashwani on 30/10/18.
 */
data class LanguageMap (

        @SerializedName("lan")
        @Expose
        var lanCode: String = "",
        @SerializedName("rn")
        @Expose
        var localName: String = "",
        @SerializedName("n")
        @Expose
        var englishName: String = ""
)