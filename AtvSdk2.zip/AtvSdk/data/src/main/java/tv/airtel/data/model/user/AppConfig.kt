package tv.airtel.data.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import tv.airtel.data.model.user.profile.ContactUs

/**
 * Created by Udit on 02/10/17.
 */
data class AppConfig(

    var id: String = "",
    @SerializedName("voucherUrl")
    @Expose
    var voucherUrl: String? = null,

    @SerializedName("default_api_interval")
    @Expose
    var defaultApiInterval: Int = 0,

    @SerializedName("versionConfig")
    @Expose
    var appVersion: AppVersion? = null,

    @SerializedName("update_metadata_interval")
    @Expose
    var updateMetadataInterval: Int = 0,

    @SerializedName("pages")
    @Expose
    var pages: List<Page>? = null,

    @SerializedName("user_config_interval")
    @Expose
    var userConfigInterval: Int = 0,

    @SerializedName("syncRecentFrequency")
    @Expose
    var syncRecentFrequency: Int = 0,

    @SerializedName("promoChannelPkg")
    @Expose
    var promoChannelPkg: String? = null,

    @SerializedName("promoTVPkg")
    @Expose
    var promoTVPkg: String? = null,

    @SerializedName("promoMusicPkg")
    @Expose
    var promoMusicPkg: String? = null,

    @SerializedName("sta_url")
    @Expose
    var staUrl: String? = null,

    @SerializedName("fuConfig")
    @Expose
    var fuConfig: FairUsageConfig = FairUsageConfig(1, 3600),

    @SerializedName("language_map")
    @Expose
    var languageMap: List<LanguageMap>? = null,

    @SerializedName("max_profile")
    @Expose
    var maxProfiles: Int = 5,

    @SerializedName("contact_us")
    @Expose
    var contactUs: ContactUs? = null,

    @SerializedName("faq_data")
    @Expose
    var faqUrl: String? = null,

    @SerializedName("help_video")
    @Expose
    var helpVideoUrl: String? = null,

    @SerializedName("cpDetails")
    @Expose
    var cpDetailsList: List<CpDetails>?,

    @SerializedName("addRecentEpisodeMinTimeLeftLimit")
    @Expose
    var addRecentEpisodeMinTimeLeftLimitSec: Int?,

    @SerializedName("addRecentMovieMinTimeLeftLimit")
    @Expose
    var addRecentMovieMinTimeLeftLimitSec: Int?,

    @SerializedName("featuredApps")
    @Expose
    var featuredApps: Set<String>?,

    @SerializedName("help_videos_enabled")
    @Expose
    var helpVideosEnabled: Boolean = false,

    @SerializedName("dialogsPrimeTime")
    @Expose
    val primeTimeDialogs: HashMap<String, PrimeTimeDialogMeta>?,

    @SerializedName("myAirtelHomePageMusic")
    @Expose
    var myAirtelHomePageMusic: String? = "5bdc82b1e4b0b825e2a68b48",

    @SerializedName("myAirtelHomePageAirtelTV")
    @Expose
    var myAirtelHomePageAirtelTV: String? = "5bc85500e4b066b41bd3049b",

    @SerializedName("searchDefaultTabId")
    @Expose
    var searchDefaultTabId: String? = "music",

    @SerializedName("musicRelatedPackageId")
    @Expose
    var musicRelatedPackageId: String? = null,

    @SerializedName("rcu_battery_threshold")
    @Expose
    var rcuBatteryThreshold: Int = 15,

    @SerializedName("xstreamPlans")
    @Expose
    var xstreamPlans: List<XstreamPlans>?,

    @SerializedName("obJobTimer")
    @Expose
    var obJobTimer: Long = 300000,

    @SerializedName("pinSuccessTimer")
    @Expose
    var pinSuccessTimer: Long = 3000
)
