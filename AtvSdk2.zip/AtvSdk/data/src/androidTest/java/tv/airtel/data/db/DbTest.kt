package tv.airtel.data.db

import android.arch.persistence.room.Room
import android.support.test.InstrumentationRegistry

import org.junit.After
import org.junit.Before

abstract class DbTest {
    protected lateinit var db: MiddlewareDb

    @Before
    fun initDb() {
        db = Room.inMemoryDatabaseBuilder(InstrumentationRegistry.getContext(),
                MiddlewareDb::class.java).build()
    }

    @After
    fun closeDb() {
        db.close()
    }
}
