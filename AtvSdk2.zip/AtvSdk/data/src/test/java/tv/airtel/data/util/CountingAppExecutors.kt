package tv.airtel.data.util

import tv.airtel.data.api.model.AppExecutors
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

class CountingAppExecutors {

    private val LOCK = Object()

    private var taskCount = 0

    val appExecutors: AppExecutors

    init {
        val increment = Runnable {
            synchronized(LOCK) {
                taskCount--
                if (taskCount == 0) {
                    LOCK.notifyAll()
                }
            }
        }
        val decrement = Runnable {
            synchronized(LOCK) {
                taskCount++
            }
        }
        appExecutors = AppExecutors(
                CountingExecutor(increment, decrement),
                CountingExecutor(increment, decrement),
                CountingExecutor(increment, decrement))
    }

    @Throws(InterruptedException::class, TimeoutException::class)
    fun drainTasks(time: Int, timeUnit: TimeUnit) {
        val end = System.currentTimeMillis() + timeUnit.toMillis(time.toLong())
        while (true) {
            synchronized(LOCK) {
                if (taskCount == 0) {
                    return
                }
                val now = System.currentTimeMillis()
                val remaining = end - now
                if (remaining > 0) {
                    LOCK.wait(remaining)
                } else {
                    throw TimeoutException("could not drain tasks")
                }
            }
        }
    }

    private class CountingExecutor(private val increment: Runnable, private val decrement: Runnable) : Executor {

        private val delegate = Executors.newSingleThreadExecutor()

        override fun execute(command: Runnable) {
            increment.run()
            delegate.execute {
                try {
                    command.run()
                } finally {
                    decrement.run()
                }
            }
        }
    }
}
