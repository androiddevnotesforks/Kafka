package com.airtel.vision.di.modules

import dagger.Module
import tv.airtel.data.di.NetworkModule

/**
 * Dagger module that provides objects which will live during the application lifecycle.
 */
@Module(includes = [NetworkModule::class])
abstract class ApplicationModule {

}
