package com.airtel.vision.manager

import android.accounts.AccountManager
import android.app.Application
import android.content.Context
import android.preference.PreferenceManager
import android.text.TextUtils
import org.json.JSONObject
import timber.log.Timber
import tv.airtel.data.utilmodule.util.Constants
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Created by VipulKumar on 19/03/18.
 *
 */

@Singleton
class ViaUserManager @Inject
internal constructor(private val application: Application) {


    //TODO ("Akash Gupta to put login logic")
    val isLoggedIn = false
    private var offlineBundleStatusMap: HashMap<String, JSONObject>? = hashMapOf()


    private val INSTALL_PREF_NAME = "moe_custom"

    /**
     * This method is used to set shared preferences
     *
     * @param key   shared object key
     * @param value shared object value
     */
    fun setPreferences(key: String?, value: String) {
        val appSharedPrefs = PreferenceManager
                .getDefaultSharedPreferences(application.applicationContext)
        if (appSharedPrefs != null) {
            val prefsEditor = appSharedPrefs.edit()
            if (prefsEditor != null && key != null) {
                prefsEditor.putString(key, value)
                prefsEditor.apply()
            }
        }
    }

    /**
     * This method is used to get shared object
     *
     * @param key shared object key
     * @return return value, for default "" assign.
     */
    fun getPreferences(key: String): String? {

        val appSharedPrefs = PreferenceManager
                .getDefaultSharedPreferences(application.applicationContext)

        val json = appSharedPrefs.getString(key, "")
        return if (TextUtils.isEmpty(json)) {
            null
        } else json
    }

    fun clearPreferences(context: Context?) {
        if (context != null) {
            val appSharedPrefs = PreferenceManager
                    .getDefaultSharedPreferences(context)
            if (appSharedPrefs != null) {
                val prefsEditor = appSharedPrefs.edit()
                if (prefsEditor != null) {
                    prefsEditor.clear()
                    prefsEditor.apply()
                }
            }
        }
    }

    fun clearOfflineBundlePack() {
        if (offlineBundleStatusMap != null) offlineBundleStatusMap?.clear()
    }


    fun getGmaillD(): String? {
        val manager = AccountManager.get(application.applicationContext)
        val accounts = manager.getAccountsByType("com.google")
        val possibleEmails = LinkedList<String>()

        for (account in accounts) {
            // TODO: Check possibleEmail against an email regex or treat
            // account.name as an email address only for certain account.type values.
            possibleEmails.add(account.name)
        }

        if (!possibleEmails.isEmpty()) {
            val email = possibleEmails[0]
            Timber.e("EMAILID ", " ........................... $email")
            return email
        }
        return null
    }



    fun setFirstLaunch() {
        val pref = application.applicationContext.getSharedPreferences(INSTALL_PREF_NAME, Context.MODE_PRIVATE)
        pref.edit().putBoolean(Constants.PREF_FIRST_LAUNCH, false).apply()
    }

}
