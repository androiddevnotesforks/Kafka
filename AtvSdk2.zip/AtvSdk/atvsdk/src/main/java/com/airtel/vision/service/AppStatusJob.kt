package com.airtel.vision.service

import com.airtel.vision.analytics.AnalyticsUtil
import tv.airtel.data.utilmodule.util.LogUtil
import javax.inject.Inject

/**
 * Created by Satya on 04/04/18.
 * Schedular to update app status on Splash screen.
 */
internal class AppStatusJob @Inject constructor() : JobScheduler(AppStatusJob::class.java.simpleName, 98) {
    private var counter: Int = 0

    var data = NONE_DATA
    fun startJob(appStatusData: String, maxCount: Long, delay: Long, interval: Long) {
        data = appStatusData
        appStatusCount = maxCount
        start(delay, interval)
    }

    override fun trigger() {
        LogUtil.d("AppStatusJob", "appStatusRunnable counter : " + counter + "app status " + data)
        if (counter.toLong() == appStatusCount) {
            stop()
            return
        }
        ++counter
        AnalyticsUtil.sendAppStatusEvent(data)
        done()
    }

    companion object {
        const val DEFAULT_APP_STATUS_INTERVAL = 10// 10 sec
        const val DEFAULT_APP_STATUS_COUNTER = 2
        const val NONE_DATA = "none"
        private var appStatusCount: Long = DEFAULT_APP_STATUS_COUNTER.toLong()

    }
}
