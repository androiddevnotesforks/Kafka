package com.airtel.vision.player

/**
 * Created by Aditya Mehta on 16/04/18.
 */
interface PlaybackEventListener {

//    fun onPlayerStateChanged(playEventState: PlayerEventState)

    fun updateSeekBar(current: Long, total: Long, bufferTime: Long)
}