package com.airtel.vision.analytics

import tv.airtel.wynk.analytics.Analytics
import tv.airtel.wynk.analytics.AnalyticsHashMap
import tv.airtel.wynk.analytics.events.Event
import tv.airtel.wynk.analytics.util.AnalyticsConstants.APP_STATUS
import tv.airtel.wynk.analytics.util.AnalyticsConstants.MSISDN_SOURCE


internal object AnalyticsUtil {

    fun partialRegistrationEvent(msisdnSource: String) {

        val properties = AnalyticsHashMap()
        properties.put(MSISDN_SOURCE, msisdnSource)
        sendAnalytics(Event.PATRTIAL_REGISTER, properties)
        //TODO check its logic with airtel tv app
//        sendingAppsFlyerEvent(true)

    }

    fun completeRegistrationEvent(msisdnSource: String) {

        val properties = AnalyticsHashMap()
        properties.put(MSISDN_SOURCE, msisdnSource)
        sendAnalytics(Event.COMPLETE_REGISTER, properties)
        //TODO check its logic with airtel tv app
//        sendingAppsFlyerEvent(false);
    }


    fun clickEvent(properties: AnalyticsHashMap) {
        sendAnalytics(Event.CLICK, properties)
    }

    fun onRegistrationFailed(properties: AnalyticsHashMap) {
        sendAnalytics(Event.REG_FAILED, properties)
    }

    fun sendAppStatusEvent(appStatusData: String) {
        val properties = AnalyticsHashMap()
        properties[APP_STATUS] = appStatusData
        sendAppStatusEvent(properties)

    }

    fun sendAppStatusEvent(properties: AnalyticsHashMap) {
        sendAnalytics(Event.APP_STATUS.eventId, Event.APP_STATUS.isCritical, properties)
    }

    //
//    //TODO uncomment and fix build errors
    fun setMoEUserAttribute() {
//    //        String productId = null;
//    //        MoEHelper.getInstance(VisionApplication.getContext()).setUserAttribute(MoEHelperConstants.USER_ATTRIBUTE_UNIQUE_ID, ViaUserManager.getInstance().getUid());
//    //        if (!TextUtils.isEmpty(ViaUserManager.getInstance().getName()))
//    //            MoEHelper.getInstance(VisionApplication.getContext()).setUserAttribute(MoEHelperConstants.USER_ATTRIBUTE_USER_NAME, ViaUserManager.getInstance().getName());
//    //        if (!TextzUtils.isEmpty(ViaUserManager.getInstance().getEmail()))
//    //            MoEHelper.getInstance(VisionApplication.getContext()).setUserAttribute(MoEHelperConstants.USER_ATTRIBUTE_USER_EMAIL, ViaUserManager.getInstance().getEmail());
//    //
//    //        if (!TextUtils.isEmpty(ViaUserManager.getInstance().getMobileNumber()))
//    //            MoEHelper.getInstance(VisionApplication.getContext()).setUserAttribute(MoEHelperConstants.USER_ATTRIBUTE_USER_MOBILE, ViaUserManager.getInstance().getMobileNumber());
//    //
//    //        Subscription offeredSubscription = ViaUserManager.getInstance(VisionApplication.getContext()).getHuaweiSubscription();
//    //        if (offeredSubscription != null) {
//    //            productId = offeredSubscription.productId;
//    //            if (!TextUtils.isEmpty(productId)) {
//    //                MoEHelper.getInstance(VisionApplication.getContext()).setUserAttribute(DTH_SUB, productId);
//    //            }
//    //        }
//    //        MoEHelper.getInstance(VisionApplication.getContext()).setUserAttribute(IMEI, DeviceIdentifier.getIMEI())
//    //                .setUserAttribute(IMSI, DeviceIdentifier.getIMSI())
//    //                .setUserAttribute(PERM_ID, true);
//    //
//    //        MoEHelper.getInstance(VisionApplication.getContext()).setUserAttribute(AIRTEL_FLAG, ViaUserManager.getInstance().isAirtelUser());
    }


    internal fun sendAnalytics(event: Event, analyticsHashMap: AnalyticsHashMap) {
        sendAnalytics(event.eventId, true, analyticsHashMap)
    }

    internal fun sendAnalytics(eventName: String, isCritical: Boolean, eventProperties: AnalyticsHashMap) {

        Analytics.instance?.trackEvent(eventName, isCritical, eventProperties)
    }
}
