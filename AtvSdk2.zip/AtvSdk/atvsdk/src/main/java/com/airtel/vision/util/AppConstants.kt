package com.airtel.vision.util

/**
 * Created by b0203949 on 26/03/18.
 */
object AppConstants{

    const val DEFAULT_LAST_WATCH_POSITION = -1

}