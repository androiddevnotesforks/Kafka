package com.airtel.vision.di

/**
 * Marks an activity / fragment injectable.
 */
interface Injectable
