package com.airtel.vision.viewmodel

import android.app.Application
import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.Transformations
import com.airtel.vision.livedata.WiseLiveData
import tv.airtel.data.api.ParameterBuilder.buildCreateProfileParams
import tv.airtel.data.api.ParameterBuilder.buildUpdateProfileParams
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.livedata.AbsentLiveData
import tv.airtel.data.model.PeopleProfile
import tv.airtel.data.model.content.RowItemContent
import tv.airtel.data.model.user.profile.ProfileEntity
import tv.airtel.data.repo.ProfileRepository
import javax.inject.Inject

/**
 * Created by VipulKumar on 02/05/18.
 */
class ProfileViewModel
@Inject internal constructor(private val profileRepository: ProfileRepository) {
    @Inject
    internal lateinit var application: Application

    private val favoriteListResponse = WiseLiveData.create<Resource<List<RowItemContent>>>()
    private var favoriteList: LiveData<Resource<List<RowItemContent>>>
    private val favoriteListMutableLiveData = MutableLiveData<Boolean>()

    private var peopleProfileResponse: WiseLiveData<Resource<PeopleProfile>> = WiseLiveData.create()
    private var peopleProfile: LiveData<Resource<PeopleProfile>>
    private val profileIdMutableLiveData = MutableLiveData<String>()

    private val createProfileResponse: WiseLiveData<Resource<ProfileEntity>> = WiseLiveData.create()
    private var createProfileData: LiveData<Resource<ProfileEntity>>
    private var createProfileMutableLiveData = MutableLiveData<CreateProfileTrigger>()

    private val deleteProfileResponse: WiseLiveData<Resource<ProfileEntity>> = WiseLiveData.create()
    private var deleteProfileData: LiveData<Resource<ProfileEntity>>
    private var deleteProfileMutableLiveData = MutableLiveData<DeleteProfileTrigger>()

    private val updateProfileResponse: WiseLiveData<Resource<ProfileEntity>> = WiseLiveData.create()
    private var updateProfileData: LiveData<Resource<ProfileEntity>>
    private var updateProfileMutableLiveData = MutableLiveData<CreateProfileTrigger>()

    private val selectProfileResponse: WiseLiveData<Resource<ProfileEntity>> = WiseLiveData.create()
    private var selectProfileData: LiveData<Resource<ProfileEntity>>
    private var selectProfileMutableLiveData = MutableLiveData<SelectProfileTrigger>()

    private val unlinkDeviceResponse: WiseLiveData<Resource<ProfileEntity>> = WiseLiveData.create()
    private var unlinkDeviceData: LiveData<Resource<ProfileEntity>>
    private var unlinkDeviceMutableLiveData = MutableLiveData<String>()

    private val resetAccountResponse: WiseLiveData<Resource<ProfileEntity>> = WiseLiveData.create()
    private var resetAccountData: LiveData<Resource<ProfileEntity>>
    private var resetAccountMutableLiveData = MutableLiveData<Boolean>()

    private val getProfileDataResponse: WiseLiveData<Resource<ProfileEntity>> =
        WiseLiveData.create()
    private var getProfileData: LiveData<Resource<ProfileEntity>>
    private var getProfileDataMutableLiveData = MutableLiveData<Boolean>()

    init {
        getProfileData = Transformations.switchMap(getProfileDataMutableLiveData) {
            if (it != null) {
                profileRepository.getUserProfiles()
            } else {
                AbsentLiveData.create<Resource<ProfileEntity>>()
            }
        }

        initGetProfileDataResponse()

        selectProfileData = Transformations.switchMap(selectProfileMutableLiveData) {
            if (it != null) {
                profileRepository.switchUserProfile(it.profileId)
            } else {
                AbsentLiveData.create<Resource<ProfileEntity>>()
            }
        }

        initSelectProfileDataResponse()

        updateProfileData = Transformations.switchMap(updateProfileMutableLiveData) {
            if (it != null) {
                profileRepository.updateUserProfile(
                    it.profileId!!,
                    buildUpdateProfileParams(it.name, it.passCode)
                )
            } else {
                AbsentLiveData.create<Resource<ProfileEntity>>()
            }
        }
        initUpdateProfileResponse()

        createProfileData = Transformations.switchMap(createProfileMutableLiveData) {
            if (it != null) {
                profileRepository
                    .createUserProfile(buildCreateProfileParams(it.name!!, it.passCode))
            } else {
                AbsentLiveData.create<Resource<ProfileEntity>>()
            }
        }

        initCreateProfileResponse()

        deleteProfileData = Transformations.switchMap(deleteProfileMutableLiveData) {
            if (it != null) {
                profileRepository
                    .deleteUserProfile(it.profileId)
            } else {
                AbsentLiveData.create<Resource<ProfileEntity>>()
            }
        }

        initDeleteProfileResponse()

        favoriteList = Transformations.switchMap(favoriteListMutableLiveData) {
            if (it) {
                profileRepository.loadFavoriteContents()
            } else {
                AbsentLiveData.create<Resource<List<RowItemContent>>>()
            }
        }
        initFavoritesListResponse()

        peopleProfile = Transformations.switchMap(profileIdMutableLiveData) {
            if (it != null) {
                profileRepository.loadPeopleProfile(it)
            } else {
                WiseLiveData.create<Resource<PeopleProfile>>()
            }
        }
        initPeopleProfileResponse()

        unlinkDeviceData = Transformations.switchMap(unlinkDeviceMutableLiveData) {
            if (it != null) {
                profileRepository.unlinkDevice(it)
            } else {
                AbsentLiveData.create<Resource<ProfileEntity>>()
            }
        }

        initUnlinkDeviceDataResponse()

        resetAccountData = Transformations.switchMap(resetAccountMutableLiveData) {
            if (it == true) {
                profileRepository.resetAccount()
            } else {
                AbsentLiveData.create<Resource<ProfileEntity>>()
            }
        }

        initResetAccountResponse()
    }

    private fun initUnlinkDeviceDataResponse() {
        unlinkDeviceResponse.addSource(unlinkDeviceData) { resource ->
            when (resource?.status) {
                Status.LOADING -> unlinkDeviceResponse.dispatchLoading(resource)
                Status.SUCCESS -> unlinkDeviceResponse.dispatchSuccess(resource)
                Status.ERROR -> unlinkDeviceResponse.dispatchError(resource)
            }
        }
    }

    private fun initResetAccountResponse() {
        resetAccountResponse.addSource(resetAccountData) { resource ->
            when (resource?.status) {
                Status.LOADING -> resetAccountResponse.dispatchLoading(resource)
                Status.SUCCESS -> resetAccountResponse.dispatchSuccess(resource)
                Status.ERROR -> resetAccountResponse.dispatchError(resource)
            }
        }
    }

    private fun initGetProfileDataResponse() {
        getProfileDataResponse.addSource(getProfileData) {
            onProfileEntityFetched(it)
        }
    }

    private fun onProfileEntityFetched(resource: Resource<ProfileEntity>?) {
        when (resource?.status) {
            Status.LOADING -> getProfileDataResponse.dispatchLoading(resource)
            Status.SUCCESS -> {

                getProfileDataResponse.dispatchSuccess(resource)
            }
            Status.ERROR -> getProfileDataResponse.dispatchError(resource)
        }
    }

    private fun initSelectProfileDataResponse() {
        selectProfileResponse.addSource(selectProfileData) { resource ->
            when (resource?.status) {
                Status.LOADING -> selectProfileResponse.dispatchLoading(resource)
                Status.SUCCESS -> selectProfileResponse.dispatchSuccess(resource)
                Status.ERROR -> selectProfileResponse.dispatchError(resource)
            }
        }
    }

    private fun initCreateProfileResponse() {
        createProfileResponse.addSource(createProfileData) {
            when (it?.status) {
                Status.LOADING -> createProfileResponse.dispatchSuccess(Resource.loading(it.data))
                Status.SUCCESS -> createProfileResponse.dispatchSuccess(Resource.success(it.data))
                Status.ERROR -> createProfileResponse.dispatchError(Resource.error(it.error, null))
            }
        }
    }

    private fun initDeleteProfileResponse() {
        deleteProfileResponse.addSource(deleteProfileData) {
            when (it?.status) {
                Status.LOADING -> deleteProfileResponse.dispatchSuccess(Resource.loading(it.data))
                Status.SUCCESS -> deleteProfileResponse.dispatchSuccess(Resource.success(it.data))
                Status.ERROR -> deleteProfileResponse.dispatchError(Resource.error(it.error, null))
            }
        }
    }

    private fun initUpdateProfileResponse() {
        updateProfileResponse.addSource(updateProfileData) {
            when (it?.status) {
                Status.LOADING -> updateProfileResponse.dispatchSuccess(Resource.loading(it.data))
                Status.SUCCESS -> updateProfileResponse.dispatchSuccess(Resource.success(it.data))
                Status.ERROR -> updateProfileResponse.dispatchError(Resource.error(it.error, null))
            }
        }
    }

    private fun initPeopleProfileResponse() {
        peopleProfileResponse.addSource(peopleProfile) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> peopleProfileResponse.dispatchSuccess(resource)
                Status.LOADING -> peopleProfileResponse.dispatchLoading(resource)
                Status.ERROR -> peopleProfileResponse.dispatchError(resource)
            }
        }
    }

    private fun initFavoritesListResponse() {
        favoriteListResponse.addSource(favoriteList) {
            when (it?.status) {
                Status.SUCCESS -> {
                    if (it.data != null) {
                        favoriteListResponse.dispatchSuccess(Resource.success(it.data))
                    } else {
                        favoriteListResponse.dispatchSuccess(Resource.success(null))
                    }
                }

                Status.LOADING -> {
                    // do nothing
                }

                Status.ERROR -> {
                    favoriteListResponse.dispatchError(Resource.error(it.error, null))
                }
            }
        }
    }

    internal fun getFavoritesList(): WiseLiveData<Resource<List<RowItemContent>>> {
        favoriteListMutableLiveData.value = true
        return favoriteListResponse
    }

    internal fun getPeopleProfile(profileId: String): WiseLiveData<Resource<PeopleProfile>> {
        profileIdMutableLiveData.value = profileId
        return peopleProfileResponse
    }

    internal fun getProfileData(): LiveData<Resource<ProfileEntity>> {
        getProfileDataMutableLiveData.value = true
        return getProfileDataResponse
    }

    internal fun selectProfile(profileId: String): LiveData<Resource<ProfileEntity>> {
        selectProfileMutableLiveData.value = SelectProfileTrigger(profileId)
        return selectProfileResponse
    }

    internal fun createProfile(name: String, passCode: String? = null):
            LiveData<Resource<ProfileEntity>> {
        createProfileMutableLiveData.value = CreateProfileTrigger(name = name, passCode = passCode)
        return createProfileResponse
    }

    internal fun deleteProfile(profileId: String):
            LiveData<Resource<ProfileEntity>> {
        deleteProfileMutableLiveData.value = DeleteProfileTrigger(profileId)
        return deleteProfileResponse
    }

    internal fun updateProfile(
        profileId: String, name: String? = null,
        passCode: String? = null
    ): LiveData<Resource<ProfileEntity>> {
        updateProfileMutableLiveData.value = CreateProfileTrigger(
            profileId = profileId,
            name = name, passCode = passCode
        )
        return updateProfileResponse
    }

    internal fun unlinkDevice(deviceId: String): LiveData<Resource<ProfileEntity>> {
        unlinkDeviceMutableLiveData.value = deviceId
        return unlinkDeviceResponse
    }

    internal fun resetAccount(): LiveData<Resource<ProfileEntity>> {
        resetAccountMutableLiveData.value = true
        return resetAccountResponse
    }

    data class CreateProfileTrigger(
        val profileId: String? = null, val name: String? = null,
        val passCode: String? = null
    )

    data class SelectProfileTrigger(val profileId: String)

    data class DeleteProfileTrigger(val profileId: String)
}

