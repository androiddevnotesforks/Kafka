package com.airtel.vision.viewmodel

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.Transformations
import com.airtel.vision.livedata.WiseLiveData
import com.airtel.vision.manager.newsync.RecentSyncPreferenceManager
import com.airtel.vision.util.AppConstants
import com.airtel.vision.util.ContentTransformations
import com.airtel.vision.util.ContentTransformations.transformRecentContentDetails
import com.airtel.vision.util.ContentTransformations.transformToFavorites
import com.airtel.vision.util.ContentTransformations.transformToRecents
import com.airtel.vision.util.DateTimeUtil
import tv.airtel.data.api.model.AppExecutors
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.livedata.SingleLiveEvent
import tv.airtel.data.model.content.BaseRow
import tv.airtel.data.model.content.ClearHistoryResponse
import tv.airtel.data.model.content.ContentDetail
import tv.airtel.data.model.content.recentfavorite.RecentContentDetails
import tv.airtel.data.model.content.recentfavorite.RecentFavoriteEntity
import tv.airtel.data.model.content.recentfavorite.RecentFavouriteRequestEntity
import tv.airtel.data.model.content.recentfavorite.RecentSyncRequestWrapper
import tv.airtel.data.model.layout.RowSubType
import tv.airtel.data.model.user.CurrentUser
import tv.airtel.data.repo.RecentFavoriteRepository
import tv.airtel.data.utilmodule.util.LogUtil
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Author : Akash Gupta
 * Created On : 09/08/18
 *
 */
@Singleton
internal class RecentFavoriteViewModel
@Inject internal constructor(
    private val recentFavoriteRepository: RecentFavoriteRepository,
    private val executors: AppExecutors
) {

    private var syncRecentFavoriteResponse:
            SingleLiveEvent<Resource<String?>> = SingleLiveEvent()
    private var syncRecentFavoriteMutableLiveData = MutableLiveData<RecentSyncRequestWrapper>()
    private var syncRecentFavorite: LiveData<Resource<List<RecentFavoriteEntity>>>

    private var getRecentResponse: WiseLiveData<Resource<List<RecentFavoriteEntity>>> =
        WiseLiveData.create()
    private var getRecentMutableLiveData = MutableLiveData<Boolean>()
    private var getRecents: LiveData<Resource<List<RecentFavoriteEntity>>>

    private var recentFavouriteMutableLiveData = MutableLiveData<String>()
    private var recentFavourite: LiveData<RecentFavoriteEntity>
    @Inject
    lateinit var recentSyncPreferenceManager: RecentSyncPreferenceManager
    @Inject
    lateinit var currentUser: CurrentUser
    private var getFavoriteResponse: WiseLiveData<Resource<BaseRow>> = WiseLiveData.create()
    private var getFavoriteMutableLiveData = MutableLiveData<Boolean>()
    private var getFavorite: LiveData<Resource<List<RecentFavoriteEntity>>>


    private var clearHistoryResponse: WiseLiveData<Resource<ClearHistoryResponse>> =
        WiseLiveData.create()
    private var clearHistoryMutableLiveData = MutableLiveData<Boolean>()
    private var clearHistory: LiveData<Resource<ClearHistoryResponse>>

    init {
        syncRecentFavorite =
            Transformations.switchMap(syncRecentFavoriteMutableLiveData) { syncData ->
                if (syncData != null) {
                    recentFavoriteRepository.syncRecentFavorite(syncData)
                } else {
                    WiseLiveData.create<Resource<List<RecentFavoriteEntity>>>()
                }
            }
        initSyncResponse()

        getRecents = Transformations.switchMap(getRecentMutableLiveData) { it ->
            if (it) {
                recentFavoriteRepository.getRecentsList()
            } else {
                WiseLiveData.create<Resource<List<RecentFavoriteEntity>>>()
            }
        }
        initGetRecentsResponse()

        recentFavourite = Transformations.switchMap(recentFavouriteMutableLiveData) {
            if (it.isNotNullOrEmpty()) {
                recentFavoriteRepository.getRecentFavourite(it)
            } else {
                WiseLiveData.create<RecentFavoriteEntity>()
            }
        }

        getFavorite = Transformations.switchMap(getFavoriteMutableLiveData) { it ->
            if (it) {
                recentFavoriteRepository.getFavoritesList()
            } else {
                WiseLiveData.create<Resource<List<RecentFavoriteEntity>>>()
            }
        }
        initGetFavoriteResponse()

        clearHistory = Transformations.switchMap(clearHistoryMutableLiveData) { it ->
            if (it) {
                recentFavoriteRepository.clearWatchHistory()
            } else {
                WiseLiveData.create<Resource<ClearHistoryResponse>>()
            }
        }
        initClearHistoryResponse()
    }

    private fun initClearHistoryResponse() {
        clearHistoryResponse.addSource(clearHistory) { resource ->

            when (resource?.status) {
                Status.LOADING -> clearHistoryResponse.dispatchLoading(resource)
                Status.SUCCESS -> clearHistoryResponse.dispatchSuccess(resource)
                Status.ERROR -> clearHistoryResponse.dispatchError(resource)
            }
        }
    }

    private fun initSyncResponse() {
        syncRecentFavoriteResponse.addSource(syncRecentFavorite) { resource ->
            when (resource?.status) {
                Status.LOADING -> syncRecentFavoriteResponse.dispatchLoading(
                    Resource.loading(
                        null
                    )
                )
                Status.SUCCESS -> {
                    LogUtil.d(RecentSyncPreferenceManager.TAG + " sync response continue watching response SUCCESS")
                    syncRecentFavoriteResponse.dispatchSuccess(Resource.success(null))
                }
                Status.ERROR -> {
                    syncRecentFavoriteResponse.dispatchError(
                        Resource.error(
                            resource.error,
                            null
                        )
                    )
                    LogUtil.d(RecentSyncPreferenceManager.TAG + " sync response error setting update true error " + resource.error.toString())
                    recentSyncPreferenceManager.setLocalDbUpdated(true)
                }
            }
        }

        syncRecentFavoriteResponse.observeForever {

        }
    }

    private fun initGetRecentsResponse() {
        getRecentResponse.addSource(getRecents) {
            when (it?.status) {
                Status.SUCCESS -> {
                    if (it.data != null) {
                        getRecentResponse.dispatchSuccess(Resource.success(it.data))
                    } else {
                        getRecentResponse.dispatchSuccess(Resource.success(null))
                    }
                }

                Status.LOADING -> {
                    // do nothing
                }

                Status.ERROR -> {
                    getRecentResponse.dispatchError(Resource.error(it.error, null))
                }
            }
        }
    }

    private fun initGetFavoriteResponse() {
        getFavoriteResponse.addSource(getFavorite) {
            when (it?.status) {
                Status.SUCCESS -> {
                    if (it.data != null) {
                        val baseRow = BaseRow()
                        baseRow.id = "ContinueWatching"
                        baseRow.subType = RowSubType.CONTINUE_WATCHING
                        val contentEntity = ContentTransformations
                            .transformGetRecentFavoriteWatched(it.data)
                        if (contentEntity.content.isNotEmpty()) {
                            baseRow.contents = contentEntity
                        }
                        getFavoriteResponse.dispatchSuccess(Resource.success(baseRow))
                    } else {
                        getFavoriteResponse.dispatchSuccess(Resource.success(null))
                    }
                }

                Status.LOADING -> {
                    // do nothing
                }

                Status.ERROR -> {
                    getFavoriteResponse.dispatchError(Resource.error(it.error, null))
                }
            }
        }
    }

    fun syncRecentFavorites(clearAll: Boolean, diff: Boolean) {
        executors.diskIO().execute {
            LogUtil.d("RecentFavTest syncRecentFavorites clearALl " + clearAll + " diff " + diff)
            if (clearAll) {
                clearAll()
            }

            val recentsList: List<RecentFavoriteEntity> =
                recentFavoriteRepository.getRecentsListForSync()
            val favoriteList: List<RecentFavoriteEntity> =
                recentFavoriteRepository.getFavoritesListForSync()

            val addFavList = favoriteList.filter {
                it.fav
            }
            val removedFavList = favoriteList.filter {
                !it.fav
            }

            val addRecentsList = recentsList.filter {
                it.recent
            }
            val removedRecentsList = recentsList.filter {
                !it.recent
            }

            val favorites = transformToFavorites(addFavList, removedFavList)
            val recents = transformToRecents(addRecentsList, removedRecentsList)

            executors.mainThread().execute {
                syncRecentFavoriteMutableLiveData.value = RecentSyncRequestWrapper(
                    RecentFavouriteRequestEntity(
                        favorites,
                        recents
                    ), diff
                )
            }
        }
    }

    fun addRecent(
        contentId: String,
        contentDetail: ContentDetail,
        lastWatchedPosition: Int = 0,
        episodeNo: Int = 0,
        tvShowName: String?,
        seasonNo:Int?
    ) {
        val recentContentDetails =
            transformRecentContentDetails(contentDetail, episodeNo = episodeNo,tvShowName = tvShowName,seasonNo =  seasonNo)

        executors.diskIO().execute {
            val recentEntity = createRecentFavoriteItem(
                contentId,
                recentContentDetails, lastWatchedPosition, false, true
            )
            if (recentFavoriteRepository.isExist(contentId) > 0) {
                recentFavoriteRepository.updateRecentFavorite(
                    recentEntity.recent,
                    recentEntity.lastWatchedPosition.toInt(), recentEntity.lastUpdatedTimeStamp,
                    recentEntity.isRecentSynced, recentEntity._id
                )
            } else {
                recentFavoriteRepository.addRecentFavorite(recentEntity)
            }
            recentSyncPreferenceManager.setLocalDbUpdated(true)
        }
    }

    private fun createRecentFavoriteItem(
        contentId: String, recentContentDetails: RecentContentDetails,
        lastWatchedPosition: Int, isFav: Boolean,
        isRecent: Boolean
    ): RecentFavoriteEntity {
        val recentFavorite = RecentFavoriteEntity()

        recentContentDetails.id = contentId
        recentFavorite._id = contentId
        recentFavorite.contentDetails = recentContentDetails
        recentFavorite.fav = isFav
        recentFavorite.recent = isRecent
        if (isFav) {
            recentFavorite.isFavoriteSynced = false
            recentFavorite.lastUpdatedTimeStamp = DateTimeUtil.getCurrentTimeStamp()
        }
        if (isRecent) {
            recentFavorite.isRecentSynced = false
            recentFavorite.lastUpdatedTimeStamp = DateTimeUtil.getCurrentTimeStamp()
            recentFavorite.lastWatchedPosition = lastWatchedPosition.toDouble()
        }
        return recentFavorite
    }

    fun deleteRecent(contentId: String) {
        executors.diskIO().execute {
            recentFavoriteRepository.updateRecentFavorite(
                false,
                AppConstants.DEFAULT_LAST_WATCH_POSITION,
                DateTimeUtil.getCurrentTimeStamp(),
                false,
                contentId
            )
        }
        recentSyncPreferenceManager.setLocalDbUpdated(true)
    }

    fun profileChanged() {

        executors.diskIO()
            .execute {
                clearAll()
                syncRecentFavorites(true, false)
            }
    }

    fun getRecents(): WiseLiveData<Resource<List<RecentFavoriteEntity>>> {
        getRecentMutableLiveData.value = true
        return getRecentResponse
    }

    internal fun clearAll() {
        recentFavoriteRepository.clearAll()
    }

    fun getRecentlyWatched(contentIds: List<String>): LiveData<List<RecentFavoriteEntity>> {
        return recentFavoriteRepository.getRecentListByIds(contentIds)
    }

    fun getRecentlyWatchedBySeriesId(seriesId:String): LiveData<List<RecentFavoriteEntity>> {
        return recentFavoriteRepository.getRecentListBySeriesId(seriesId)
    }

    fun getRecentFavourite(contentId: String): LiveData<RecentFavoriteEntity> {
        recentFavouriteMutableLiveData.value = contentId
        return recentFavourite
    }

    fun addToWatchLater(contentId: String, contentDetail: ContentDetail) {
        executors.diskIO().execute {
            val recentContentDetails = transformRecentContentDetails(contentDetail)

            val favoriteEntity = createRecentFavoriteItem(
                contentId,
                recentContentDetails, AppConstants.DEFAULT_LAST_WATCH_POSITION, true, false
            )
            if (recentFavoriteRepository.isExist(contentId) > 0) {
                recentFavoriteRepository.updateFavorite(
                    favoriteEntity.fav,
                    favoriteEntity.lastUpdatedTimeStamp, favoriteEntity.isFavoriteSynced,
                    favoriteEntity._id
                )
            } else {
                recentFavoriteRepository.addRecentFavorite(favoriteEntity)
            }
        }
        recentSyncPreferenceManager.setLocalDbUpdated(true)
    }

    fun removeWatchLater(contentId: String) {
        executors.diskIO().execute {
            recentFavoriteRepository.updateFavorite(
                false, DateTimeUtil.getCurrentTimeStamp(),
                false, contentId
            )
        }
        recentSyncPreferenceManager.setLocalDbUpdated(true)
    }

    fun getWatchLater(): WiseLiveData<Resource<BaseRow>> {
        getFavoriteMutableLiveData.value = true
        return getFavoriteResponse
    }

    fun getLastPlayedEpisode(seriesId: String): LiveData<RecentFavoriteEntity> {
        return recentFavoriteRepository.getRecentlyPlayedEpisode(seriesId)
    }

    fun handleSync() {
        val localDbUpdated = recentSyncPreferenceManager.isLocalDbUpdated()
        LogUtil.d(
            RecentSyncPreferenceManager.TAG + "  handleSync called " + localDbUpdated
                    + "current time " + currentUser.lastSyncTime
                    + " oldLastSyncTime  " + recentSyncPreferenceManager.oldLastSyncTime()
        )
        if (localDbUpdated) {
            LogUtil.d(RecentSyncPreferenceManager.TAG + " calling sync " + localDbUpdated)
            sync(localDbUpdated)
        } else if (
            recentSyncPreferenceManager.oldLastSyncTime() < currentUser.lastSyncTime ?: -1
        ) {
            recentSyncPreferenceManager.setLastSyncTime(currentUser.lastSyncTime ?: -1L)
            sync(localDbUpdated)
        }
    }

    private fun sync(diff: Boolean) {
        LogUtil.d(RecentSyncPreferenceManager.TAG + " DIFF CALLED calling sync " + diff)
        recentSyncPreferenceManager.setLocalDbUpdated(false)
        syncRecentFavorites(false, diff)
    }

    fun clearHistory(): LiveData<Resource<ClearHistoryResponse>> {

        clearHistoryMutableLiveData.value = true

        return clearHistoryResponse
    }
}
