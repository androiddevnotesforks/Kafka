package com.airtel.vision.viewmodel

import android.app.Application
import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.Transformations
import com.airtel.vision.livedata.WiseLiveData
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.model.content.apps.AppEntity
import tv.airtel.data.repo.AppRepository
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
internal class AppViewModel @Inject constructor(private val appRepository: AppRepository) {

    @Inject
    internal lateinit var application: Application

    private var appsResponse: WiseLiveData<Resource<List<AppEntity>>> =
        WiseLiveData.create()
    private var appEntities: LiveData<List<AppEntity>>
    private val appsMutableLiveData = MutableLiveData<Boolean>()

    init {
        appEntities = Transformations.switchMap(appsMutableLiveData) {
            if (it) {
                appRepository.loadApps(application.packageManager)
            } else {
                WiseLiveData.create<List<AppEntity>>()
            }
        }
        initAppsResponse()
    }

    private fun initAppsResponse() {
        appsResponse.addSource(appEntities) {
            appsResponse.dispatchSuccess(Resource(Status.SUCCESS, it, null))
        }
    }

    fun getApps(): LiveData<Resource<List<AppEntity>>> {
        appsMutableLiveData.value = true
        appsResponse.dispatchLoading(Resource(Status.LOADING, null, null))
        return appsResponse
    }

    fun updateLastUsedTime(packageId: String, time: Long){
        appRepository.updateLastUsedTime(packageId,time)
    }


}
