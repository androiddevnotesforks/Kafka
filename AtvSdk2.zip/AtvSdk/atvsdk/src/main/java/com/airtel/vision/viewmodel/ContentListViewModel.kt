package com.airtel.vision.viewmodel

import android.app.Application
import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.Observer
import android.arch.lifecycle.Transformations
import android.support.v4.util.ArrayMap
import android.text.TextUtils
import com.airtel.vision.AtvSdk
import com.airtel.vision.extensions.absentLiveData
import com.airtel.vision.livedata.WiseLiveData
import com.airtel.vision.manager.newsync.RecentSyncPreferenceManager
import com.airtel.vision.util.ContentTransformations.transformLayoutAPISuccessEntity
import tv.airtel.data.api.model.AppExecutors
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.error.AtvError
import tv.airtel.data.livedata.AbsentLiveData
import tv.airtel.data.model.content.*
import tv.airtel.data.model.layout.LayoutEntity
import tv.airtel.data.model.user.UserConfig
import tv.airtel.data.model.user.profile.ProfileEntity
import tv.airtel.data.repo.ContentRepository
import tv.airtel.data.repo.ProfileRepository
import tv.airtel.data.repo.UserRepository
import tv.airtel.data.util.findActiveProfile
import tv.airtel.data.util.isNotNullOrEmpty
import tv.airtel.data.utilmodule.manager.UserPreferenceManager
import tv.airtel.data.utilmodule.util.LogUtil
import javax.inject.Inject

/**
 * All repository calls to fetch content for feature page
 * should be made through this class.
 * Created by Aditya Mehta on 28/03/18.
 */
internal class ContentListViewModel
@Inject internal constructor(
        private val contentRepository: ContentRepository,
        private val userRepository: UserRepository,
        private val profileRepository: ProfileRepository
) {
    @Inject
    internal lateinit var application: Application
    @Inject
    internal lateinit var recentFavoriteViewModel: RecentFavoriteViewModel
    @Inject
    internal lateinit var appExecutors: AppExecutors
    private val TAG = "CONTENT"


    /**
     * params for calling moreContent api.
     * @see [moreContentResponse]
     */
    data class MoreContentParam(
        val contentId: String?,
        val pageSize: Int?,
        val pageOffset: Int?
    )

    private val moreContentMutableLiveData = MutableLiveData<MoreContentParam>()
    private var moreContentResponse: LiveData<Resource<ContentEntityResponse>> = absentLiveData()

    private var contentResultData: ArrayMap<String, LiveData<Resource<ContentResult>>> = ArrayMap()

    //array maps to hold individual api calls LiveData so that we can remove them
    private val layoutDataMap: ArrayMap<String, LiveData<Resource<List<LayoutEntity>>>> = ArrayMap()
    private val contentDataMap: ArrayMap<String, LiveData<Resource<ContentEntityMap>>> = ArrayMap()

    private val layoutTriggerMap: ArrayMap<String, MutableLiveData<LayoutTrigger>> =
            ArrayMap()
    private val contentIdsMutableLiveDataMap: ArrayMap<String, MutableLiveData<String>> = ArrayMap()
    private val sourcePackageMutableLiveDataMap: ArrayMap<String, MutableLiveData<HashMap<String, String>>> =
            ArrayMap()

    private val requestedLayoutDataMap: ArrayMap<String, Boolean> = ArrayMap()
    private val requestedContentDataMap: ArrayMap<String, Boolean> = ArrayMap()

    private val contentByPackageId: LiveData<Resource<ContentEntityMap>>
    private val contentByPackageIdMutableLiveData = MutableLiveData<ContentTrigger>()

    private var userConfigData: LiveData<Resource<UserConfig>> = AbsentLiveData.create()

    private var profileData: LiveData<Resource<ProfileEntity>> = AbsentLiveData.create()

    private var userPropertiesMap: Map<String, String> = emptyMap()

    private class LayoutTrigger(var pageId: String, var userPropertiesMap: Map<String, String>)

    private val configObserver = Observer<Resource<UserConfig>> { resource ->
        if (resource?.data?.userProperties != null) {
            if (userPropertiesMap != resource.data?.userProperties) {
                LogUtil.d("UserConfig changed ${resource.data?.userProperties}")
                userPropertiesMap = resource.data?.userProperties as HashMap<String, String>
                appExecutors.diskIO().execute {
                    //                    layoutDataMap.keys.forEach { contentRepository.clearLayoutList(it) }
                    appExecutors.mainThread().execute { refreshLayouts() }
                }
            }
        }
    }

    private val fetchProfileObserver = Observer<Resource<ProfileEntity>> { resource ->
        // fetch layouts if active profile has changed
        resource?.data?.let {
            val savedProfileId = UserPreferenceManager
                    .getInstance(application)
                    .getString(UserPreferenceManager.KEY_USER_PROFILE_ID, "")
            val activeProfileId = it.findActiveProfile()?.id
            LogUtil.d(
                    RecentSyncPreferenceManager.TAG + "calling force refresh saved $savedProfileId active $activeProfileId"
                            + " resource " + resource.status
            )
            if (savedProfileId != activeProfileId) {
                refreshLayouts()
                recentFavoriteViewModel.profileChanged()
            }
        }

        // save new data about active profile
        if (resource?.status == Status.SUCCESS) {
            AtvSdk.getInstance().getCurrentUser()?.buildCurrentUser(null, resource.data)
            LogUtil.d("saveProfileId data ${resource.data} ${resource.data?.userProfile}")
            saveProfileId(resource.data)
        }
    }

    private fun saveProfileId(profileEntity: ProfileEntity?) {
        UserPreferenceManager.getInstance(application).putString(
                UserPreferenceManager.KEY_USER_PROFILE_ID,
                profileEntity?.findActiveProfile()?.id ?: ""
        )
    }

    init {
        moreContentResponse = Transformations.switchMap(moreContentMutableLiveData) {
            if (it != null) {
                contentRepository.loadContentList(it.contentId, it.pageSize, it.pageOffset)
            } else {
                absentLiveData()
            }
        }

        contentByPackageId = Transformations.switchMap(contentByPackageIdMutableLiveData) {
            if (it != null) {
                contentRepository.loadContentList(it.pageId, it.packageId, it.source, it.type)
            } else {
                absentLiveData()
            }
        }

        if (!profileData.hasObservers()) observeProfileChanges()
    }

    fun getContent(
            pageId: String,
            fetchBySource: Boolean = false
    ): LiveData<Resource<ContentResult>> {

        if (layoutTriggerMap[pageId] == null) {
            // pre-fill required data
            layoutTriggerMap[pageId] = MutableLiveData()
            contentIdsMutableLiveDataMap[pageId] = MutableLiveData()
            sourcePackageMutableLiveDataMap[pageId] = MutableLiveData()
            requestedLayoutDataMap[pageId] = false
            requestedContentDataMap[pageId] = false
        }

        createLiveDataIfNull(pageId)
        fetchLayoutSetup(pageId, fetchBySource)

        if (!userConfigData.hasObservers()) observeConfigChanges()
        return contentResultData[pageId]!!
    }

    fun getContentByPackageId(contentTrigger: ContentTrigger): LiveData<Resource<ContentEntityMap>> {
        contentByPackageIdMutableLiveData.value = contentTrigger
        return contentByPackageId
    }

    private fun fetchLayoutSetup(pageId: String, fetchBySource: Boolean = false) {
        if (layoutDataMap[pageId] == null) {
            layoutDataMap[pageId] = Transformations
                    .switchMap(layoutTriggerMap[pageId]!!) {
                        if (it != null) {
                            contentRepository.loadLayoutList(it.pageId, it.userPropertiesMap)
                        } else {
                            AbsentLiveData.create()
                        }
                    }

            addLayoutEntityLiveData(pageId, fetchBySource)
        }
        fetchLayout(pageId)
    }

    private fun fetchLayout(pageId: String) {
        requestedLayoutDataMap[pageId] = true
        if (userPropertiesMap.isEmpty()) {
            userPropertiesMap = AtvSdk.getInstance().getCurrentUser()?.userProperties ?: mapOf()
        }
        layoutTriggerMap[pageId]!!.value = LayoutTrigger(pageId, userPropertiesMap)
    }

    private fun fetchContentsByContentIdsSetup(
            pageIdString: String,
            baseRows: List<BaseRow>,
            commaSeparatedMiddlewareContentIds: String, shouldFetch: Boolean
    ) {
        if (contentDataMap[pageIdString] == null) {
            contentDataMap[pageIdString] = Transformations
                    .switchMap(contentIdsMutableLiveDataMap[pageIdString]!!) {
                        if (it != null) {
                            contentRepository.loadContentList(
                                    pageIdString, it, shouldFetch = shouldFetchFromServer
                            )
                        } else {
                            AbsentLiveData.create()
                        }
                    }
        }
        addContentLiveData(pageIdString, baseRows)
        fetchContent(pageIdString, commaSeparatedMiddlewareContentIds, shouldFetch)
    }

    private fun fetchContentsByContentSourcePackageSetup(
            pageIdString: String,
            baseRows: List<BaseRow>,
            groupSourcePackages: HashMap<String, String>,
            shouldFetch: Boolean
    ) {
        if (contentDataMap[pageIdString] == null) {
            contentDataMap[pageIdString] = Transformations
                    .switchMap(sourcePackageMutableLiveDataMap[pageIdString]!!) {
                        if (it != null) {
                            contentRepository.loadContentList(
                                    pageIdString, it, shouldFetchFromServer
                            )
                        } else {
                            AbsentLiveData.create()
                        }
                    }
        }
        addContentLiveData(pageIdString, baseRows)
        fetchContentBySource(pageIdString, groupSourcePackages, shouldFetch)
    }

    private var shouldFetchFromServer = false

    private fun fetchContent(
            pageId: String,
            commaSeparatedMiddlewareContentIds: String,
            shouldFetch: Boolean
    ) {
        shouldFetchFromServer = shouldFetch
        requestedContentDataMap[pageId] = true
        contentIdsMutableLiveDataMap[pageId]!!.value = commaSeparatedMiddlewareContentIds
    }

    private fun fetchContentBySource(
            pageId: String,
            sourcePackage: HashMap<String, String>,
            shouldFetch: Boolean
    ) {
        shouldFetchFromServer = shouldFetch
        requestedContentDataMap[pageId] = true
        sourcePackageMutableLiveDataMap[pageId]!!.value = sourcePackage
    }

    private fun addLayoutEntityLiveData(pageId: String, fetchBySource: Boolean = false) {
        LogUtil.d("addLayoutEntityLiveData $this")
        contentResultData[pageId]?.removeSource(layoutDataMap[pageId]!!)
        contentResultData[pageId] = Transformations.map(layoutDataMap[pageId]!!) {

            if (it?.data.isNotNullOrEmpty() &&
                    it?.data!![0].pageId == pageId && (requestedLayoutDataMap[pageId]!! || it.data != layoutDataMap[pageId]?.value?.data)
            ) {
                when (it.status) {
                    Status.SUCCESS -> {
                        requestedLayoutDataMap[pageId] = false
                        onLayoutEntityLoaded(pageId, it.data, true, fetchBySource)
                    }

                    Status.LOADING -> {
                        onLayoutEntityLoaded(pageId, it.data, false, fetchBySource)
                    }

                    else -> {
                        LogUtil.d(TAG, "Error addLayoutEntityLiveData")
                        requestedLayoutDataMap[pageId] = false
                        onLayoutEntityLoaded(pageId, it.data, true, fetchBySource)
                    }
                }
            } else {
                when (it?.status) {
                    Status.ERROR -> {
                        dispatchError(pageId, null, it.error)
                        LogUtil.d(TAG, "Error addLayoutEntityLiveData else clause")
                    }
                    Status.LOADING -> {
                        dispatchLoading(pageId, null)
                    }
                    else -> {
                    }
                }
            }
        }
    }

    private fun onLayoutEntityLoaded(
            pageId: String,
            layoutEntities: List<LayoutEntity>?,
            shouldFetch: Boolean,
            fetchBySource: Boolean = true
    ) {
        val baseRows: List<BaseRow> = transformLayoutAPISuccessEntity(layoutEntities)
        if (fetchBySource) {
            appendIdsAndFetchContentBySource(pageId, baseRows, shouldFetch)
        } else {
            appendIdsAndFetchContent(pageId, baseRows, shouldFetch)
        }
    }

    private fun addContentLiveData(pageId: String, baseRows: List<BaseRow>) {
        // always dispatchValue because shouldFetch is false
        contentResultData[pageId]?.removeSource(contentDataMap[pageId]!!)
        contentResultData[pageId]?.addSource(contentDataMap[pageId]!!) {
            if (it?.data != null && (requestedContentDataMap[pageId]!! ||
                            it.data != contentDataMap[pageId]?.value?.data)
            ) {
                when (it.status) {
                    Status.SUCCESS -> {
                        addRowContents(baseRows, it.data?.map!!)
                        if (shouldFetchFromServer) {
                            dispatchSuccess(pageId, baseRows)
                            requestedContentDataMap[pageId] = false
                        } else {
                            dispatchLoading(pageId, baseRows)
                        }
                    }

                    Status.LOADING -> {
                    }

                    Status.ERROR -> {
                        LogUtil.d(TAG, "Error addContentLiveData")
                        addRowContents(baseRows, it.data?.map!!)
                        dispatchError(pageId, baseRows, it.error)
                    }
                }
            }
        }
    }

    private fun appendIdsAndFetchContent(
            pageId: String,
            baseRows: List<BaseRow>,
            shouldFetch: Boolean
    ) {
        val middleWareContentIds = StringBuilder("")
        for (row in baseRows) {
            if (row.layoutContents.isNotNullOrEmpty()) {

                middleWareContentIds.append(row.layoutContents!![0].packageId).append(",")
            }
        }

        if (!TextUtils.isEmpty(middleWareContentIds)) {
            val commaSeparatedMiddlewareContentIds =
                    middleWareContentIds.toString().substring(0, middleWareContentIds.length - 1)
            fetchContentsByContentIdsSetup(
                    pageId, baseRows,
                    commaSeparatedMiddlewareContentIds, shouldFetch
            )
        } else {
            //till live data is pending, send empty rows to client
            //when following case occur
        }
    }

    private fun appendIdsAndFetchContentBySource(
            pageId: String,
            baseRows: List<BaseRow>,
            shouldFetch: Boolean
    ) {
        val middleWareContentIds = StringBuilder("")
        for (row in baseRows) {
            if (row.layoutContents.isNotNullOrEmpty()) {

                middleWareContentIds.append(row.layoutContents!![0].packageId).append(",")
            }
        }

        if (!TextUtils.isEmpty(middleWareContentIds)) {
            fetchContentsByContentSourcePackageSetup(
                    pageId, baseRows,
                    groupPackageBySourceStr(baseRows), shouldFetch
            )
        } else {
            // till live data is pending, send empty rows to client
            // when following case occur
        }
    }

    private fun appendedSourcePackage(baseRows: List<BaseRow>): String {
        var queryStr = ""
        val groupPackagesString = groupPackageBySourceStr(baseRows)
        groupPackagesString.forEach { (key, value) ->
            queryStr = "$key=$value&"
        }
        return queryStr
    }

    private fun groupPackageBySourceStr(baseRows: List<BaseRow>): HashMap<String, String> {
        val groupPackagesString = HashMap<String, String>()
        val groupPackages: Map<String, MutableList<BaseRow>> = groupPackageBySource(baseRows)
        groupPackages.forEach { (key, value) ->
            val packagesStr = value.map {
                it.layoutContents!![0].packageId
            }
            groupPackagesString[key] = packagesStr.joinToString(separator = ",")
        }
        return groupPackagesString
    }

    private fun groupPackageBySource(baseRows: List<BaseRow>): Map<String, MutableList<BaseRow>> {
        val sourceMap = HashMap<String, MutableList<BaseRow>>()
        for (row in baseRows) {
            val source = row.backendType
            source?.let {
                val packages: MutableList<BaseRow> = sourceMap[source.name] ?: mutableListOf()
                packages.add(row)
                sourceMap[source.name] = packages
            }
        }
        return sourceMap
    }

    private fun addRowContents(
            baseRows: List<BaseRow>,
            rowContentMap: HashMap<String, ContentEntity>
    ) {
        for (row in baseRows) {
            if (row.layoutContents.isNotNullOrEmpty()) {
                row.contents = rowContentMap[row.layoutContents!![0].packageId]
                if (row.contents != null && row.contents?.content != null &&
                        row.contents?.content!!.size > row.totalCount && row.totalCount > 0
                ) {
                    val filteredRowContents = ArrayList<Content>(row.totalCount)
                    filteredRowContents.addAll(row.contents!!.content.subList(0, row.totalCount))
                    row.contents!!.content = filteredRowContents
                }
            }
        }
    }

    private fun dispatchSuccess(pageId: String, baseRows: List<BaseRow>?) {
        val liveData = contentResultData[pageId]
        val contentResult = if (baseRows == null)
            null else ContentResult(pageId, baseRows)
        liveData?.dispatchSuccess(Resource.success(contentResult))
    }

    private fun dispatchLoading(pageId: String, baseRows: List<BaseRow>?) {
        val liveData = contentResultData[pageId]
        val contentResult = if (baseRows == null)
            null else ContentResult(pageId, baseRows)
        liveData?.dispatchLoading(Resource.loading(contentResult))
    }

    private fun dispatchError(pageId: String, baseRows: List<BaseRow>?, error: AtvError?) {
        LogUtil.d(TAG, "Error dispatchError")
        val contentResult = if (baseRows == null)
            null else ContentResult(pageId, baseRows)
        val liveData = contentResultData[pageId]
        liveData?.dispatchError(Resource.error(error, contentResult))
    }

    private fun refreshLayouts() {
        LogUtil.d("LayoutDataMap $layoutDataMap")
        appExecutors.diskIO().execute {
            contentRepository.clearLayoutList()
            contentRepository.clearContentList()
            appExecutors.mainThread().execute {
                for (pageId in layoutDataMap.keys) {
                    fetchLayout(pageId)
                }
            }
        }
    }

    fun getContent(
            contentId: String?,
            pageSize: Int?, pageIndex: Int?
    ): LiveData<Resource<ContentEntityResponse>> {
        moreContentMutableLiveData.value = MoreContentParam(contentId, pageSize, pageIndex)
        return moreContentResponse
    }

    fun getContentByContentId(contentId: String): LiveData<Content> {
        return contentRepository.loadContentByContentId(contentId)
    }

    private fun observeConfigChanges() {
        userConfigData = userRepository.getUserConfig(false)
        userConfigData.observeForever(configObserver)
    }

    private fun observeProfileChanges() {
        profileData = profileRepository.getUserProfiles(false)
        profileData.observeForever(fetchProfileObserver)
    }

    private fun createLiveDataIfNull(pageId: String) {
        if (contentResultData[pageId] == null) {
            contentResultData[pageId] = WiseLiveData()
            //TODO: fix cleanup
//            contentResultData[pageId]?.addCleanupListener {
//                layoutDataMap[pageId]?.let {
////                    contentResultData[pageId]?.removeSource(it)
////                    layoutDataMap.remove(pageId)
//                }
//
//                contentDataMap[pageId]?.let {
//                    contentResultData[pageId]?.removeSource(it)
//                    contentDataMap.remove(pageId)
//                }
//
//                recentlyWatchedDataMap[pageId]?.let {
//                    contentResultData[pageId]?.removeSource(it)
//                    recentlyWatchedDataMap.remove(pageId)
//                }
//
////                userConfigData.removeObserver(configObserver)
//            }
        }
    }

    internal data class ContentTrigger(
            var pageId: String,
            var packageId: String,
            var source: String,
            var type: String
    )
}

