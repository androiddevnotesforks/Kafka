//package com.airtel.vision.player
//
//import airtel.tv.stb.player.PlaybackController
//import airtel.tv.stb.player.enums.ErrorReason
//import airtel.tv.stb.player.enums.PlaybackControllerState
//import airtel.tv.stb.player.exception.ResponseError
//import airtel.tv.stb.player.interfaces.PlaybackControllerListener
//import airtel.tv.stb.player.model.PlaybackItemCore
//import airtel.tv.stb.player.util.QualityController
//import android.app.Activity
//import android.app.Application
//import android.app.Fragment
//import android.arch.lifecycle.LiveData
//import android.arch.lifecycle.Observer
//import android.os.Bundle
//import android.view.View
//import android.view.ViewGroup
//import com.airtel.vision.util.ContentTransformations
//import com.airtel.vision.viewmodel.ContentDetailViewModel
//import tv.accedo.airtel.wynk.domain.firebase.util.ConfigUtils
//import tv.airtel.data.api.model.Resource
//import tv.airtel.data.livedata.AbsentLiveData
//import tv.airtel.data.manager.CPManager
//import tv.airtel.data.model.ResultEntity
//import tv.airtel.data.model.content.ContentDetail
//import tv.airtel.data.model.player.DetailViewModel
//import tv.airtel.data.model.player.StreamingResponse
//import tv.airtel.data.model.user.CurrentUser
//import tv.airtel.util.util.PlaybackQuality
//import tv.airtel.wynk.analytics.util.AnalyticsConstants
//import java.util.*
//import javax.inject.Inject
//import javax.inject.Singleton
//
///**
// * Created by Aditya Mehta on 16/04/18.
// */
//@Suppress("MemberVisibilityCanBePrivate")
//@Singleton
//class AtvPlayer @Inject internal constructor(val qualityController: QualityController) {
//    private var playbackEventListener: PlaybackEventListener? = null
//
//    @Inject
//    internal lateinit var playbackController: PlaybackController
//    @Inject
//    internal lateinit var applicationContext: Application
//    @Inject
//    internal lateinit var currentUser: CurrentUser
//    @Inject
//    internal lateinit var contentDetailViewModel: ContentDetailViewModel
//
//    private var playerState: PlayerEventState? = null
//    private var cpSubState: CPManager.CPSubState? = null
//    private var currentActivity: Activity? = null
//    private var isPlayedOnce = false
//    private var lifeCycleRegistered = false
//    private var playbackListenerWrapper = PlaybackListenerWrapper()
//
//    private var addRecentObserver: Observer<Resource<ResultEntity>>
//    private var addRecentLiveData: LiveData<Resource<ResultEntity>> = AbsentLiveData.create()
//
//    private var deleteRecentObserver: Observer<Resource<ResultEntity>>
//    private var deleteRecentLiveData: LiveData<Resource<ResultEntity>> = AbsentLiveData.create()
//
//
//    init {
//        qualityController.initialiseQualityController()
//
//        addRecentObserver = Observer {
//            if(it != null){
//            }
//        }
//
//        deleteRecentObserver = Observer {
//            if(it != null){
//            }
//        }
//    }
//
//    private fun registerLifeCycleListener() {
//
//        if (lifeCycleRegistered) return
//
//        applicationContext.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
//            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
//
//            }
//
//            override fun onActivityStarted(activity: Activity) {
//
//            }
//
//            override fun onActivityResumed(activity: Activity) {
//
//            }
//
//            override fun onActivityPaused(activity: Activity) {
//
//            }
//
//            override fun onActivityStopped(activity: Activity) {
//
//            }
//
//            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle?) {
//
//            }
//
//            override fun onActivityDestroyed(activity: Activity) {
////                if (context != null && context.javaClass.getName() == activity.javaClass.name) {
//                if (activity == currentActivity) {
//                    playbackController.onActivityDestroyed()
//                    destroy()
//                }
//            }
//        })
//        lifeCycleRegistered = true
//    }
//
//    private fun destroy() {
//        playerState = null
//        cpSubState = null
//        playbackEventListener = null
//        currentActivity = null
//        isPlayedOnce = false
//    }
//
//    internal fun setPlaybackEventListener(activity: Activity, playbackEventListener: PlaybackEventListener, configUtils: ConfigUtils) {
//        this.playbackEventListener = playbackEventListener
//        currentActivity = activity
//        registerLifeCycleListener()
//        playbackController.init(activity)
//
//        playbackController.setPlaybackListener(playbackListenerWrapper)
//    }
//
//    private fun onOrientationChanged(orientation: Int) {
//    }
//
//    private fun onStreamingSuccessCallBack(streamingUrl: StreamingResponse?) {
//        //  playbackEventListener?.onStreamingDataResponseSuccess(streamingUrl)
//        //client already has init_state, he doesn't need to know about this information
//    }
//
//    private fun onStreamingErrorCallback(error: ResponseError?) {
//        //  playbackEventListener?.onStreamingDataResponseError(error)
//        val playbackControllerState = PlayerEventState.ERROR
//        playbackControllerState.errorDetail.errorReason = ErrorReason.FETCHING_STREAMING_URL_ERROR
//        playbackControllerState.errorDetail.errorCode = error?.getErrorCode()
//
//        playbackEventListener?.onPlayerStateChanged(playbackControllerState)
//    }
//
//    private fun updateSeekBar(current: Long, total: Long, bufferTime: Long) {
//        playbackEventListener?.updateSeekBar(current, total, bufferTime)
//    }
//
//    private fun onStateChanged(playbackControllerState: PlaybackControllerState?) {
//
//        sendPlayerState(playbackControllerState)
//
//    }
//
//    private fun updateUserConfig() {
//
//    }
//
//    private fun sendPlayerState(playbackControllerState: PlaybackControllerState?) {
//
//
//        when (playbackControllerState) {
//
//            PlaybackControllerState.NOT_CREATED ->
//                playerState = PlayerEventState.NOT_CREATED
//            PlaybackControllerState.INIT_PLAYER ->
//                playerState = PlayerEventState.INIT_PLAYER
//            PlaybackControllerState.INITIALIZING ->
//                playerState = PlayerEventState.INITIALIZING
//            PlaybackControllerState.CREATED -> {
//                playerState = PlayerEventState.CREATED
//
//                if (cpSubState === CPManager.CPSubState.VALID) initStreaming()
//            }
//            PlaybackControllerState.NOT_RUNNING -> {
//                ///  playerState = PlayerEventState.NOT_RUNNING
//                //client doesn't need to know about this state
//            }
//            PlaybackControllerState.PREPARING ->
//                playerState = PlayerEventState.PREPARING
//            PlaybackControllerState.PREPARED ->
//                playerState = PlayerEventState.PREPARED
//            PlaybackControllerState.AUTO_STARTED, PlaybackControllerState.MANNUAL_STARTED
//            -> playerState = PlayerEventState.STARTED
//            PlaybackControllerState.AUTO_PAUSED, PlaybackControllerState.MANNUAL_PAUSED
//            -> playerState = PlayerEventState.PAUSED
//            PlaybackControllerState.ERROR
//            -> playerState = PlayerEventState.ERROR
//            PlaybackControllerState.FINISHED
//            -> playerState = PlayerEventState.FINISHED
//            PlaybackControllerState.DESTROYED
//            -> {
//                //client doesn't need to know about this state
//                //playerState = PlayerEventState.DESTROYED
//            }
//        }
//        playerState?.let {
//            copyPlaybackState(playbackControllerState, it)
//            playbackEventListener?.onPlayerStateChanged(playerState as PlayerEventState)
//        }
//    }
//
//    private fun copyPlaybackState(playbackControllerState: PlaybackControllerState?, playerEventState: PlayerEventState) {
//
//        playerEventState.errorDetail.isRecoverable = playbackControllerState?.stateDesc?.isRecoverable ?: false
//        playerEventState.errorDetail.errorCode = playbackControllerState?.stateDesc?.errorCode
//        playerEventState.errorDetail.errorReason = playbackControllerState?.stateDesc?.errorReason
//    }
//
//    private fun initStreaming() {
//        isPlayedOnce = true;
//        playbackController.startPlay()
//    }
//
//    private lateinit var contentDetail: ContentDetail
//
//    fun getContentDetail () : ContentDetail {
//        return contentDetail;
//    }
//
//    fun loadStreamingData(detailViewModel: ContentDetail) {
//        contentDetail = detailViewModel;
//
//        val detailViewModel = ContentTransformations.transformToDetailViewModel(detailViewModel)
////           playbackController.loadData(toPlaybackItemCore(detailViewModel))
//        val isValid = CPManager.isPlaybackValid(detailViewModel.cpId, detailViewModel.contentType,
//                detailViewModel.isFreeContent, currentUser.getLoginState())
//
//        if (isValid) {
//            cpSubState = CPManager.CPSubState.VALID
//            playbackController.loadData(toPlaybackItemCore(detailViewModel))
//
//            //  playbackController.startPlay()
//        } else {
//            val cpSubState = CPManager.getCPState(detailViewModel.cpId, detailViewModel.contentType, detailViewModel.isFreeContent,
//                    currentUser.getLoginState()
//            )
//            checkCp(cpSubState, detailViewModel);
//        }
//    }
//
//    private fun checkCp(cpSubState: CPManager.CPSubState, detailViewModel: DetailViewModel) {
//
//        this.cpSubState = cpSubState
//        when (cpSubState) {
//            CPManager.CPSubState.CP_UNKNOWN -> {
//
//            }
////                if (toPlay || view?.isAutoFetch() == false) {
////                    view?.showToast(ConfigUtils.getString(Keys.CONTENT_PROVIDER_NOT_AVAILABLE))
////                }
//        //TODO give error
//            CPManager.CPSubState.VALID -> {
//                playbackController.loadData(toPlaybackItemCore(detailViewModel))
//            }
//        //view?.onPlayableContentAvailable(detailViewModel)
//            CPManager.CPSubState.CP_EXPIRED -> {
//                playbackController.loadData(toPlaybackItemCore(detailViewModel))
//                playbackEventListener?.onPlayerStateChanged(PlayerEventState.AUTO_PLAY_FAILED)
//                playerState = PlayerEventState.AUTO_PLAY_FAILED
//            }
//
////                if (toPlay || view?.isAutoFetch() == false) {
////                    view?.onPlayableContentAvailable(detailViewModel)
////                }
//        //TODO give error
//            CPManager.CPSubState.LOGIN_UNKNOWN -> {
//
//                playbackEventListener?.onPlayerStateChanged(PlayerEventState.LOGIN_UNKNOWN)
//            }
////                if (toPlay || view?.isAutoFetch() == false) {
////                    view?.whenUserNotRegistered(detailViewModel.id)
////                }
//        //TODO give error
//            CPManager.CPSubState.WCF_EXPIRED_NO_EMAIL,
//            CPManager.CPSubState.CP_EXPIRED_NO_EMAIL,
//            CPManager.CPSubState.LOGIN_NO_EMAIL -> {
//            }
////                if (toPlay || view?.isAutoFetch() == false) {
////                    view?.whenUserEmailNotFound()
////                }
//            CPManager.CPSubState.WCF_EXPIRED -> {
//                playbackEventListener?.onPlayerStateChanged(PlayerEventState.NO_SUBSCRIPTION)
//            }
////                if (toPlay || view?.isAutoFetch() == false) {
////                    view?.openSubscriptionDialog(detailViewModel.cpId, Constants.ReqCode.OPEN_SUBSCRIPTION_PAGE)
////                }
//        }
//    }
//
//    private fun getPlayerView(): View {
//        return playbackController.playbackView
//    }
//
//    fun addPlayerToView(viewGroup: ViewGroup) {
//
//        val parent = playbackController.playbackView.parent
//
//        if (parent != null) {
//            (parent as ViewGroup).removeView(playbackController.playbackView)
//        }
//
//        viewGroup.addView(playbackController.playbackView)
//    }
//
//    fun pauseClicked() {
//        playbackController.pauseClicked()
//    }
//
//    fun playClicked() {
//        if (!isPlayedOnce && cpSubState === CPManager.CPSubState.CP_EXPIRED) {
//            initStreaming()
//        } else {
//            playbackController.playClicked()
//        }
//    }
//
//    private fun stopPlay() {
//        playbackController.stopPlay()
//    }
//
////    private fun playerBackButtonClicked() {
////        playbackController.playerBackButtonClicked()
////    }
//
////   private fun fullScreenSwitchClicked() {
////        playbackController.fullScreenSwitchClicked()
////    }
//
//    fun setRewind30sec() {
//        playbackController.setRewind30sec()
//    }
//
//    fun setForward30sec() {
//        playbackController.setForward30sec()
//    }
//
//    fun retryPlayBack() {
//        playbackController.retryPlayBack()
//    }
//
////    private fun dimVolume(v: Float) {
////        //playbackController.dimVolume(v)
////    }
//
////    public void setPlayerControls(View view) {
////        if (playerLayout != null) {
////            playerLayout.setPlayerControls(view);
////        }
////    }
//
//    fun seekTo(seekTo: Long) {
//        playbackController.seekTo(seekTo)
//    }
//
//    fun skipIntroClicked() {
//        playbackController.skipIntroClicked()
//    }
//
//    fun hidePlayerControls() {
//        playbackController.hidePlayerControls()
//    }
//
//    fun showPlayerControls() {
//        playbackController.showPlayerControls()
//    }
//
//
////    fun retryClicked() {
////        playbackController.retryClicked()
////    }
//
////    fun nextEpisodeClicked() {
////        playbackController.nextEpisodeClicked()
////    }
//
//    fun setPlayerControls(view: View) {
//        playbackController.setPlayerControls(view);
//    }
//
//    fun setPlayerControls(view: Fragment) {
//        playbackController.setPlayerControls(view);
//    }
//
//    fun removePlayer() {
//        playbackController.removePlayer()
//    }
//
//    fun getQualityList(): ArrayList<PlaybackQuality> {
//        return playbackController.qualityList
//    }
//
//    fun setQuality(qualityId : String) {
//        playbackController.setQuality(qualityId)
//    }
//
//    internal fun toPlaybackItemCore(detailViewModel: DetailViewModel): PlaybackItemCore {
//
//        return PlaybackItemCore.Builder(applicationContext, detailViewModel.id,
//                detailViewModel.contentType, AnalyticsConstants.SourceNames.content_detail_page.name)
//                .createItem(detailViewModel, qualityController)
//    }
//
//    private inner class PlaybackListenerWrapper : PlaybackControllerListener {
//
//        override fun removeFromRecent(parameter: String) {
//            deleteRecentLiveData.removeObserver{
//                deleteRecentObserver
//            }
//            deleteRecentLiveData = contentDetailViewModel.removeFromRecent(parameter)
//            deleteRecentLiveData.observeForever(deleteRecentObserver)
//        }
//
//        override fun addRecent(parameters: MutableMap<String, String>) {
//            addRecentLiveData.removeObserver { addRecentObserver }
//            addRecentLiveData = contentDetailViewModel.addRecent(parameters)
//            addRecentLiveData.observeForever(addRecentObserver)
//        }
//
//        override fun onStreamingSuccessCallBack(streamingUrl: StreamingResponse?) {
//            this@AtvPlayer.onStreamingSuccessCallBack(streamingUrl)
//        }
//
//        override fun onStreamingErrorCallback(error: ResponseError?) {
//            this@AtvPlayer.onStreamingErrorCallback(error)
//        }
//
//        override fun updateSeekBar(current: Long, total: Long, bufferTime: Long) {
//            this@AtvPlayer.updateSeekBar(current, total, bufferTime)
//        }
//
//        override fun onStateChanged(var1: PlaybackControllerState?) {
//            this@AtvPlayer.onStateChanged(var1)
//        }
//
//        override fun onOrientationChanged(orientation: Int) {
//            this@AtvPlayer.onOrientationChanged(orientation)
//        }
//
//        override fun updateUserConfig() {
//            this@AtvPlayer.updateUserConfig()
//        }
//    }
//}