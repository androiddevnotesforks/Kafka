package com.airtel.vision.viewmodel

import android.app.Application
import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.Transformations
import android.util.Log
import com.airtel.vision.livedata.WiseLiveData
import tv.airtel.data.api.ParameterBuilder
import tv.airtel.data.api.model.Resource
import tv.airtel.data.api.model.Status
import tv.airtel.data.manager.CPManager
import tv.airtel.data.model.ResultEntity
import tv.airtel.data.model.content.ContentDetail
import tv.airtel.data.model.content.detail.EpisodeDetail
import tv.airtel.data.model.content.detail.SeasonDetail
import tv.airtel.data.model.content.related.RelatedContent
import tv.airtel.data.model.content.related.RelatedSports
import tv.airtel.data.model.search.SearchResponse
import tv.airtel.data.model.user.CurrentUser
import tv.airtel.data.repo.ContentDetailRepository
import javax.inject.Inject

/**
 * All repository calls to fetch content for feature page
 * should be made through this class.
 * Created by Aditya Mehta on 28/03/18.
 */
internal class ContentDetailViewModel
@Inject internal constructor(private val contentDetailRepository: ContentDetailRepository) {
    @Inject
    internal lateinit var application: Application
    @Suppress("MemberVisibilityCanBePrivate")
    @Inject
    lateinit var currentUser: CurrentUser

    private var contentDetailResponse: WiseLiveData<Resource<ContentDetail>> = WiseLiveData.create()
    private var contentDetail: LiveData<Resource<ContentDetail>>
    private val contentIdMutableLiveData = MutableLiveData<String>()

    private var seasonDetailResponse: WiseLiveData<Resource<SeasonDetail>> = WiseLiveData.create()
    private var seasonDetail: LiveData<Resource<SeasonDetail>>
    private val seasonIdMutableLiveData = MutableLiveData<String>()

    private var episodeDetailResponse: WiseLiveData<Resource<EpisodeDetail>> = WiseLiveData.create()
    private var episodeDetail: LiveData<Resource<EpisodeDetail>>
    private val episodeIdMutableLiveData = MutableLiveData<String>()

    private var relatedContentResponse: WiseLiveData<Resource<RelatedContent>> = WiseLiveData.create()
    private var relatedContent: LiveData<Resource<RelatedContent>>
    private val relatedContentIdMutableLiveData = MutableLiveData<String>()

    private var relatedSportsResponse: WiseLiveData<Resource<RelatedSports>> = WiseLiveData.create()
    private var relatedSports: LiveData<Resource<RelatedSports>>
    private val relatedSportsIdMutableLiveData = MutableLiveData<String>()

    private var relatedPeopleResponse: WiseLiveData<Resource<SearchResponse>> = WiseLiveData.create()
    private var relatedPeople: LiveData<Resource<SearchResponse>>
    private val relatedPeopleIdMutableLiveData = MutableLiveData<String>()

    private var addRecentResponse: WiseLiveData<Resource<ResultEntity>> = WiseLiveData.create()
    private var addRecent: LiveData<Resource<ResultEntity>>
    private val addRecentMutableLiveData = MutableLiveData<MutableMap<String, String>?>()

    private var deleteRecentResponse: WiseLiveData<Resource<ResultEntity>> = WiseLiveData.create()
    private var deleteRecent: LiveData<Resource<ResultEntity>>
    private val deleteRecentMutableLiveData = MutableLiveData<String>()

    private var markFavoriteResponse: WiseLiveData<Resource<ResultEntity>> = WiseLiveData.create()
    private var markFavorite: LiveData<Resource<ResultEntity>>
    private val markFavoriteMutableLiveData = MutableLiveData<Pair<String, Boolean>>()

    private var isContentDetailDelivered: Boolean = false
    private var isContentEpisodeDetailDelivered: Boolean = false
    private var isContentSeasonDetailDelivered: Boolean = false

    init {

        contentDetail = Transformations.switchMap(contentIdMutableLiveData) {
            if (it != null) {
                contentDetailRepository.loadContentDetail(it)
            } else {
                WiseLiveData.create<Resource<ContentDetail>>()
            }
        }
        initContentDetailResponse()

        seasonDetail = Transformations.switchMap(seasonIdMutableLiveData) {
            if (it != null) {
                contentDetailRepository.loadSeasonDetail(it)
            } else {
                WiseLiveData.create<Resource<SeasonDetail>>()
            }
        }
        initSeasonDetailResponse()

        episodeDetail = Transformations.switchMap(episodeIdMutableLiveData) {
            if (it != null) {
                contentDetailRepository.loadEpisodeDetail(it)
            } else {
                WiseLiveData.create<Resource<EpisodeDetail>>()
            }
        }
        initEpisodeDetailResponse()

        relatedContent = Transformations.switchMap(relatedContentIdMutableLiveData) {
            if (it != null) {
                contentDetailRepository.loadContentRelatedEntities(it,
                        currentUser.userContentProperties)
            } else {
                WiseLiveData.create<Resource<RelatedContent>>()
            }
        }
        initContentRelatedResponse()

        relatedSports = Transformations.switchMap(relatedSportsIdMutableLiveData) {
            if (it != null) {
                contentDetailRepository.loadSportsRelatedEntities(it)
            } else {
                WiseLiveData.create<Resource<RelatedSports>>()
            }
        }
        initSportsRelatedResponse()

        relatedPeople = Transformations.switchMap(relatedPeopleIdMutableLiveData) {
            if (it != null) {
                contentDetailRepository.loadPeopleRelatedContent(it, ParameterBuilder
                        .buildPeopleRelatedContentParams(it, currentUser))
            } else {
                WiseLiveData.create<Resource<SearchResponse>>()
            }
        }
        initPeopleRelatedResponse()

        addRecent = Transformations.switchMap(addRecentMutableLiveData) {
            if (it != null) {
                contentDetailRepository.addRecent(it)
            } else {
                WiseLiveData.create<Resource<ResultEntity>>()
            }
        }
        initAddRecentResponse()

        deleteRecent = Transformations.switchMap(deleteRecentMutableLiveData) {
            if (it != null) {
                contentDetailRepository.deleteRecent(it)
            } else {
                WiseLiveData.create<Resource<ResultEntity>>()
            }
        }
        initDeleteRecentResponse()

        markFavorite = Transformations.switchMap(markFavoriteMutableLiveData) {
            if (it != null) {
                if (it.second)
                    contentDetailRepository.markFavorite(it.first)
                else
                    contentDetailRepository.unMarkFavorite(it.first)
            } else {
                WiseLiveData.create<Resource<ResultEntity>>()
            }
        }
        initMarkFavoriteResponse()
    }

    private fun initMarkFavoriteResponse() {
        markFavoriteResponse.addSource(markFavorite) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> markFavoriteResponse.dispatchSuccess(resource)
                Status.LOADING -> markFavoriteResponse.dispatchLoading(resource)
                Status.ERROR -> markFavoriteResponse.dispatchError(resource)
            }
        }
    }

    private fun initAddRecentResponse() {
        addRecentResponse.addSource(addRecent) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> addRecentResponse.dispatchSuccess(resource)
                Status.LOADING -> addRecentResponse.dispatchLoading(resource)
                Status.ERROR -> addRecentResponse.dispatchError(resource)
            }
        }
    }

    private fun initDeleteRecentResponse() {
        deleteRecentResponse.addSource(deleteRecent) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> deleteRecentResponse.dispatchSuccess(resource)
                Status.LOADING -> deleteRecentResponse.dispatchLoading(resource)
                Status.ERROR -> deleteRecentResponse.dispatchError(resource)
            }
        }
    }

    private fun initContentDetailResponse() {
        contentDetailResponse.addSource(contentDetail) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> {
                    if (!isContentDetailDelivered) {
                        onContentDetailSuccess(resource)
                    }
                }
                Status.LOADING -> contentDetailResponse.dispatchLoading(resource)
                Status.ERROR -> contentDetailResponse.dispatchError(resource)
            }
        }
    }

    private fun initSeasonDetailResponse() {
        seasonDetailResponse.addSource(seasonDetail) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> {
                    if (!isContentSeasonDetailDelivered) {
                        onSeasonContentDetailSuccess(resource)
                    }
                }
                Status.LOADING -> seasonDetailResponse.dispatchLoading(resource)
                Status.ERROR -> seasonDetailResponse.dispatchError(resource)
            }
        }
    }

    private fun initEpisodeDetailResponse() {
        episodeDetailResponse.addSource(episodeDetail) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> {
                    if (!isContentEpisodeDetailDelivered) {
                        onEpisodeContentDetailSuccess(resource)
                    }
                }
                Status.LOADING -> episodeDetailResponse.dispatchLoading(resource)
                Status.ERROR -> episodeDetailResponse.dispatchError(resource)
            }
        }

    }

    private fun initContentRelatedResponse() {
        relatedContentResponse.addSource(relatedContent) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> relatedContentResponse.dispatchSuccess(resource)
                Status.LOADING -> relatedContentResponse.dispatchLoading(resource)
                Status.ERROR -> relatedContentResponse.dispatchError(resource)
            }
        }
    }

    private fun initSportsRelatedResponse() {
        relatedSportsResponse.addSource(relatedSports) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> relatedSportsResponse.dispatchSuccess(resource)
                Status.LOADING -> relatedSportsResponse.dispatchLoading(resource)
                Status.ERROR -> relatedSportsResponse.dispatchError(resource)
            }
        }
    }

    private fun initPeopleRelatedResponse() {
        relatedPeopleResponse.addSource(relatedPeople) { resource ->
            when (resource?.status) {
                Status.SUCCESS -> relatedPeopleResponse.dispatchSuccess(resource)
                Status.LOADING -> relatedPeopleResponse.dispatchLoading(resource)
                Status.ERROR -> relatedPeopleResponse.dispatchError(resource)
            }
        }
    }

    private fun onContentDetailSuccess(it: Resource<ContentDetail>) {
        when (it.data?.cpId) {
            CPManager.CP.MWTV, CPManager.CP.HUAWEI -> {
            }
            else -> {
//                userContentDetailMutableLiveData.value = it.data?.id
            }
        }
        contentDetailResponse.dispatchSuccess(it)
        isContentDetailDelivered = true
    }

    private fun onEpisodeContentDetailSuccess(it: Resource<EpisodeDetail>) {
        isContentEpisodeDetailDelivered = true
        episodeDetailResponse.dispatchSuccess(it)
    }

    private fun onSeasonContentDetailSuccess(it: Resource<SeasonDetail>) {
        seasonDetailResponse.dispatchSuccess(it)
        isContentSeasonDetailDelivered = true
    }

    fun getContentDetail(contentId: String): LiveData<Resource<ContentDetail>> {
        isContentDetailDelivered = false
        contentIdMutableLiveData.value = contentId
        return contentDetailResponse
    }

    fun getSeasonDetail(contentId: String): LiveData<Resource<SeasonDetail>> {
        isContentSeasonDetailDelivered = false
        seasonIdMutableLiveData.value = contentId
        return seasonDetailResponse
    }

    fun getEpisodeDetail(contentId: String): LiveData<Resource<EpisodeDetail>> {
        isContentEpisodeDetailDelivered = false
        episodeIdMutableLiveData.value = contentId
        return episodeDetailResponse
    }

    fun getRelatedContentEntities(contentId: String): WiseLiveData<Resource<RelatedContent>> {
        relatedContentIdMutableLiveData.value = contentId
        return relatedContentResponse
    }

    fun getRelatedSportsEntities(contentId: String): WiseLiveData<Resource<RelatedSports>> {
        relatedSportsIdMutableLiveData.value = contentId
        return relatedSportsResponse
    }

    fun getRelatedPeopleEntities(profileId: String): WiseLiveData<Resource<SearchResponse>> {
        relatedPeopleIdMutableLiveData.value = profileId
        return relatedPeopleResponse
    }

    fun addRecent(parameters: MutableMap<String, String>?): LiveData<Resource<ResultEntity>> {
        addRecentMutableLiveData.value = parameters
        return addRecentResponse
    }

    fun deleteRecent(contentId: String): LiveData<Resource<ResultEntity>> {
        deleteRecentMutableLiveData.value = contentId
        return deleteRecentResponse
    }

    fun markFavorite(contentId: String, markFavorite: Boolean = true): LiveData<Resource<ResultEntity>> {
        markFavoriteMutableLiveData.value = Pair(contentId, markFavorite)
        return markFavoriteResponse
    }
}

