package com.airtel.vision.util

import java.util.*

/**
 * Author : Akash Gupta
 * Created On : 09/08/18
 *
 */
object DateTimeUtil {
    fun getCurrentTimeStamp(): Long {
        return Date().time
    }
}