package com.airtel.vision.util

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import tv.airtel.data.utilmodule.DeviceIdentifier
import tv.airtel.data.utilmodule.util.LogUtil
import java.util.ArrayList
import java.util.HashMap

/**
 * Created by Satya on 27/03/18.
 */

object PermissionsUtil {

    private const val REQ_TYPE_APP_START = 0
    private const val REQ_TYPE_OPTIONAL = 1


    fun isPermissionGranted(type: PermissionType, activity: Context): Boolean {

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1) {
            val phoneStatePermission = ContextCompat.checkSelfPermission(activity,
                    Manifest.permission.READ_PHONE_STATE)
            if (type === PermissionType.TYPE_APP_START) {
                /**
                 * We check for device type that if STB or Stick then we don't need permissions
                 */
                when (DeviceIdentifier.deviceType) {
                    DeviceIdentifier.DeviceType.DEVICE_STICK,
                    DeviceIdentifier.DeviceType.DEVICE_STB -> {
                    }
                    DeviceIdentifier.DeviceType.DEVICE_PHONE,
                    DeviceIdentifier.DeviceType.DEVICE_TABLET -> {
                        if (DeviceIdentifier.projectType != DeviceIdentifier.AppId.APP_PRIMETIME && DeviceIdentifier.projectType != DeviceIdentifier.AppId.APP_MITRA) {
                            if (phoneStatePermission != PackageManager.PERMISSION_GRANTED) {
                                return false
                            }
                        }
                    }
                }
            } else if (type == PermissionType.TYPE_OPTIONAL) {
            }
        }
        return true
    }

    fun requestPermission(type: PermissionType, activity: Activity) {
        when (type) {
            PermissionType.TYPE_APP_START -> requestMandatoryPermissions(REQ_TYPE_APP_START, activity)
            PermissionType.TYPE_OPTIONAL -> requestOptionalPermissions(REQ_TYPE_OPTIONAL, activity)
        }
    }

    private fun requestMandatoryPermissions(mode: Int, activity: Activity) {
        LogUtil.e("PERM", "requestFileIO")
        val phoneStatePermission = ContextCompat.checkSelfPermission(activity.applicationContext, Manifest.permission.READ_PHONE_STATE)
        val accountPermission = ContextCompat.checkSelfPermission(activity.applicationContext, Manifest.permission.GET_ACCOUNTS)
        val listPermissionsNeeded = ArrayList<String>()
        if (!ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.READ_PHONE_STATE)) {
            if (phoneStatePermission != PackageManager.PERMISSION_GRANTED)
                listPermissionsNeeded.add(Manifest.permission.READ_PHONE_STATE)
        }
        if (!ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.GET_ACCOUNTS)) {
            if (accountPermission != PackageManager.PERMISSION_GRANTED)
                listPermissionsNeeded.add(Manifest.permission.GET_ACCOUNTS)
        }
        if (listPermissionsNeeded.size > 0) {
            ActivityCompat.requestPermissions(activity, listPermissionsNeeded.toTypedArray(), mode)
        }

    }


    private fun requestOptionalPermissions(mode: Int, activity: Activity) {
        val accountPermission = ContextCompat.checkSelfPermission(activity, Manifest.permission.GET_ACCOUNTS)
        val listPermissionsNeeded = ArrayList<String>()
        if (!ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.GET_ACCOUNTS)) {
            if (accountPermission != PackageManager.PERMISSION_GRANTED)
                listPermissionsNeeded.add(Manifest.permission.GET_ACCOUNTS)
            ActivityCompat.requestPermissions(activity, listPermissionsNeeded.toTypedArray(), mode)
        } else if (activity is OnRunTimePermissionListener) {
            activity.onPermissionDenied(PermissionType.TYPE_OPTIONAL)
        }
    }


    fun onRequestPermissionsResult(listener: OnRunTimePermissionListener?, requestCode: Int, permissions: Array<String>, grantResults: IntArray) {

        when (requestCode) {

            REQ_TYPE_APP_START -> {
                LogUtil.e("PERM", "REQ_TYPE_APP_START")
                val perms2 = HashMap<String, Int>()
                perms2[Manifest.permission.READ_PHONE_STATE] = PackageManager.PERMISSION_GRANTED
                perms2[Manifest.permission.GET_ACCOUNTS] = PackageManager.PERMISSION_GRANTED
                if (grantResults.isNotEmpty()) {
                    for (i in permissions.indices)
                        perms2[permissions[i]] = grantResults[i]
                    if (perms2[Manifest.permission.READ_PHONE_STATE] == PackageManager.PERMISSION_GRANTED && perms2[Manifest.permission.GET_ACCOUNTS] == PackageManager.PERMISSION_GRANTED) {
                        listener?.onPermissionGranted(PermissionType.TYPE_APP_START)
                    } else {
                        listener?.onPermissionDenied(PermissionType.TYPE_APP_START)
                    }
                }
            }
            REQ_TYPE_OPTIONAL -> {

            }
        }
    }

    enum class PermissionType {

        TYPE_APP_START,
        TYPE_OPTIONAL
    }

    interface OnRunTimePermissionListener {

        fun onPermissionGranted(type: PermissionType)

        fun onPermissionDenied(type: PermissionType)
    }

}
