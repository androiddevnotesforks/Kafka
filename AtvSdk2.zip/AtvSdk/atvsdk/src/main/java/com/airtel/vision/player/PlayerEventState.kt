//package com.airtel.vision.player
//
//import airtel.tv.stb.player.enums.ErrorReason
//
///**
// * Created by Aditya Mehta on 16/04/18.
// */
//
//
//enum class PlayerEventState(val errorDetail: ErrorDetail) {
//
//    NOT_CREATED(ErrorDetail(false, null, null)),
//    INITIALIZING(ErrorDetail(false, null, null)),
//    CREATED(ErrorDetail(false, null, null)),
//    INIT_PLAYER(ErrorDetail(false, null, null)),
//    PREPARING(ErrorDetail(false, null, null)),
//    PREPARED(ErrorDetail(false, null, null)),
//    STARTED(ErrorDetail(false, null, null)),
//    PAUSED(ErrorDetail(false, null, null)),
//    ERROR(ErrorDetail(false, null, null)),
//    FINISHED(ErrorDetail(false, null, null)),
//    NO_SUBSCRIPTION(ErrorDetail(false, null, null)),
//    LOGIN_UNKNOWN(ErrorDetail(false, null, null)),
//    AUTO_PLAY_FAILED(ErrorDetail(false, null, null));
//
//    class ErrorDetail(
//            var isRecoverable: Boolean = false,
//            var errorReason: ErrorReason? = null,
//            var errorCode: String? = null
//    )
//}
